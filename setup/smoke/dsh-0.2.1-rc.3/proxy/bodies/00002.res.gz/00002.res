data: {"id":"0ced582067ea89d60b11c5e5eecb7659","object":"chat.completion.chunk","created":1792974333,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1583,"ts_us":1792974333797082}}

data: {"id":"0ced582067ea89d60b11c5e5eecb7659","object":"chat.completion.chunk","created":1792974333,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Create hello","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1583,"ts_us":1792974333797302}}

data: {"id":"0ced582067ea89d60b11c5e5eecb7659","object":"chat.completion.chunk","created":1792974333,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":".txt with hi","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":171,"completion_tokens":6,"total_tokens":177,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":128,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1583,"ts_us":1792974333797575}}

data: [DONE]

