data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338583208}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_t8cdf8mi1eh2tirslssyeyq1","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338583298}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338583334}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338595618}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338596405}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338597448}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338597505}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338615690}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338615755}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338615801}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338615866}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338643493}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338643544}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338643841}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338644029}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338691993}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338692088}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338692163}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338692238}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338709685}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338709795}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338710532}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338710590}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":967,"ts_us":1792974338721113}}

data: {"id":"567ab46dc02a0509e196e9f008f31ac2","object":"chat.completion.chunk","created":1792974338,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":6073,"completion_tokens":58,"total_tokens":6131,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5760,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":967,"ts_us":1792974338721247}}

data: [DONE]

