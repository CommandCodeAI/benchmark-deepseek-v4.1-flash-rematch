data: {"id":"932a1d41b96599e5a47ee47f8a67bbbb","object":"chat.completion.chunk","created":1792974340,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1267,"ts_us":1792974340463617}}

data: {"id":"932a1d41b96599e5a47ee47f8a67bbbb","object":"chat.completion.chunk","created":1792974340,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"done —","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1267,"ts_us":1792974340463711}}

data: {"id":"932a1d41b96599e5a47ee47f8a67bbbb","object":"chat.completion.chunk","created":1792974340,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" `","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1267,"ts_us":1792974340463777}}

data: {"id":"932a1d41b96599e5a47ee47f8a67bbbb","object":"chat.completion.chunk","created":1792974340,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"hello.txt` created with contents","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1267,"ts_us":1792974340523299}}

data: {"id":"932a1d41b96599e5a47ee47f8a67bbbb","object":"chat.completion.chunk","created":1792974340,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":" `hi`.","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":6146,"completion_tokens":13,"total_tokens":6159,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":6016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1267,"ts_us":1792974340523670}}

data: [DONE]

