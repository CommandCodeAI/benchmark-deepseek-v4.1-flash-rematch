data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336722852}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Empty"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336722946}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directory, so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336723538}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no existing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840175}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hello.txt. Write it."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840221}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_bzerjot5jn79rkt81ynjs2p1","type":"function","function":{"name":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840353}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840395}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840443}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840482}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840524}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840563}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840628}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840691}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840745}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336840777}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336845458}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336845525}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336845580}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336845688}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336858830}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336858929}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336859040}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336860423}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336879623}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336879702}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336879764}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336879844}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336881285}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336881333}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336881573}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336881637}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336901394}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336901448}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336901497}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336903715}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336922762}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336922805}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336922863}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336925130}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336942628}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336942810}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336942861}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336943439}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336943534}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336943613}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336944276}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336944349}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336964195}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336964238}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336964286}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336964510}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336997121}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336997256}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336997324}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974336997504}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337005501}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337005590}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337005712}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337005935}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337028418}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337028498}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337028592}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337028747}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337045424}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337045474}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337045578}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337046218}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337092364}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337092413}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337092480}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337092538}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":991,"ts_us":1792974337138613}}

data: {"id":"f8235bd5ec5d7ff853f4e5192ebd01e3","object":"chat.completion.chunk","created":1792974336,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":5880,"completion_tokens":114,"total_tokens":5994,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":12,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":991,"ts_us":1792974337138778}}

data: [DONE]

