data: {"id":"4aadf3efcf4a7a0e7fcae16bff52b2de","object":"chat.completion.chunk","created":1792972598,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2655,"ts_us":1792972598905758}}

data: {"id":"4aadf3efcf4a7a0e7fcae16bff52b2de","object":"chat.completion.chunk","created":1792972598,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":"Done","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":5895,"completion_tokens":2,"total_tokens":5897,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2655,"ts_us":1792972598905895}}

data: [DONE]

