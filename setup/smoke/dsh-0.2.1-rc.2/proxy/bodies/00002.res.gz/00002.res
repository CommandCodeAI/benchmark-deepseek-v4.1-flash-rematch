data: {"id":"a384dd4de43037ac40e36ea20f21f491","object":"chat.completion.chunk","created":1792972594,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":876,"ts_us":1792972595098805}}

data: {"id":"a384dd4de43037ac40e36ea20f21f491","object":"chat.completion.chunk","created":1792972594,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Create hello","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":876,"ts_us":1792972595098874}}

data: {"id":"a384dd4de43037ac40e36ea20f21f491","object":"chat.completion.chunk","created":1792972594,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".txt with hi","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":876,"ts_us":1792972595098914}}

data: {"id":"a384dd4de43037ac40e36ea20f21f491","object":"chat.completion.chunk","created":1792972594,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":171,"completion_tokens":6,"total_tokens":177,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":128,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":876,"ts_us":1792972595099025}}

data: [DONE]

