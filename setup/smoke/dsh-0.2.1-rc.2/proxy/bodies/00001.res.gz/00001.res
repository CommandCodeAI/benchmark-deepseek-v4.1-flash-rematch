data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595473891}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_r15oh7x3xlhp7xqeij0urqkp","type":"function","function":{"name":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595473972}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595474333}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595505750}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595505829}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595505892}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595505954}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595518986}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595519136}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595519234}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595519330}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595530669}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595530755}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595530830}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595530901}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595530973}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595531047}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595531165}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595531239}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595553046}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595553203}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595553428}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595553738}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595582995}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595583080}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595583354}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595583430}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597313}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597421}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597525}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597636}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597732}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597809}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597885}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595597967}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595610577}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595610739}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595610835}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595610938}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595624263}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595624371}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595624454}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595624537}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595626808}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595627060}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595627147}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595639614}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595649515}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595649616}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595649704}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595649783}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595650902}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595651003}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595651099}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595651176}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595711631}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595711755}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595711849}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595711938}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595714074}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595714165}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595714240}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595714316}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595792411}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595792496}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595792589}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1250,"ts_us":1792972595795997}}

data: {"id":"87ccc7450f366d77daa35fa9dd9b8074","object":"chat.completion.chunk","created":1792972595,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":5715,"completion_tokens":101,"total_tokens":5816,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":4096,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1250,"ts_us":1792972595796295}}

data: [DONE]

