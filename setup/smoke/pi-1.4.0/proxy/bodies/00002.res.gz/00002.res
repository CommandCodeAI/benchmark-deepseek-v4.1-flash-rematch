data: {"id":"71b09ecad8f017292c91dbe03022a923","object":"chat.completion.chunk","created":1792973314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":834,"ts_us":1792973314985851}}

data: {"id":"71b09ecad8f017292c91dbe03022a923","object":"chat.completion.chunk","created":1792973314,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":"done","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":1880,"completion_tokens":2,"total_tokens":1882,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":1664,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":834,"ts_us":1792973314986017}}

data: [DONE]

