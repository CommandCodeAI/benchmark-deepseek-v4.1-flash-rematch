data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312012046}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_x3sjehu7ewarclld20n6f488","type":"function","function":{"name":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312012127}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312012198}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312025219}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312025275}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312025437}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312025489}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054196}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054268}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054498}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054604}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054665}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054715}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054825}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312054894}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312068199}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312068273}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312068318}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312068419}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312084039}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312084097}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312084243}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312084528}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312104680}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312104956}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312105239}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312105294}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312105600}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312105655}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312105694}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312106116}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312125637}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312125894}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312125958}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312126529}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312141687}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312141797}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312142075}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312142195}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312142433}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312143459}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312143533}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312143580}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312182965}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312183045}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312183432}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312183487}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312205376}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312205626}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312205846}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312206149}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312274466}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312274534}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312274828}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312275072}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312275126}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312275300}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312277366}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312277639}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312277688}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312277848}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312277892}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312278197}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312334311}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312334482}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973312334543}}

data: {"id":"126356acb39bb1c1ce2b591eed3780a4","object":"chat.completion.chunk","created":1792973311,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":1716,"completion_tokens":100,"total_tokens":1816,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":0,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1050,"ts_us":1792973312334739}}

data: [DONE]

