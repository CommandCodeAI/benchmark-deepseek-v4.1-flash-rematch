data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311392447}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311469823}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user wants a title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311469907}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311473151}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the conversation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311585111}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The message asks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311585151}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to create hello.txt containing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311585318}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"hi\". A short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311585355}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" title: \"Create hello"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311624209}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".txt with hi\" — three"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311624359}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to five words"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311624592}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311624637}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"hello"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311641769}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".txt with hi\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311641827}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Keep it natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311641959}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311642015}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Create","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311662171}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" hello","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311662243}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".txt","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311662301}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1258,"ts_us":1792974311662425}}

data: {"id":"ff41abbc5af2ae9eafcddaf65f5c31f2","object":"chat.completion.chunk","created":1792974311,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":" hi","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":478,"completion_tokens":54,"total_tokens":532,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":384,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":48,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1258,"ts_us":1792974311662537}}

data: [DONE]

