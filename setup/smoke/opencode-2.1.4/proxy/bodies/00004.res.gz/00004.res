data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315065581}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Reply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315065667}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exactly \"done.\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315065695}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315116155}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" User says then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315116211}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reply done. Lik"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315116255}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ely just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315116291}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" done"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315223017}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315223115}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"done","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315223183}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":939,"ts_us":1792974315223253}}

data: {"id":"b739114f792ab73ca9cd42b4c822389e","object":"chat.completion.chunk","created":1792974314,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":5547,"completion_tokens":20,"total_tokens":5567,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5376,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":17,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":939,"ts_us":1792974315223901}}

data: [DONE]

