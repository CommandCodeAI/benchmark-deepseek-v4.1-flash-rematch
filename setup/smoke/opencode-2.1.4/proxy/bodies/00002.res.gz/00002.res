data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311127694}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311127772}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need fulfill. Need create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311127834}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hello.txt containing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311263609}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hi,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311263679}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then reply done. We are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311263731}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in work dir"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311263774}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use write tool. Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311275801}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311275881}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" existing file? Instruction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311275986}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says create. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311276058}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s inspect quickly maybe no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311365685}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need. But treat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311365779}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unfamiliar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311365851}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" files, don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311365919}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t overwrite?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311468746}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hello"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311468848}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".txt likely test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311469682}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311469772}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use shell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311526645}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test existence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311527256}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311527427}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write tool,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311527827}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311634996}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311635068}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"riting potential user file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311635265}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311635531}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311680035}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311680108}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1svm0qlentchaey29791ddca","type":"function","function":{"name":"glob"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311680238}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311680348}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311681073}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pattern"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311681150}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311681227}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311681389}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311696521}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311696756}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311696909}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311697059}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1006,"ts_us":1792974311735293}}

data: {"id":"a1efe7fcb6de79d00f0d116180bcf24c","object":"chat.completion.chunk","created":1792974310,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":5323,"completion_tokens":117,"total_tokens":5440,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":256,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":79,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1006,"ts_us":1792974311735702}}

data: [DONE]

