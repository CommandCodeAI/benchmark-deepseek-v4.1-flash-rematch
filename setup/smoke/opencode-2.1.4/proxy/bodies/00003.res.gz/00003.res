data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313373256}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313373406}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write. Content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313373528}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313475854}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hi\" perhaps word hi"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313475931}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313476037}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line. \"hi"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313477030}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\\n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313504517}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313504560}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_x6ar62luo67t8mbfj981uzvc","type":"function","function":{"name":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313504980}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313505041}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313515727}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313515787}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313515927}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313515971}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313525837}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313525889}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313526016}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313526133}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313562526}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313562686}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313562760}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313563036}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313570847}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313570925}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313570978}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313571018}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313623921}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1106,"ts_us":1792974313624214}}

data: {"id":"d247fa2960edeb83ea075d89bd1bb4af","object":"chat.completion.chunk","created":1792974313,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":5455,"completion_tokens":74,"total_tokens":5529,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5248,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":19,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1106,"ts_us":1792974313624563}}

data: [DONE]

