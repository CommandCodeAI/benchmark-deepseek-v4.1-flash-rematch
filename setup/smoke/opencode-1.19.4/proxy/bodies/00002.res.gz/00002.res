data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335031405}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335031486}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user wants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335032151}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335228294}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simple task: create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335228391}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hello"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335228462}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".txt containing \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335228533}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hi\", then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335245672}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reply done. Let me use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335245763}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335245831}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write tool. Need to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335245893}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check the working"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335265694}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directory."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335265797}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335265871}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335265948}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hello"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335283987}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".txt in c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335284112}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wd.\n\nI should probably"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335284301}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335284494}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335377761}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file exists first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335377846}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335378802}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335378874}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requires read first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335440755}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335440850}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335441307}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exists). Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335441401}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" just write it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335538129}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If it exists"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335538192}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335538243}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tool may fail requiring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335538566}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read. Let's check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335606528}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with ls quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335606602}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335606804}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335606967}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trivial; I can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335697730}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" just write. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335697799}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per instructions,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335697864}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if existing file,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335697904}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" must read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335772319}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first. Let me check existence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335772491}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335772622}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glob or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335773379}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bash. I'll use glob"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335823874}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for hello"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335823949}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".txt. But simpler"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335824056}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": just write;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335824336}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if fails, read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335924245}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then write. To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335924400}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" minimize,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335924482}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll glob"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335925331}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335949005}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_b89rafokictvi8cd0yjq8n6b","type":"function","function":{"name":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335949064}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335949122}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335949817}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335991219}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335991283}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335991495}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335992021}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335992146}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335992356}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335992511}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335992797}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335992867}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335995912}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335995977}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973335996021}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336001219}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336001268}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336001403}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336001506}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336034982}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336035058}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336035123}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336035173}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336046495}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336046551}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336046607}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336047023}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336047599}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336047674}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336047741}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336049390}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336070085}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336070140}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336070189}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336070988}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336091915}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336092001}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336092091}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336092209}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336092276}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336092329}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336092373}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336092402}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336182310}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336182384}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336182432}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336182483}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336182584}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336183710}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336183760}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336183834}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336190351}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336190420}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336190547}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336190603}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336218776}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336218841}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336218944}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336219059}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336219867}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336220138}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336220249}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336220308}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336283395}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336283571}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1519,"ts_us":1792973336283625}}

data: {"id":"8a7cc927051844ea72cf5194148d8807","object":"chat.completion.chunk","created":1792973334,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":10795,"completion_tokens":247,"total_tokens":11042,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":0,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":146,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1519,"ts_us":1792973336284283}}

data: [DONE]

