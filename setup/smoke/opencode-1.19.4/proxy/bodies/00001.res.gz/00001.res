data: {"id":"9a1f31ced731cea255a503a0e0c25af7","object":"chat.completion.chunk","created":1792973332,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":846,"ts_us":1792973332418053}}

data: {"id":"9a1f31ced731cea255a503a0e0c25af7","object":"chat.completion.chunk","created":1792973332,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Creating","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":846,"ts_us":1792973332418119}}

data: {"id":"9a1f31ced731cea255a503a0e0c25af7","object":"chat.completion.chunk","created":1792973332,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" hello.txt with","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":846,"ts_us":1792973332419024}}

data: {"id":"9a1f31ced731cea255a503a0e0c25af7","object":"chat.completion.chunk","created":1792973332,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" \"","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":846,"ts_us":1792973332456481}}

data: {"id":"9a1f31ced731cea255a503a0e0c25af7","object":"chat.completion.chunk","created":1792973332,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":"hi\"","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":561,"completion_tokens":8,"total_tokens":569,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":512,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":846,"ts_us":1792973332456594}}

data: [DONE]

