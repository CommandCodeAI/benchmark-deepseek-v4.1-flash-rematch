data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377120511}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377151801}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need build single-file index"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377151923}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".html in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377153097}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377215821}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wd. Need design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377215979}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377216166}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377216209}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quality. Need inspect workspace."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377279467}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We'll plan"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377279634}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We have huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377279795}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" token budget"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377280272}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need produce polished interactive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377523991}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem simulation. Need likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377524090}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no need external"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377524174}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assets. Need ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377524250}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377589012}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377589107}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", run N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377589178}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations, seeded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377589345}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PRNG deterministic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377630131}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", simulation logic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377630241}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" separate render, head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377630324}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377637990}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aster than"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377675219}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real time, controls composition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377675388}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" integrated, distinctive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377675534}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual direction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377675577}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", palette"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377697792}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377697853}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"type pairing/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377697984}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ignature element,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377698194}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species colors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377759744}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/glyphs, all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377759927}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variables integrated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377760099}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377760248}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" surface, custom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377824263}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377824322}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iders/dials"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377824377}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/steppers/toggles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377824467}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377943336}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377943509}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next to each knob"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377943890}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" showing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377944042}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effect, tooltips"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377990110}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyboard support"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377990272}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus states"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377990500}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973377990569}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378081427}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378081608}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378081698}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378082126}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"plague/third"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378153151}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378153289}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378153436}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"urable intervals,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378153841}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" restrained"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378269277}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" announcement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378269509}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378269926}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378269975}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" markers, end dashboard population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378338674}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378338822}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trait drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378338972}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378339315}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378409229}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"read per gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378409410}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per species canvas same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378409454}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" language"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378409855}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWe need deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378501255}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378501305}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index.html only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378501366}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need test via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378501427}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378576024}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less browser maybe available? Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378576097}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" environment. Need maybe screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378576152}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378576189}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We'll explore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378758136}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378758202}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_kiy0yzmmao6yjo8zo0eawhls","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378758271}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973378758365}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090139}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090199}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090254}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090311}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090382}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090640}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090715}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090783}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090851}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090894}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379090959}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091025}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" which"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091087}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091152}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" npm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091197}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091264}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091314}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091453}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091533}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091596}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091641}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091705}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091776}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091834}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091890}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379091952}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092011}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092045}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092088}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092396}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092456}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092500}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092562}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092615}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092664}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092731}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092801}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092866}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092930}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379092987}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093048}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093201}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093288}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" npm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093357}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093439}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093530}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093596}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093707}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093799}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093869}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093931}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379093972}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094023}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094207}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094266}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094328}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094399}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094453}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094504}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094549}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094625}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094677}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094740}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094785}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094841}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379094989}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095077}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095147}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095253}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095312}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095390}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095466}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095532}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095598}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095646}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095700}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095765}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095933}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379095986}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096038}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096084}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096165}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096235}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096297}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096360}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096420}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096484}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096598}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096689}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096822}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096899}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379096961}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379097030}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379097083}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379097144}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379097183}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379127653}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379127734}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379127877}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379127950}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379177901}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379177975}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379178186}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379178256}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379182073}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379182154}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379182228}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379182300}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379184919}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379185010}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" workspace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379185089}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379185192}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" available"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379185315}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tool"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379185396}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379185449}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379185516}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379229460}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_0lb9d3tydko7sg9m0bqtac2n","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379229609}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379229803}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379229878}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379246912}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379246985}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379247099}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379247547}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379289877}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379290029}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379290084}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379290227}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379290533}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379290603}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379290712}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379290763}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379292894}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379292985}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379293114}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379293210}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379312983}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379313091}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379313232}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379313283}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379314070}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379314142}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379314188}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379314257}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379336930}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379337007}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379337065}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379337126}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379350038}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379350128}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379350195}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379350248}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379353306}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379353411}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379353464}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379353613}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379365598}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379365665}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379365735}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379365825}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379378417}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379378464}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379378552}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379378601}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379379234}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379379345}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379379579}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379379635}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379407571}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379407685}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379407884}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379407965}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379417616}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379417690}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379417759}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379417822}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"printf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379418064}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379418119}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379418228}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379418270}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379446955}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379447071}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379447155}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379447247}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379463504}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379463598}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379463675}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379463750}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510264}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510366}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510450}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510527}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510606}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510687}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510758}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379510834}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379524669}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"List"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379524771}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" existing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379524878}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" files"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379524962}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379606219}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":871,"ts_us":1792973379606351}}

data: {"id":"8718c78245aaabf932655a513171f3c2","object":"chat.completion.chunk","created":1792973377,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":6129,"completion_tokens":460,"total_tokens":6589,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5504,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":196,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":871,"ts_us":1792973379606720}}

data: [DONE]

