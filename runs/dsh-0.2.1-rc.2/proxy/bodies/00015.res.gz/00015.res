data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988407036}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988463775}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28 gives more stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988464000}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and all species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988464377}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survive all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988532805}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988533092}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Default food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988533159}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988533302}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988619306}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988619506}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988619810}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28, average moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988619873}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988719127}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-370"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988719200}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", shrike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988719258}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40-46"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988805114}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps, flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988813673}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 371"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988813922}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-101"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988813966}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2. Shri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988905491}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes cap often;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988905552}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988999572}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988999632}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973988999689}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births 45"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989096151}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989096376}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989096638}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 85"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989096678}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-300. Not lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989170701}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989170900}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989171213}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989171295}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989191287}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike cap/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989191390}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"controls and boost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989191463}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989191540}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989222091}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989222182}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe.\n\nThe cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989222338}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" causes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989224535}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shrike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989290655}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to hover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989290845}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 42-52,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989291422}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" which is too many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989291522}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989364773}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989365197}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"50 out"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989365281}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989365361}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989441626}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It's fine. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989441713}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989441893}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pressure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989442153}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keeps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989576607}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants low. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989576683}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set cap 28 to allow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989576749}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989576808}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989607561}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989607627}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap at 42 not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989607687}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989607744}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989682728}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989683005}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989683071}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes lower, moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989683472}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989846939}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989847201}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plants lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989847251}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989847734}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989893130}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable.\n\nThe biggest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989893192}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" concern is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989893240}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants fluctuating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989893290}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989910842}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989911066}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 to 85"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989911137}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We could increase plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973989911301}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local rate more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990005615}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to smooth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990005908}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990005975}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990006448}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dependent prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990122808}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990122929}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990123093}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990123557}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yields min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990178815}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 85"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990179004}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990179996}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990180077}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990227993}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot times"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990228067}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990228203}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could be sparse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990228255}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can choose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990328422}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial/default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990328716}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed/time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990329111}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to showcase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990329174}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990420758}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But evaluation may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990420980}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run arbitrary time. Need robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990421208}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual.\n\nMaybe redesign"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990421278}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the ecology"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990482025}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990482103}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less oscill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990482170}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"atory, e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990482231}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g. plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990556163}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have high reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990556289}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth and are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990556578}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not the primary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990556667}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limiting factor;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990637951}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990638147}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990638203}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990638664}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990731318}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" thresholds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990731429}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990732388}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990732451}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants are abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990795484}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", lens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990795649}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks lush and prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990795692}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990796142}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If prey over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990871294}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"populate, predators control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990871501}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". A balance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990871794}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990871856}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990984661}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990984831}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990985181}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973990985263}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-4000, moths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991019407}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991019481}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-250, shri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991019531}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991019627}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991108486}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991108676}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" achieve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991108997}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991109370}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991173249}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stronger ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991173550}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991173596}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991173853}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991256249}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991256383}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local rate .05) and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991256447}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991256861}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991338433}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moderate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991338499}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991338629}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991338680}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991413787}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991413871}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991414224}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991414277}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991500810}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991500955}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991501246}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strong,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991501286}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" which leads sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991620233}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991620289}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need prevent sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991620333}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike overpopulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991620546}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991658858}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apping at lower "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991658942}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991659013}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and making"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991659078}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991773329}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991773471}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" efficient when many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991773505}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991773881}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shrike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991951344}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991951621}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991951675}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973991952057}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey may grow to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992028555}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 500, eating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992028610}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants. Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992028657}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moth cap?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992028929}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992041372}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm.\n- Add negative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992041487}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992041748}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dependence to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992042104}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moth reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992077987}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992078050}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survival"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992078092}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992078180}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992166008}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"razing independent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992166223}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992166508}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992166577}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992246718}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crowding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992246912}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992247867}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"isease. Reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992247927}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992337321}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduced by moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992337412}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992337503}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992337559}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `_reproduce`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992417809}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scale chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992417948}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992418266}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992418310}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992500795}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992500950}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 + count/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992500999}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ap). Easier:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992501366}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992583950}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992584163}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992584433}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992584505}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992660638}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992660861}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"crow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992661146}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ding cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992661191}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992757646}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992757885}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `cost += 0.001"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992757942}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 * moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992758278}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Count` per individual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992844874}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992845139}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"500 → .75"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992845194}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/g). This damp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992845454}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ens bo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992941003}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oms and prevents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992941181}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992941546}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"grazing. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992941600}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s an ecological carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992993727}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992993822}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from the closed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992993868}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glass. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973992994278}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993141718}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993141834}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993141881}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stabilize.\n- Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993142337}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993157605}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993157719}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993157953}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"row so they can't be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993158002}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wiped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993236768}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" out:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993236862}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993237041}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count < 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993237092}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", boost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993317269}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed rain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993317412}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" automatically? \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993318773}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Refug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993318857}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ia\" in seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993451466}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bank. Add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993451542}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a low-density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993451599}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rescue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993451649}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993498842}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993499046}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seedCount"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993499093}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" *="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993499362}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1 + ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993577221}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993577292}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" - flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993577373}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/600"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993577723}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")*..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993645039}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`. This prevents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993645114}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993645430}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dropping below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993645471}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~100, but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993718848}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visually still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993718922}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993719010}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Better plants have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993719055}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993792162}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"al"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993792276}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"atable/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993792495}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"refuge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993792746}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" portions?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993870148}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could show individual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993870289}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993870610}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ground"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993870664}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cover? Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993945502}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSince"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993945659}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993945919}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973993945987}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" main deliverable,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994070717}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the ecosystem can be somewhat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994070768}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamic/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994070816}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994070861}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-bust but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994128111}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994128160}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994128201}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994128255}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction frequently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994213962}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994214031}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994214075}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994214493}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994378677}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can choose default seed and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994378737}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994378874}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial condition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994378959}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The screenshot at random"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994392917}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time might show plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994393039}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~1000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994393120}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994393667}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if default. Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994427772}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994427835}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"NOR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994427881}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"TH-3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994427942}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" with food 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994532529}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gives final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994532588}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 767"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994532655}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/134"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994532754}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/51, avg 101"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994612130}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2/344/46"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994612183}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994612243}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994612375}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"end) dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994669709}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" anyway"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994669819}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994670099}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10s, need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994670163}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994848258}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's check default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994848354}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994848435}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could prime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994848490}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994857399}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994857488}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable oscillations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994857577}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe not over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994857676}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-optimize.\n\nBut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994912183}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994912318}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count: at 767"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994912363}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with 660"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973994912780}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995014966}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995015100}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", density ~3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995015379}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8% (767"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995015469}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995078547}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20k cells), appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995078637}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparse! To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995078871}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995078908}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush, need dig into rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995164831}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995165031}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can be larger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995165094}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995165463}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple sprouts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995260270}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995260401}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995260475}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995260829}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995317388}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800 across circle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995317481}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995317556}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as scattered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995317628}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dots. Need at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995444369}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" least 1500-300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995444421}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 plants for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995444571}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush look. Our starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995444649}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995488759}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1900 (9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995488900}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5% cover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995489126}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995489188}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" somewhat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995551793}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparse, but can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995551926}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995552187}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants larger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995552374}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/spread."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995633584}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995633680}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" To get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995633961}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995634303}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995714586}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plants could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995714708}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995714987}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clusters bigger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995715070}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than one cell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995795236}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Or use continuous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995795278}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant agents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995795456}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995795504}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per cell. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995898673}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we need bigger plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995898737}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995898866}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995898910}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendering scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995947266}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995947438}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" halo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995947490}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973995947759}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oss patches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996034040}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996034100}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996034584}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fill. We could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996034639}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" treat plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996127626}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996127687}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s about"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996127734}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996127772}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6px at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996190316}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 160"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996190401}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996190470}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996190556}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996265128}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 at ~3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996265272}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996265562}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" => 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996265614}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% area"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996339598}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996339728}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996339819}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" look dotted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996339871}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996416909}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" draw \"m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996417023}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oss beds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996417214}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996417314}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" neighboring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996499833}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants connected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996500190}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996500465}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" idea"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996500542}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": connect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996588903}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearby plants with faint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996589620}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" filaments"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996589675}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/branch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996589712}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996660738}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" form organic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996660806}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996660901}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996660976}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual density increases"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996785542}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996785687}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more plants and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996785886}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996786182}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996866252}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996866476}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aesthetic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996866537}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973996866911}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has a subtle moss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997004423}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997004777}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" texture. Good.\n\nBut for ecology"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997004871}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997005061}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scarcity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997028884}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997029134}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997029213}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997031154}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve. Our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997085189}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator counts high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997085276}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997085504}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997085579}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997219487}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant count to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997219558}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" e.g. "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997219674}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4000 and food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997219734}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997439616}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997439662}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then plant count maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997439761}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1500-3000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997439798}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997492758}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" proper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997492925}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997493152}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". More"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997493207}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997576401}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997576610}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997576841}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable. Let's explore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997576893}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with start "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997595352}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4000, local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997595498}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997595549}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .05, food 36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997595982}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", repro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997607333}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" thresholds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997607494}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997607782}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". More"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997607863}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997644900}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more food;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997645037}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moths boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997645330}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predators boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997645621}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997737696}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stronger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997737822}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crowding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997738129}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and lower caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997738184}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997815115}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997815240}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grid hold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997815414}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up to multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997815472}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants? Already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997894078}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one per cell. Cover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997894190}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997894489}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 820"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973997894571}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998081960}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If we hal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998082129}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve growth, plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998082318}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can be 2000."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998082419}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998096029}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills them.\n\nPotential simulate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998096200}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998096459}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" middle \"se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998096547}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eded ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998154390}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" with a fixed fraction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998154537}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998154800}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" protected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998154861}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998228584}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" substrate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998228645}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not eaten"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998228695}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by moths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998228750}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998308983}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g., plants have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998309078}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a \"c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998309146}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rown\" size"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998309208}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and only some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998404231}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells accessible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998404311}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998404378}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998404445}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998458449}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998458761}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998458844}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998459008}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remains reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998546118}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998546174}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998546242}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of disappearing. Interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998546316}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998602691}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exist in ~400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998602841}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 cells; when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998603148}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eaten, they don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998603216}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t disappear entirely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998680662}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998681160}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reset to a seedling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998681218}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998681319}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with age 0 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998768286}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998768415}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"row."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998768501}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998768863}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998846550}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" declines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998846814}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998847167}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes/old age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998847232}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Moths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998928130}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998928191}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"energy\" but plant remains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998928246}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Visual vegetation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973998928299}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remains. This changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999005826}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999005954}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics and provides"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999006029}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush look. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999006287}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999140931}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999141046}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999141119}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999141580}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth.\n- The food resource"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999166324}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999166586}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" standing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999166646}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" biomass; prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999166974}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consume energy and the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999253071}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant loses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999253290}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999253359}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999253731}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"health"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999314783}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999314933}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rows. Need \"g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999315055}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"razed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999315101}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" state. That would show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999428697}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shorter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999428747}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999428873}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999428930}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999472955}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Individual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999473109}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999473303}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells persistent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999473585}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999599549}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still spreads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999599674}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can implement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999600212}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n   - Each plant has `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999600256}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"age`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999628077}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `energy`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999628147}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/`bi"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999628327}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"omass` "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999628397}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0..1; grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999721757}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999721990}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999722058}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999722428}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999915227}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(age, 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999915339}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5)` / `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999915603}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"grazedAt ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999915649}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999957839}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`, and yields"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999958114}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy proportional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999958351}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792973999958394}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But if a plant is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000022488}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" always"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000022611}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazed at young age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000022671}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", it persists"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000022848}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000096040}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cell. Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000096288}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000096544}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000096812}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n   - However user expects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000154066}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000154144}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" creatures"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000154199}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000154397}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000229630}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n   - Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000229683}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000229864}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would not collapse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000229921}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; more stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000296552}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Selection"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000296603}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000296637}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resilience"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000296724}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000365348}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000365403}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"undity may still."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000365431}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000365528}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000453007}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grasses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000453202}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000453256}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oss in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000453685}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a terr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000543168}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arium. Data not too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000543251}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complex.\n   - But current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000543374}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" model de"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000543451}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"letes plant on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000615135}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000615199}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can instead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000615256}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000615356}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it as \"graz"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000703522}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed\" with age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000703740}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000703780}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000704162}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and give"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000870526}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000870588}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000870642}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000870701}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000917434}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; low age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000917519}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000917768}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000917828}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000955721}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000955814}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mostly only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000956054}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" decline from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974000956144}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" old"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001035926}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-age death"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001036042}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001036265}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes. Food becomes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001036310}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limited by reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001180672}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001180971}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not population. M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001181062}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001181141}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" won't wipe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001248937}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" out plants. This could stabilize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001249009}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001249057}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001249099}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001294910}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n   - Initial plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001295016}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1900 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001295266}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still sparse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001295319}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001358532}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial to 4000 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001358730}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001358998}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% cover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001359040}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and more."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001448857}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But count affects sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001448929}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001449090}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001449166}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Yet plant reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001515073}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001515121}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" creates new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001515175}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001516799}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001595212}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumed but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001595321}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not killed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001595591}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001595646}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001727779}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can hit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001727863}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap. Control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001727932}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via senescence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001728106}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001790740}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001791608}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001791719}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001791776}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth\" control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001855889}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would naturally set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001855986}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrowth of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001856390}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001856435}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"zed moss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001931410}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001931610}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001931760}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001931818}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds. Great."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001989885}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001989980}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" define each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001990329}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant's `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974001990369}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"bi"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002058153}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"omass` grows each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002058259}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen (or age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002058557}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" represents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002058615}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002268653}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002268708}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on vigor and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002269015}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nutrition;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002269064}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey consume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002317130}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" biomass; if biomass low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002317214}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", it remains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002317592}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but cannot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002317677}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002333273}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002333424}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002333479}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002334212}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002414603}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" persist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002414755}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This is a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002414990}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better \"under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002415040}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002497901}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" closed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002497986}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecology"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002498053}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002498145}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002618977}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" refactor.\n- Consumption by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002619079}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002619378}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002619449}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002648593}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002648711}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reaching"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002649012}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002649055}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002727656}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002727733}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fraction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002727800}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If plant is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002727864}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002802950}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ature\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002803103}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough, remove it?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002803427}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's classic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002803506}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002884047}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002884161}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002884391}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", leave"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974002884737}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003000114}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003000311}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can have plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003000471}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"age\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003000763}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003082423}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003082488}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003082583}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" targets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003082654}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mature plants, and consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003119924}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resets age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003119982}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003120921}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Mature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003120985}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003248112}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003248185}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003248268}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"maturity` gens. This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003248331}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003343020}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many seedlings"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003343169}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003343515}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"bar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003343603}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ren cells"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003358826}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003358964}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remain as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003359430}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small sprouts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003359514}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The lens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003428238}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003428338}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still show tiny sprouts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003428612}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003428824}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003519649}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time. Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003519784}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" becomes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003520137}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throughput"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003520201}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could allow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003589069}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey select"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003589119}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003589165}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age > maturity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003589779}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if target mature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003665778}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", remove or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003665984}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reset."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003666026}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003666377}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003747924}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003747975}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003748149}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny sprouts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003748412}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The count of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003818981}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" viable food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003819100}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matters"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003819352}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003819397}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pler: keep current removal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003895317}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003895848}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003895903}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and add \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003895957}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003995928}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ent seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003996089}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"bank"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003996463}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974003996510}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rapidly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004053363}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004053417}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004054612}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". More plants ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004054699}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004129630}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004129818}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004129872}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrowth. But then prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004130225}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004207201}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004207244}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004207412}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density isn't required"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004208111}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to have full green"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004296883}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carpet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004296994}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004297059}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" noct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004297476}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"urne glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004380359}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004380441}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scattered luminous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004380749}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moss,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004380802}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004442257}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004442362}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes can be beautiful even"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004442641}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004442688}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 500 plants, if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004532243}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004532317}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with halos. We can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004532385}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004532452}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant as a little moss cluster"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004617988}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004618038}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004618079}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-10px with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004618264}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004684199}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004684330}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rigs. With 500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004684654}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants, there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004684710}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'d still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004761499}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be visible activity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004761618}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004761959}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004762011}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 abundant. At low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004838398}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" points"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004838614}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", swarm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004838692}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004839368}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moths. Fine."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004928621}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004928710}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"living"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004928778}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004928833}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004999316}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004999437}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t require full carpet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004999516}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nStill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974004999815}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", robustness and sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005074297}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005074415}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005077647}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" arbitrary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005077690}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005159454}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005159653}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with empty species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005159922}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005159983}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that's a legitimate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005242530}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005242613}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outcome and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005242667}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interesting. Default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005242810}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005318965}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be chosen. We'll choose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005319061}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005319202}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that survives"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005319557}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005403892}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005403981}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NORTH-3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005404062}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" with default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005404262}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food 22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005477570}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005477656}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005477719}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"333/340"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005477783}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/52, all survive;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005559840}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005559894}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005560125}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005560183}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005638044}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 52. \"GL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005638247}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ASS-1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005638538}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" final "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005638586}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"861/520/32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005795492}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005795571}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005795690}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"GLASS-1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005795767}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005899198}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005899288}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moth cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005899336}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and plant "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005899442}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"861, but at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005937566}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240 it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005937797}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has 32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005937862}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974005938126}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes. \"NOR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006021264}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"TH-3\" nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006021341}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006021479}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006021535}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006094306}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006094366}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006094690}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006094767}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NORTH-3\" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006227818}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 767/134"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006228105}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/51. Sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006228147}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006228207}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could reduce max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006266800}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shrikes to 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006267072}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to reduce."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006267111}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006267907}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006352514}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006352857}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006352900}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28 & shrike cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006353214}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28; maybe plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006432057}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006432300}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", moths?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006432354}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need cap births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006432585}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006513417}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006513673}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006513939}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006513985}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006653529}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10. Test. Could patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006653600}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006653749}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_mnrzow2at9gab3dmz4xkbcq6","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006654071}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006654138}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006654183}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006654260}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006654332}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006654383}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006654440}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006655770}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006655846}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006664550}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006664678}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006664928}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006665326}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006665400}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006665864}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006665924}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006665979}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006689949}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006690142}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006690213}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006690264}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006720074}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006720130}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006720396}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006720509}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006739310}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006739404}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006739478}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006739551}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006740013}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006740082}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006740149}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006740212}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006766585}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006766660}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006766823}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006766911}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006766963}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006767033}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006768290}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006768353}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006782678}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006782839}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006782920}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006783313}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006796883}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006796954}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006797304}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006797428}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006797781}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006797858}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006799058}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006799130}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006816329}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_SH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006816388}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006816442}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006816893}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006837872}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006838175}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006838239}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006838421}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006838463}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006838577}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006839277}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_SH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006839358}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006856846}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006856981}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006857041}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006857102}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006888247}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006888338}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006888551}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006889018}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006889101}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006889164}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006889211}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006889891}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006914170}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006914343}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006914394}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006914459}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006938796}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006938897}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006939244}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974006939308}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007021446}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007021531}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007021602}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007021853}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007024178}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007024238}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007027695}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007027766}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007027822}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007027877}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007027927}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007028112}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007035432}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007035539}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007035861}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007035929}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007042932}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007043087}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007043142}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007043604}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007043885}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007044241}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007044296}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007044345}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007045038}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007045087}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007045579}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007045627}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007068030}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007068075}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007068141}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007068282}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007083295}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007083345}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007083464}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007083520}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007083966}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007084011}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007084061}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007084134}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007147037}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007147140}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007147229}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007147284}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007159238}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007159418}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007159466}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007159835}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007161951}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007162177}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007162237}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007162647}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007167649}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007167698}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007167807}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007167851}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007170157}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007170397}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007170492}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007170576}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007179373}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007179550}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007179609}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007180116}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007181054}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007181123}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007181169}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007181352}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007196274}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007196472}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007196526}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007197090}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007216258}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007216319}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007216522}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007216579}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007218004}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007218147}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007218464}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007218543}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007239291}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007239374}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007239448}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007239498}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007267188}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007267391}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007267435}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007267932}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007285351}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007285412}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007285678}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007285926}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007286202}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007286251}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007286306}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007286375}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007300161}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007300221}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007300483}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007300535}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007321535}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007321612}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007321675}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007321774}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007322770}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007323171}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007323293}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007323554}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007349411}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007349467}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007349676}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007349729}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007356123}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007356176}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007356413}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007356463}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007356529}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007356594}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007356642}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007357568}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007377406}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007377480}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007377548}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007377595}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007399003}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007399099}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007399185}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007399259}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007399814}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007400194}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007400427}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007400552}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007415956}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007416055}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007416436}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007416530}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007439059}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007439153}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007439236}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007439337}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007439844}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007439932}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007440198}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007440306}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007472358}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007472492}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007472570}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007472971}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007473058}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007473135}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007473517}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007473613}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007491290}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007491609}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007491714}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007491919}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007510804}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007511085}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007511182}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007511441}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007511548}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007511633}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007511711}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007511787}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007604583}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007604654}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007604829}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007604938}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007610645}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007610690}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007610937}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007611012}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007611429}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007611511}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007611583}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007612107}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007619848}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007619908}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007620181}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007620230}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007621555}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007621598}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007621645}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007621693}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007622173}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007622217}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007622282}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007622337}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007628883}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007628945}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007629056}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007629100}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007633331}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007633560}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007633617}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007633672}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007634250}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007634299}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007634368}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007634449}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007646602}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007646962}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007647040}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007648907}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007668502}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007668760}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007668855}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007669357}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007669606}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007669838}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007669883}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007670386}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007695715}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007695973}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007696021}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007696077}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007709491}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007709563}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007709620}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007709990}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007710835}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007710890}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007710938}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007711213}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007728254}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007728318}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007728372}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007728412}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007748548}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007748629}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007748689}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007748733}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007749039}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007749083}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007749167}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007749219}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007767191}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007767405}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007767459}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007768026}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007805528}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007805606}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007805662}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007805824}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007827962}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007828037}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007828104}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007828225}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007841240}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007841513}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007841599}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007841828}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007882765}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007882837}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007883073}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007883151}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007883577}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007883896}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007884034}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007884115}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007903352}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007903654}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007903727}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007903961}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007923755}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007923987}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"07"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007924039}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007924103}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007940915}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"URE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007941031}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007941115}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007941183}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007957871}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007957920}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007958150}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"NOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007958207}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"TH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007958861}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007959096}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007959354}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007959398}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007979165}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007979256}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007979361}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007979593}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007995112}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007995376}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007995428}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007995755}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007996046}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007996443}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007996502}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IDE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974007996554}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008020754}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008020806}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008020959}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008021000}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008055970}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008056223}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008056276}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008057004}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008110993}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008111275}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008111321}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008111678}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008112576}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008112843}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008113294}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008113375}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008122938}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008123023}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008123093}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008123142}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008123572}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008123645}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008127567}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008127632}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008135375}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008135655}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008135740}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008135811}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008155365}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008155691}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008155967}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008156037}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008156519}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008156588}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008156647}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008156688}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008173867}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008173916}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008174140}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008174199}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008194912}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008194961}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008195247}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008195321}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008195675}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008195724}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008195787}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008196416}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008231072}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008231354}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008231399}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008231674}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008235296}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008235492}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008235549}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008235996}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008284467}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008284740}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008284795}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008285200}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008285283}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008285347}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008285439}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008285489}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008287025}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008287087}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008287140}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008287196}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008346294}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008346346}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008346511}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008346721}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008368350}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008368397}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008368585}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008368638}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008369093}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008369150}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008369494}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008369541}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008387099}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008387159}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008387361}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008387411}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008388606}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008388854}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008388896}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008389606}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008389655}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008390168}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008390222}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008390282}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008390772}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008390822}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008390864}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008391586}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008399409}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008399504}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008399731}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008399797}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008400572}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008400821}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008400870}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008400921}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008447630}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008447700}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008447747}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008447889}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008473329}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008473578}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008473635}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008477279}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008482094}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" lower"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008482175}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" predator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008482406}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008482477}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008531404}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" richer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008531492}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" flora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008531558}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008531626}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008609009}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2091,"ts_us":1792974008609117}}

data: {"id":"fc1b0574e3ad50e2ae7a15d30f60d535","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":86270,"completion_tokens":2694,"total_tokens":88964,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":84608,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":2160,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2091,"ts_us":1792974008609232}}

data: [DONE]

