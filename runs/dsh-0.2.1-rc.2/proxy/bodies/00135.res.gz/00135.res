data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977886843066}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893656287}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" job"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893755056}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" finished"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893763446}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893763517}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893763572}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893763629}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_fidsk2ctEW4nEIO81Q1n3811","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893807378}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893807476}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893807557}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893823882}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893823959}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893824024}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893824087}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893841250}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893862449}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893862519}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893862572}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893862628}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893862716}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893862782}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893871596}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893871687}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".out"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893871750}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893871811}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893871874}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893871936}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893887579}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893887651}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893887713}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893887772}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893887831}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893887891}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977893904518}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894016961}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017016}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017105}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017179}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017250}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017507}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017569}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017614}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017780}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017851}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894017901}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894018007}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1719,"ts_us":1792977894018078}}

data: {"id":"af097d9211444fdd6937b65279f32836","object":"chat.completion.chunk","created":1792977886,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":513228,"completion_tokens":81,"total_tokens":513309,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5376,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":6,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1719,"ts_us":1792977894018417}}

data: [DONE]

