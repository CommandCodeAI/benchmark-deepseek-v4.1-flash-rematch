data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187827876}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Continue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187877608}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output maybe text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187877759}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187877851}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" viewport."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187942605}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_6fupwvexa9i5spo8kaq0dncd","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187942697}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187942785}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187942862}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187964872}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187965014}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187965181}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187965267}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187973399}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187973585}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187973795}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187977331}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187977518}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187977632}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187977820}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" inspect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975187985479}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188001917}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188002028}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188002168}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188002250}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188002351}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188002407}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188002487}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188002654}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188055291}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188055389}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188055486}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188055533}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188073236}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188073355}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188073511}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188073613}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188080603}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188080777}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" lower"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188080842}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" section"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188080947}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188136926}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" overflow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188137057}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188137131}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6805,"ts_us":1792975188137199}}

data: {"id":"32cb0da27b76d8a57083cdeaf72a174e","object":"chat.completion.chunk","created":1792975187,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":265820,"completion_tokens":82,"total_tokens":265902,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":262144,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":8,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6805,"ts_us":1792975188254678}}

data: [DONE]

