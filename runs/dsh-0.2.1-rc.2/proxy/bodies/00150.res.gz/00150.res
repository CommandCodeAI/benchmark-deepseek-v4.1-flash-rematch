data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978127535170}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128242139}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128455137}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" object"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128476095}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" printed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128476182}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" weird"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128476482}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128476549}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spreading"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128476619}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Node"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128505648}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"List"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128505892}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" entries"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128505958}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128533609}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" irrelevant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128533689}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128534026}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128534099}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-unit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128534167}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mapping"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656395}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656482}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656547}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656608}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Stats"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656668}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656731}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656794}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656853}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656915}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"289"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128656976}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"col"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128657128}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"onies"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128674784}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128674882}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128674946}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128675010}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128675089}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128695517}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128695591}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128695644}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128695830}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128695884}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128717937}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" separated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128718010}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128740610}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128740669}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" block"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128740829}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128740914}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128766601}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128766675}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128777133}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128794962}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128795029}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128795072}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128812064}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128812114}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128812159}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128818880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128818949}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128819011}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128819062}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128834125}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128834183}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128834235}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" early"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128848908}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128865467}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128865531}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128883646}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128883731}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128883858}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128883953}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128907480}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128907557}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128923031}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128923104}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128923154}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" legend"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128934647}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128958826}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128965789}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128965845}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128965892}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" must"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128965939}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128977734}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128977782}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128977849}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Noun"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978128991806}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" helper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129012231}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129012311}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129027021}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129027107}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129064656}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129064719}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129064780}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129064828}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129072281}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129072332}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" break"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129072368}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129086596}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129086662}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129103159}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129103232}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" thing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129103295}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129103344}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129103404}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129118818}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129118889}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129118965}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" catast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129141665}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129187762}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188155}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188209}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188260}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188308}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188355}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" correct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188642}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188691}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129188740}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129203491}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129203564}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129203622}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" correct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129246109}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129246187}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129246244}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129246303}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129246361}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129246417}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129251153}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129251228}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129251289}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129251344}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129267012}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129267092}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129267158}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" left"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129281936}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" census"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129297559}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129314169}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dynamically"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129314243}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129326251}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129326321}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129336979}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129355662}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Great"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129355739}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129383373}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129383470}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129383613}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129383679}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129391638}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129391707}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129414061}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129414124}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129414179}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129417465}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129453327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129453405}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129466518}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129466579}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129466633}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129466679}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129466739}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129484331}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stats"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129484405}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129498656}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129513002}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129552267}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129552346}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129552430}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129552485}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129552537}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129552617}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129559647}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129559705}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129578374}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129593409}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129593488}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colony"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129593539}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129609784}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" holding"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129609866}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129609919}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129622041}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129622119}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129622179}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129622281}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129622343}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129622417}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129643358}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129643437}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129657410}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129657479}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129671178}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sample"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129715121}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129737914}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129737978}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129738030}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129738083}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129746894}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129756527}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129785469}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129795392}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129807050}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129807119}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129807167}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129807216}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129827300}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129827459}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" description"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129857296}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129873080}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129873161}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129894243}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129894322}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129894376}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129894425}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129894635}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129894695}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129923933}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129924021}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129924082}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129924144}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129924357}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129924431}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129962267}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129962354}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129962650}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129962716}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129962778}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129987473}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129987568}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129987633}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129987701}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129987801}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978129987881}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130017097}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130017197}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130017279}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130017367}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130017436}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130017541}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130021929}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130039566}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130039662}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130050744}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" split"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130065143}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" second"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130065261}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130084695}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130097700}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" even"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130097773}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130115671}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scripting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130115743}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130135502}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" B"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130149421}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130172520}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130172586}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130172633}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scripting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130186683}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enabled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130186734}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" don"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130186824}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130201143}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130201240}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nos"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130201296}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130201428}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130201524}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130201596}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130231327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130231392}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130231437}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130231477}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130231523}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130260862}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130260943}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130260987}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130261035}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" style"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130261091}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130261148}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" included"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130261296}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" even"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130261350}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130261389}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130281938}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130282007}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130282052}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130282109}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130282160}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130296845}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130296894}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130309392}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130309468}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130309519}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130309572}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130327150}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130327233}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130327285}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130345285}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" size"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130345340}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130361754}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"460"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130380493}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"KB"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130380550}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130389583}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130389665}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130389733}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" date"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130389776}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130398939}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130399042}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130399150}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" workspace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130414166}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130414216}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130429963}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130430014}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130445126}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130482915}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130483061}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130483154}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130483228}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130494167}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130539238}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130539311}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130539368}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" validation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130539406}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130539449}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130539504}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" functionality"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130566123}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130566226}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130585576}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130585666}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130585717}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130585803}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" logic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130595851}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" broken"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130595908}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130608063}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130608122}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" just"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130608162}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130625455}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130625542}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" manual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130637162}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130664496}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130664566}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130664620}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130668183}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130693770}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130693841}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130693888}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130699747}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130722645}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130739880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130739951}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130757799}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130757883}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130757954}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130758013}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130774523}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deterministic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130774620}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130787704}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130787778}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130802581}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130802646}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130819191}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" call"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130832084}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130850636}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Noun"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130867788}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130875242}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130875321}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130875368}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130889411}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130889501}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130889584}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130889645}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Math"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130908721}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".random"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130908790}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130908846}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" false"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130908900}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130922034}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130922090}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130939827}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130939924}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130939998}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130940070}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130956295}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130956409}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130973025}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130973118}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130973176}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130973253}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130973327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130984611}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130984664}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130999672}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978130999751}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131014040}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131014168}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requirement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131014227}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131014291}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"N"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131029731}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131059420}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131061283}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131077457}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131077512}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131077580}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131077639}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131098288}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131098392}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expects"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131098473}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131112358}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131112421}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131126666}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131154477}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"urable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131154521}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131155486}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" *"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131155538}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131172575}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131172649}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131187155}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"*"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131187227}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131187282}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131205528}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131205615}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131218683}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131218811}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131234334}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131234416}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131234538}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131234599}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131260902}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131260997}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"240"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131261065}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131283357}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131283447}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131299794}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" adjust"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131299888}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131299959}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131338476}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131338581}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131338657}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131338723}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131338795}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131338865}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ends"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131338933}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131370603}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131370703}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131370763}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131370895}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131370948}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131380897}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131380962}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131381010}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131395535}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131395599}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131395694}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131395747}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ty"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131409930}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131409977}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131410013}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131410049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131425120}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" phrase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131425169}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131452222}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"r"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131452308}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"uns"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131458390}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131458469}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131458527}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131482684}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131482767}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131482818}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131482869}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131482928}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131483014}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" imply"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131502023}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131502126}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fixed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131502187}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131512037}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131512111}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131525119}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" variable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131525176}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131536888}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131536964}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" continuous"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131550577}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" running"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131567526}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131567589}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131582453}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131582496}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131582543}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131608834}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131615353}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131615421}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131630275}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131630379}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131630484}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" finish"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131630538}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131644957}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131645008}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".st"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131659818}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131677350}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131677445}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131692216}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131692269}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131708410}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131708458}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131708500}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131725037}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131725087}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131725122}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131725162}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131725204}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131739046}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scheduled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131739096}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131754622}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" applied"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131754681}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" automatically"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131771146}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131771214}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131786246}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131786293}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131786375}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131802353}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131802423}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131802491}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sample"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131802544}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131817918}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131835277}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131850087}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" waits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131850131}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131866636}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131866694}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131882913}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131882987}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131883039}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131883095}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131883168}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131899645}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pre"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131913143}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"fers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131913271}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131935793}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131935847}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"che"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131935883}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"me"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131935922}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131935957}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131936001}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131943546}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131961058}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" theme"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131984663}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131984721}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131984781}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131984868}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978131984952}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132002227}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132002277}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" comments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132024242}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" documenting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132024296}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132024362}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132034863}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" def"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132045904}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132058933}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132059006}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132059060}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132059098}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132073628}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132073713}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132073781}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132085851}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132085954}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132086038}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132086117}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132125128}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132125177}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" long"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132125269}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132125340}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132133282}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132149880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132149965}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132150056}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132150121}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132150162}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132166849}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" assessed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132166931}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132166981}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132167052}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" human"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132205755}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" who"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132205844}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" opens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132205911}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132215420}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132215486}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132215547}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132235888}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132235954}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132236010}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132246992}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132247097}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132247148}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132247205}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132262609}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132262687}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132262744}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132277253}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132277335}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132277394}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132277482}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132294966}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132295063}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132295122}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" analysis"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132307344}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132325919}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132326000}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132341839}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132341899}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spacing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132341956}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132359889}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132359964}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132360005}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132360073}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132372494}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132372568}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132372622}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" metrics"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132389985}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132390085}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132403092}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132403168}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132420032}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" twe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132434530}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132434648}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132434710}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132434757}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" thing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132451040}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132451108}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132451162}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" improve"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132465943}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132466017}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132485701}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132485778}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132497588}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132519396}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132583632}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-left"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132583716}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132583781}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"L"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132583963}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"IVE"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132584053}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ·"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132584168}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132584236}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"045"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132584321}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132602328}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132602430}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132602506}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" static"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132602564}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132618584}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132646290}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132646398}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132668110}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132668179}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"9"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132668219}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132687442}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132693744}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132693802}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132693880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132708539}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132708592}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132708635}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"11"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132723717}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132723791}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132723846}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132723889}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" left"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132723935}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132723993}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132745724}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132745794}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132745835}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132745906}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132764683}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132764726}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132764789}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" decorative"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132783915}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132784110}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132784164}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132784241}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132803796}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132803866}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" y"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132816056}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" around"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132816117}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132828522}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"156"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132828579}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132828624}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132828670}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132843995}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132844075}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132844137}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132844190}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132844250}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132861453}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132861532}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" right"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132861581}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" co"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132874814}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ords"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132890973}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132891066}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132907184}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"11"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132907264}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132922365}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132922430}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132938366}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" right"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132938439}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132938528}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132938574}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132938621}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132938649}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bottom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132953918}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132953985}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"UD"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132969307}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132969354}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132969404}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132969482}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132969536}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132969594}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132991077}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978132991132}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133004987}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133005057}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" center"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133005110}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133017102}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133032786}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133032835}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133032892}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" collisions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133048150}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133064632}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133086122}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133104072}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" detect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133104158}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133104213}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133145878}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133145926}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133146001}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133146058}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bottom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133146110}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133146250}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133146303}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"inals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133168730}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133168799}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133168859}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133190494}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" list"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133190542}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133190681}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133190734}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133219487}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133219575}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133231545}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133231595}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133244403}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133244459}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133244507}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133259991}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133260052}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133273708}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"UD"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133273771}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133273813}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlapping"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133287310}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133332764}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133332845}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133332896}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133332932}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133332972}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133333025}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133333077}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133333111}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133336466}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133351850}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133367608}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133367656}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133367696}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133367731}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133367767}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133391249}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133391304}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133391378}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133391441}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133412684}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133412745}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133426745}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133426798}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133426833}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133426880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133449917}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133449994}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":").\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133450048}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133450088}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Great"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133450138}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133456802}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133456875}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Over"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133456928}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133473602}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" between"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133473653}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133473695}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133501081}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-status"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133501162}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133503539}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133518864}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133536955}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133537049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133537121}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" badge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133550745}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133569941}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133570068}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133570142}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133583326}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133583404}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133583471}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133600479}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133600568}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133600635}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133600696}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" brand"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133619612}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133619699}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133637217}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133637329}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133637398}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133637465}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Footer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133637524}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133645595}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" frame"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133668572}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133691245}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133691300}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133691354}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133709468}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742222}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742292}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742346}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742401}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742485}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742538}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742597}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133742659}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessibility"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133760373}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133760477}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133760522}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rud"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133806697}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"imentary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133806754}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" audit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133806809}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133806863}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133806914}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133806964}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133817316}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133817364}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133834406}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133849627}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133849678}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133849733}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Play"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133849786}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133865404}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133865530}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessibility"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133865616}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" snapshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133865662}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978133865716}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Dep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134014886}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"recated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134014935}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134014970}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015011}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".access"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015050}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ibility"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015084}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015123}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015158}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015196}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015230}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015265}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015299}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015338}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" loc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015469}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ator"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015536}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".e"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015574}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"valuate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015658}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015696}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015747}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015804}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015883}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015933}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Manual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134015987}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" checks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016050}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016099}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016144}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016274}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016329}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016410}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016513}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016554}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" support"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134016594}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mouse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134036055}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wheel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134042851}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134042898}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134058046}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" required"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134058096}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134058153}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134058203}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134058239}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134075516}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inputs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134075575}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134093088}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134093149}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134112627}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" keyboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134123561}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" arrow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134136682}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issues"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134136740}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134150245}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134150295}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134150348}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ste"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134150416}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134174034}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134174089}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/min"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134183508}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"us"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134183581}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134183635}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134183685}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134183733}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" switch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134199142}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134199221}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134199271}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134199320}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134216274}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"led"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134216324}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134216378}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134216425}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134216460}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Enter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134216498}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134229591}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134229639}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134229690}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134242962}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134243029}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134243069}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134243114}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134259078}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134278156}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134291023}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134291104}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134327808}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134327867}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134342617}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134342672}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134342731}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134342783}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134358340}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134372964}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134373049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134373115}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134373161}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134373274}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134388913}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134388992}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134389049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134408739}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" decorative"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134408801}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134444394}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134444442}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134444489}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134444532}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134459010}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134497369}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134497445}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134497488}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134497531}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Press"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134497573}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134497611}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134497660}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134506248}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134506292}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134532536}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134532600}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"les"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134532640}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pinned"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134536574}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134536650}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pressing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134536705}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Escape"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134554273}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hides"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134554329}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134570754}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134570801}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134570870}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134570940}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134570989}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134583915}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134583977}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134584020}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cover"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134602583}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134615656}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intercept"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134615737}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134632572}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134646791}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pointer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134646853}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-e"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134663838}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"vents"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134663905}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" none"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134663957}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134664015}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134664064}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134664100}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134687187}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134687237}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134687287}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-exp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134705029}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"anded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134705101}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134705150}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134721480}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-described"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134721559}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134721615}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134721654}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134721703}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134732404}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134732473}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134732537}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" help"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134732597}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134732657}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134745055}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"role"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134745103}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134745157}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134764251}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134764317}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134764364}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134764415}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134764459}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134764515}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134779896}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134780000}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134780101}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134817336}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" near"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134817413}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134817460}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pointer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134817520}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leaves"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134817566}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hides"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134825982}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unless"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134836135}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pinned"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134852384}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134852445}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134852492}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134852545}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Keyboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134852590}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134852650}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134872807}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134872912}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134884966}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134885028}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Great"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134885063}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134885106}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134885152}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134885258}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ring"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134902023}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134902080}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134917058}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134917116}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134932084}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" global"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134950750}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" outline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134966593}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134966664}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134966714}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" offset"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134982569}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134982619}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978134999103}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135036047}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135036124}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135036180}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135036259}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135036345}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135041677}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135057425}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135057506}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135057564}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135057619}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135074261}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135074315}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135074353}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135074392}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135089076}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135089156}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135089229}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Number"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135089299}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135107011}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135107082}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135107202}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135107252}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Switch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135107294}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135141652}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oggle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135141733}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" global"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135141793}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135141843}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135141884}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135141923}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135153745}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135153841}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135153915}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135153981}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135167675}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135183796}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135183863}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135183908}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135198728}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135198812}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135198869}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135198919}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135230759}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135230818}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135230870}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135230940}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135240188}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135240247}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135252018}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135252094}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135267701}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135281446}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135281536}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135300852}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135300937}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135301006}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135325759}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135325854}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135330292}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" desktop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135340093}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135358527}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135358612}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135358683}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135372562}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135372654}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135386755}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135386843}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135403684}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135403782}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135403853}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135418514}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135433993}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" status"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135449996}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135466497}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135487029}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135487126}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135499499}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135499600}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135499701}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fol"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135528558}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"io"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135528657}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135528731}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135543065}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135543150}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135547790}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135547933}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" play"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135567745}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135582304}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" conclude"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135594276}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135624782}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instruments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135624910}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" collapse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135624983}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135644676}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135644748}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135664036}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135678204}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135678277}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135691387}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135691491}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" most"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135703899}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" logical"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135703972}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135718254}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135718341}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"play"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135718401}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/con"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135734718}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"clude"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135756362}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135756439}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instruments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135756494}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135756534}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135771271}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135771354}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135771405}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" puts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135788976}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" transport"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135805587}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135816285}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135816352}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135829125}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135829173}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135829249}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135829299}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135845730}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135845781}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135845848}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135845905}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135875892}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135875950}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135876001}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135876048}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135892149}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" buttons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135908422}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135940818}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135940880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135940938}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135940990}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135941028}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135954160}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accepted"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135954210}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135970481}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135970547}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135987434}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135987522}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135987592}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" HTML"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978135987677}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136002173}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136002231}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136002283}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136020373}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"theme"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136020492}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136020550}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136020597}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136039071}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136039139}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136039186}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136053289}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136053352}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136053404}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136053507}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136082993}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136083062}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136083113}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136083167}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" icons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136083211}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136124373}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" buttons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136124462}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136124536}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136124592}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136134640}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" brand"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136134710}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136134776}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136153110}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136153192}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136153293}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136153364}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136163040}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136163131}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136192975}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" parent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136193059}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spans"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136207841}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136207951}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136253194}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136253286}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136253343}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136253387}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136253434}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136253486}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136253527}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136255809}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136255853}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136285883}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136285973}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136286035}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136286099}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136324568}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136324651}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136324705}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136324748}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136324800}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136324841}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136324882}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" def"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136334343}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136351113}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136351156}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136351224}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453019}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sr"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453076}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453136}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453216}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453293}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"g"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453342}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453403}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453469}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453516}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453549}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453598}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453633}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453754}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453804}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" valid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453915}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136453962}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136472380}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136472431}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136472502}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" class"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136472545}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sr"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136503321}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136503369}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136503419}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136503468}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" clip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136503503}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136503539}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136516559}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136516620}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" problem"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136528482}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136528524}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136540919}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136540976}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136541030}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" references"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136557406}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136557485}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136557548}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" symbols"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136575721}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" referenced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136589426}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136589471}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136606000}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136606051}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136632778}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136632823}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136642129}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136642261}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136664068}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136664123}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136664172}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136678134}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136678190}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" href"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136678247}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=\"#"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136678298}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136678356}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700246}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700301}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\">"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700477}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700551}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700618}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700678}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700740}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136700788}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136717267}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sprite"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136717315}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" itself"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136732449}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136732504}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136746600}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136763034}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136763101}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136763142}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136778019}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136778078}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136778126}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136778195}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=false"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136794126}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136794192}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136794235}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136794313}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136794361}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Some"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136794409}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136810228}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136810292}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136810351}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" elements"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136829327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136829377}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136848396}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136864980}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136865046}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136865088}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" old"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136875590}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" IE"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136889895}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136908322}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136921948}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136940779}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136940851}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136940906}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136940963}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" icons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136941005}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136974234}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136974306}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136974364}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136974480}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136974539}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136974572}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136989420}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978136989472}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137005087}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"role"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137005134}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137021984}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"img"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137022050}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137022095}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137022141}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137022185}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137035035}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137049651}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137049708}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137049755}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137049903}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137049958}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"als"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137066095}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137066178}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137086811}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137086891}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137086941}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137109872}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137130599}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137130649}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137130730}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137130784}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137149916}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137171618}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137171666}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137196663}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137196755}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137196804}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" region"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137215614}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137233361}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137233411}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137233466}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ann"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137233511}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oun"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258205}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258282}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258330}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"role"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258395}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258521}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"status"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258579}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258612}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" outside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137258659}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137278370}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137288461}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137288512}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137304067}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137322718}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137322797}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ert"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137335745}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137335788}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137351991}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137352039}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137362713}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inert"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137362785}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137381061}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137381118}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ann"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137381217}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oun"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137403229}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137403312}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" outside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137403369}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137418964}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137419038}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137419092}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137419141}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137419203}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137426466}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" region"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137426531}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137447761}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" updated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137465752}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137465798}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137465858}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137477166}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"30"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137477254}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ms"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137477308}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137477351}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137504544}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137504604}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137512611}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137512658}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137512714}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137512755}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" heading"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137512816}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" structure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794078}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794131}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794174}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794223}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794265}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794304}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794351}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794389}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794439}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794475}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794507}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794552}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794618}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794714}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794779}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794848}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794901}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137794972}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795021}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795071}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795106}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":").\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795146}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795179}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795219}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795255}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795307}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" section"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795457}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795506}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795558}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795634}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795673}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795752}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795819}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" headings"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137795957}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796000}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796040}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796106}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796170}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796222}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796270}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796384}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796450}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796519}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" section"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796565}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796615}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796724}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-lab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796777}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"elled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796844}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796895}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796930}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"spec"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137796969}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"imen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797011}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797108}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797152}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" references"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797210}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797295}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797352}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137797491}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137822943}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137840867}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137840922}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137840970}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902169}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902222}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902294}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902372}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902431}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fol"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902507}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"io"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902545}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" section"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902592}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902632}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-lab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902673}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"elled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902712}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902827}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902893}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902937}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137902974}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137915288}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137915364}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137915424}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137928458}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137928504}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137928549}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137928593}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137928637}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137942334}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137942395}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"struments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137962292}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137962355}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137962418}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-lab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137981051}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"elled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137981132}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137981195}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978137981252}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138000916}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138000989}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138001051}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138001133}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138001258}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" role"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138001301}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dialog"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138026288}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labelled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138026350}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138026396}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138043592}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138043660}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138043733}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138043789}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138043839}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138058640}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138058683}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138070262}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138070318}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138093812}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138093863}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138093936}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138094017}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138094079}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138101045}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138114875}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138114930}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138114985}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138125365}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138125423}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138125481}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138125535}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138142531}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138160895}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138179417}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" always"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138179479}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138179528}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138204049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138204139}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138204197}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138206864}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138206929}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138221448}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138237682}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138237784}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" none"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138252786}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138252871}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138252918}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138268682}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tree"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138268753}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138285045}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138285118}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138285161}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138285282}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138302510}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" points"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138302586}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138316049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138316099}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138334575}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138334658}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138348172}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138348265}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JavaScript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138348339}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intercept"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138364682}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138379270}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138379351}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138379418}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138397273}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" disabled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138397360}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138397428}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138414694}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138433211}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fails"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138433327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138453381}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138453478}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138471447}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138482766}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138520365}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138520468}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138527141}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138527210}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138527263}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138527317}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138527370}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138544858}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drawer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138544932}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" modal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138553953}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" role"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138577032}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" applied"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138577102}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138594645}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" open"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138594709}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138594765}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138607354}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inert"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138607407}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138621671}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138621760}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138621824}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138621890}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138621942}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138621997}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138636591}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" modal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138636636}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138652491}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138652550}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138652591}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138652637}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138652692}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-modal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138666933}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138667020}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138667086}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138667132}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fixed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138686197}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138710324}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138710422}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740347}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740440}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740498}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740572}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740625}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740686}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740726}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138740761}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138751654}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138771168}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ID"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138771222}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" duplicates"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138785987}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138786068}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138803783}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138803840}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" help"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138871708}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138871775}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138871816}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138871861}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138871904}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138871970}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" All"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872037}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ids"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872093}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unique"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872146}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872195}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872248}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872289}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" duplicates"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872451}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872488}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138872521}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138894327}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" quick"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138894387}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138894503}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138939713}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_NwWTg3ev0DMJZ62VYWl87387","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138939848}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138957634}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138957692}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138957757}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138957826}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978138957880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025445}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025514}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025618}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025671}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025721}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025775}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025810}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139025864}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026008}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026068}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026185}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"parser"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026242}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026298}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" HTML"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026362}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Parser"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026464}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139026522}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139047817}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" collections"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139047883}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139047943}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" Counter"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139048017}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139048086}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"class"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139048152}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" P"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139093636}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139093705}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"HTML"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139093755}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Parser"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139093806}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"):\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139093875}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" def"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094010}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" __"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094146}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"init"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094242}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094324}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"self"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094397}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"):"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094484}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" super"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094565}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"().__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094757}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"init"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094850}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094900}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139094968}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" self"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139095037}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139095086}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139111875}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=[]\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139111941}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" def"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139111992}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" handle"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112060}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"_start"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112138}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tag"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112206}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(self"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112311}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":",t"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112364}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ag"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112412}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112474}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"attrs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112525}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"):\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139112563}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179265}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179322}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179373}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"dict"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179426}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179464}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"attrs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179511}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179638}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179685}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179749}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179799}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"id"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179836}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139179883}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180007}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180049}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":self"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180101}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180157}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180212}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".append"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180262}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180418}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180473}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"id"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180525}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'])\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180577}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180627}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=P"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139180670}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139186277}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139186343}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139203203}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"eed"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139203291}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139203379}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139203456}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139203521}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139203565}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139220577}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139220710}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139220813}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139220926}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139221031}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139221142}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"());"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139237881}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139255007}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139255070}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Counter"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139255114}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139255196}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139255275}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139255337}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139264282}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139280018}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139280095}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139280149}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139280215}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139280281}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139280336}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139298948}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139299004}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139299045}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139299111}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"du"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139299167}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pes"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139299209}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139311808}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139311877}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139311939}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139311990}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" k"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139328500}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":",v"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139328557}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139328610}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139328672}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".items"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139328725}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139330584}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139343704}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139343755}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139343806}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139343854}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"])\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139343907}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139343971}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139359403}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"total"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139359462}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" elements"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139359511}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139374498}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139395321}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139395379}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139395427}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139395554}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139414686}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139414733}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139414780}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139414822}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139414889}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139414939}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139432209}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139432265}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139432307}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139432373}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139432441}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139432504}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139450478}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139450593}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139450656}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139450706}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139450758}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139450914}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139470954}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139471041}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139471102}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139471169}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139471235}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139471279}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510145}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510238}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510314}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510456}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510519}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510581}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510676}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510894}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139510999}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".random"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139511158}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139530375}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139530478}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139530526}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139530579}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139530631}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".random"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139530686}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139551566}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139551649}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"network"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139551712}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" tags"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139551775}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139551900}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139551977}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139577003}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139577093}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"link"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139577161}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139593348}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139593428}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139593496}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139593586}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139593661}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139593719}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139603769}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139603910}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fetch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139603965}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139620463}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139620514}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139620591}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139620663}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fetch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139620708}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657138}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657216}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657288}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657332}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657411}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" bytes"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657463}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657515}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139657567}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139663799}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139663876}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139663944}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139664008}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"end"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139664070}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"swith"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139677443}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" </"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139700237}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139700301}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139700361}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139700430}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139700488}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".r"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139706563}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"strip"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139706626}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139706671}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"end"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139706699}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"swith"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139707602}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139707647}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"</"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139739679}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139739766}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139739836}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'))\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139739913}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139739961}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139740470}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139754801}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139754880}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139754936}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139754988}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139755063}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139773374}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139773431}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" duplicate"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139773469}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" IDs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139773522}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139773549}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139787188}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" constraints"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139787265}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139806947}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1672,"ts_us":1792978139807025}}

data: {"id":"ed144ef6494f018c0fb3b0b122017114","object":"chat.completion.chunk","created":1792978127,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":546764,"completion_tokens":1952,"total_tokens":548716,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":546304,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1669,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1672,"ts_us":1792978139843505}}

data: [DONE]

