data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978222637116}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223261985}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223378240}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kill"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223395258}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223395359}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223395438}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" killed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223412525}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" itself"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223412617}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223412693}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223412767}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" returned"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223412842}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" killed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223425470}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223425558}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" signal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223425624}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SIG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223425686}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"TER"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223442657}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223442794}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223442877}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223442953}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223443007}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223469771}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223469839}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kill"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223469933}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223469975}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"f"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223475309}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223475382}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" matched"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223475435}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223475484}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223475536}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223491158}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" string"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223491240}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" itself"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223491362}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" including"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223491398}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223523586}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223526068}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223526162}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223526252}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223526339}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223539486}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223539580}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223539653}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" killed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223555430}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223555495}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shell"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223555544}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223555587}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223593755}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" node"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223593817}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" process"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223593865}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223593928}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223593964}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stopped"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223594006}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223603334}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223603407}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223603480}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_ph9nXrP6Ou0JsKJlDGe10985","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223654780}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223654864}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223654927}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223668713}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223668801}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223668873}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223668936}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pg"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223683866}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223683948}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223684025}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"af"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223684092}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223684138}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223684195}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223705666}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223705743}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223705792}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223716802}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223716884}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"inux"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223735006}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223735063}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223751142}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223751190}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223751270}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223751370}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223751452}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223751503}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223764621}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223764698}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223764756}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223764808}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223764861}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223781381}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223781457}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223781529}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223781611}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223781671}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223781736}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223797172}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223797256}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223797348}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223797444}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223862589}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223862661}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223862714}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223862783}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223862842}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223862895}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223862997}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863084}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863148}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863200}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863280}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863354}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863456}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863527}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863594}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863709}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863778}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863899}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223863967}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223864032}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223864094}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223864156}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223864215}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223878338}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223878411}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223878478}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223878564}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223878631}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223878697}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223893957}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223894035}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223894095}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223894156}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223894215}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223910867}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223910969}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223911041}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223911111}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223911163}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223930804}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223930875}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223930926}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223942622}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223942683}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223942791}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223966110}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223966216}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223966306}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Ensure"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223966406}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" no"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223972911}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223972996}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" process"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223973074}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" left"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223990377}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" running"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978223990455}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978224005372}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2831,"ts_us":1792978224005460}}

data: {"id":"cc6395f70bc33776d68e4c9646aedee6","object":"chat.completion.chunk","created":1792978222,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":574402,"completion_tokens":185,"total_tokens":574587,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":574208,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":53,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2831,"ts_us":1792978224040746}}

data: [DONE]

