data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776083551}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776127743}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final review of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776127823}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation architecture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776127879}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776199884}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism and UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776199943}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's inspect engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776199994}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776200739}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" any use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776270241}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of wall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776270321}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clock/M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776270377}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ath.random,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776270434}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI mut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776356202}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ating."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776356271}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We know"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776356350}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" none. But render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776356865}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er drawing no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776557914}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim mutations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776558001}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776558074}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It calls this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776558144}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".sim.plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776672105}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776672373}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776672431}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" agent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776673204}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heading"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776688597}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". No modifications"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776688677}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n- However"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776688787}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `_"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776688881}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776704346}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"History"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776704403}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` and stats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776704454}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are deterministic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776704504}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The `sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776777988}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776778042}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776778096}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe` callback is set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776778272}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776841409}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI function that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776841632}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does DOM and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776841813}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776841877}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"this.draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776942103}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776942163}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"itals` but no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776942200}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim mutation. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976776942392}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Could rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777083754}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777083821}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"sim.active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777083871}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Effects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777083925}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777110719}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777110965}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- Same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777111024}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777111082}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same config yields"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777179471}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same run. Yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777179641}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- But UI's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777179737}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777179867}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls apply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777265088}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777265218}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time; if a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777265389}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user starts a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777265491}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run and changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777331460}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nothing, same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777331737}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777331806}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yield identical. The seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777331884}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777405222}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" apply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777405352}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" triggers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777405392}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777406039}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777484775}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777484834}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777484920}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utationRate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777484984}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777577566}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set by `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777646256}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"syncControls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777646306}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FromState` at start;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777646391}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine created"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777667313}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777688385}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". After"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777688424}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start, syncControls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777688479}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls engine.set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777749927}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"MutationRate etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777806972}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777807027}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777807095}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777812427}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777812706}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval sett"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777812749}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ers? sync"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777812985}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ControlsFromState doesn't call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777931514}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setEvent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777931624}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Interval! It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777931703}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updates display"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777931848}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777965150}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777965341}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Engine was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777965431}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" created with intervals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976777965618}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". good. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778050051}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778050133}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updateMutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778050234}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UI ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778050313}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778153804}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"MutationRate, food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778153885}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778154153}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778154223}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FoodUI does not set engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778225113}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778225204}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine created with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778225275}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food. speed UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778227926}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778305303}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778305391}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophe state engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778305459}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" created."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778305527}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- `start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778369395}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Run` called with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778369485}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778369552}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" settings."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778369621}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- At start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778478514}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778478578}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778478628}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778478678}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".setGener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778574961}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations(n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778575029}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")`? No, engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778575084}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" created with generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778575137}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- After"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778639465}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `syncControls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778639629}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778639757}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval inputs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778639843}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778670052}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Initial schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778670123}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778670269}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good.\n- On seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778670324}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778761413}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", startRun"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778761492}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses intervals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778761637}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778761831}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ood/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778886501}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778886569}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778886729}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG state after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778886789}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778941557}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778941678}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sequence; UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778941864}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976778942062}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779082577}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- Same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779082635}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779082779}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779082830}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779108379}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default (no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779108483}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779108798}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779108861}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779182394}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779182457}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI passes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779182549}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779182688}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779262711}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"04 (4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779262756}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%), food28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779262908}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", intervals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779263051}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779340666}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779340756}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Enabled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779340863}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Engine defaults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779340920}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779422330}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779422596}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779422633}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779422810}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779502015}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explicit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779502082}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Should produce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779502510}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical history."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779502593}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's verify by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779593589}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" comparing the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779593685}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779593726}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779594014}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations to run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779687753}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless same options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779687816}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779687939}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can expose sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779688008}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779773881}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"istory at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779773984}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779774141}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g. 20 via page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779774184}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evaluate,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779891396}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compare Node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779891441}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779891497}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779891552}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779943356}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless and compare current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779943466}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim history."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779943604}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976779943649}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780029237}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_kqf0o0ltqkkg1knwgsw0t4m6","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780029310}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780029359}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780029401}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051558}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051681}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051732}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051779}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051818}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051857}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051908}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780051970}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780057213}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780057401}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780057449}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780057581}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780072805}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780072881}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780072944}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780073074}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780073160}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780073234}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780073463}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780073512}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780093249}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780093377}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780093514}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780093623}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780112069}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780112187}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780112481}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780112593}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780135086}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780135206}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780135313}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780135382}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780155877}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780156065}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780156124}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780156241}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780157766}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780157840}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780157992}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780158046}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780180267}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780180386}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780180557}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780180613}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780200471}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780200580}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780200679}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780200799}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780200881}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780200951}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780201019}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780201085}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780238383}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780238540}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"unch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780238587}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780238704}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252212}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252318}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252404}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252487}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252567}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"args"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252643}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252868}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780252956}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"--"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780257011}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780257094}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780257164}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780257234}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780307959}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780308051}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780308146}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780308338}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780308589}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780308680}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780308956}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780309040}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780315615}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780315699}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780315782}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"viewport"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780315859}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780334833}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780334920}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780335156}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780335240}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780336112}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780336201}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780336284}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780336362}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780392696}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780392950}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780393057}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780393196}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412151}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412237}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412337}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412387}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412504}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412598}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412672}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780412827}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780420579}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780420656}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780420774}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780420837}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780442137}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780442221}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780442372}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780442444}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780442538}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780442594}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780442693}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"400"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780443718}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780453685}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780453805}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780453912}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780454061}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780462005}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780462107}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780462273}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780462327}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780472778}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780472831}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780472872}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780473628}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780498228}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780498297}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780498372}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aused"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780498447}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780525210}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780525261}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780525319}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780525436}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780539308}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780539395}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780539440}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780539579}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780540516}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780540574}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780540640}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780540696}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780555645}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780555753}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780555814}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780555962}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780592806}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780592897}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780593062}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780593437}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780620776}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780620829}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780620892}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780620945}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780635644}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780635874}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780635960}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780636069}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780662643}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780663573}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780663636}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780663707}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780760982}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780761035}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780761100}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780761158}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780761799}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780761844}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780762063}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780762114}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780762638}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780762834}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780762875}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763001}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763053}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763297}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763366}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763416}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763637}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763815}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arden"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763870}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780763981}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780764033}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780764077}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780764242}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780764291}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780772000}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780772103}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780772244}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780772337}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854218}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854300}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854359}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854457}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854596}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854678}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854784}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780854896}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mutation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780855995}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780856069}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780856139}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780856220}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780858562}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780858619}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780858711}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780859678}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872180}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872287}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872402}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872641}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872726}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872797}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872855}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780872911}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780886857}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780886914}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780886978}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780887096}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catastrophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780906830}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Enabled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780906884}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780906970}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780907164}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780924186}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780924264}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780924342}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780924510}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780924744}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Enabled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780924868}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780925023}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" intervals"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780925112}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780949497}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780949574}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780949639}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".inter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780949693}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vals"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780968616}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780968968}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780969055}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ui"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780969139}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780985111}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780985170}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780985431}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976780985486}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781032134}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781032187}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mismatch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781032231}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781032418}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781032691}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781033051}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781033115}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781033171}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781049758}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781049840}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781049912}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781049965}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781066795}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ui"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781066849}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781066976}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781067074}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781083876}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781084005}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781084102}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781084199}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781108949}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781109002}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781109141}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ui"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781109201}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781131638}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781131728}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781131805}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781131906}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781131966}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781132045}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781132141}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781132225}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781150675}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781150735}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781150799}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781150868}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781170170}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781170257}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781170352}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781172509}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781216629}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781216696}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ui"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781216748}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781216797}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ui"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781217331}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781217398}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781217454}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781217547}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258138}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258193}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258258}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258341}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258582}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258689}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258760}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"break"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781258878}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781266700}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781266775}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781266833}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781266912}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781357174}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781357246}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781357339}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781357415}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781359088}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781359187}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mismatch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781359269}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781359463}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781362241}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781362355}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781362518}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ui"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781362568}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781375086}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ui"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781375161}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781375271}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781375364}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781402175}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781402231}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781402316}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781402397}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781437818}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781437883}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"H"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781437986}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781438051}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781481684}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781481775}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781481849}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781481944}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781482077}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781482147}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781482209}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781482758}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781488818}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781488920}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781489060}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781489117}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781491761}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781491844}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781491904}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781492017}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781500839}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781500952}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781501036}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781501241}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781535884}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781535974}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781536032}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781536152}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781536261}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781536358}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781536412}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781536834}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781540955}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781541011}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781541070}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781541121}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781556312}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781556369}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781556440}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781556533}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781575566}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781575649}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781575715}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781575883}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781606721}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781606838}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781606929}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Compare"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781607138}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" UI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781639221}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781639350}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781639555}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781639625}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" histories"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781693746}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781693859}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7869,"ts_us":1792976781693922}}

data: {"id":"4c7d00885c0bf6b4df69966fc2c0fb1c","object":"chat.completion.chunk","created":1792976775,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":419418,"completion_tokens":868,"total_tokens":420286,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":418304,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":455,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":7869,"ts_us":1792976781701503}}

data: [DONE]

