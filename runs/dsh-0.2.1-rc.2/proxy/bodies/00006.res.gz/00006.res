data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720779179}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720814772}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" py"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720814830}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ftsubset output means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720814961}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unavailable. Could pip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720907779}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" install fonttools? Network"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720907920}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe, but not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720908083}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needed. We can use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720908142}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720986516}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fonts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720986650}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at runtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720986734}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973720986876}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721064896}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we embed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721065025}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" O"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721065096}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"TF "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721065163}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"591"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721140175}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721140219}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721140310}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" base64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721140356}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721248542}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can subset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721248591}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" using font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721248659}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tools pip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721248722}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" install if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721836687}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network available."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721836812}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But user specifically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721837009}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"no external"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721837405}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" libraries or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721859099}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network requests\" refers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721859188}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runtime, not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721859396}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" development."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721859460}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Still,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721880181}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" embedding "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721880399}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721880576}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fonts may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721880646}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inflate."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721893214}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could fetch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721893368}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721893509}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from web"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721893560}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at dev"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721906546}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721906647}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721906708}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not allowed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721906825}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721921386}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have web tools and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721921745}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721921803}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curl. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721921906}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local fonts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721940475}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can suffice."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721940606}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use system"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721940731}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stack."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721940802}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In Chrom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721962701}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ium screenshot,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721962756}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721962797}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arter\" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721962834}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resolves via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721980972}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fontconfig"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721981028}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721981077}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Bitstream Charter when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973721981114}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722019912}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722019974}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Charter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722020126}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722020761}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Bitstream"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722074603}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Charter\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722074925}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722074973}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Inter and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722075015}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" JetBrains Mono are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722222612}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" installed. Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722222662}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722222720}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722222934}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722235579}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user environment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722235667}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely Windows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722235752}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722235802}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ac: fall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722307084}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back Georgia,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722307141}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Helvetica,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722307252}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Courier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722307395}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722381932}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Reason"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722382013}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able. Maybe embed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722382110}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" WO"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722382253}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FF2 conversion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722486454}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722486567}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722486607}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tools from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722487340}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722528229}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722528295}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s see pip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722528350}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722528383}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constraints"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722613862}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" don't mention"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722613948}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722614006}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" size."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722614094}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Base64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722680320}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Inter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722680396}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722680472}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Charter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722680551}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859398}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" JetBrains could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859477}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be ~250"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859541}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859586}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". WO"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859700}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FF2 compression"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859763}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859834}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could select"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722859874}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973722908808}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" subset for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723038258}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ASCII and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723038314}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" symbols"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723038376}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" used"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723038457}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723038512}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would take"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723038553}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723038622}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723056172}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consistent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723056282}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723056511}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723056598}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tools `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723144452}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pip install"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723144510}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fonttools bro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723144619}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tli` possibly network?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723144778}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723240284}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" installed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723240354}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" packages, pip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723240413}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723240487}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xpx2nnt5d89ammss5pnmawr9","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723316117}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723316187}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723316317}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723316398}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723326781}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723326833}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723326968}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723327075}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723327227}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723327410}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723327587}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723327740}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723334439}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723334516}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723334574}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723334649}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723346785}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723346840}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723346934}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"li"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723347005}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723347063}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723347118}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723347174}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723347209}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723413591}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"li"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723413658}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" yes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723413711}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723413758}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"except"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723416524}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Exception"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723416636}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723416685}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723416911}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723417106}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723417544}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723417590}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723417639}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723419032}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"li"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723419079}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723419125}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723419200}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723467239}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723467321}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723467377}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723467426}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723467620}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723467698}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723467864}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723468018}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723469711}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723470206}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723470269}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723470736}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" yes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723476469}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723476520}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723476552}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723476711}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723477894}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723478097}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"except"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723478144}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Exception"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723478434}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723498917}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723499010}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723499084}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723499137}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723546532}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723546614}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723546670}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723546957}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723547038}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723547096}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723547142}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723547194}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565100}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pip"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565180}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565261}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565332}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565414}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565518}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565576}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723565684}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723593891}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723593971}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723594123}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723594976}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723617531}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723617616}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723617687}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723617809}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723629453}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723629517}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723629572}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723629691}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723691998}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723692086}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723692157}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"li"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723692267}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723738781}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723738856}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_uqbjljmk3nxs5aufax4sodzy","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723739008}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723740149}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723754213}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723754334}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723754450}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723754502}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723786084}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"curl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723786390}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723786447}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723786496}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723786897}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723786983}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723787088}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723787691}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723795925}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723796243}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723796330}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723796402}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835268}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835344}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835387}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835440}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".com"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835551}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835613}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835664}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723835724}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723849528}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723849599}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723849646}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723849719}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723884168}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723884255}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723884322}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723884466}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723907140}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723907227}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723907364}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723907608}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723994666}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" network"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723994750}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" availability"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723995228}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973723995313}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1986,"ts_us":1792973724017399}}

data: {"id":"b24a06380ff5fd17114e4c88bbe40e42","object":"chat.completion.chunk","created":1792973720,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":44091,"completion_tokens":468,"total_tokens":44559,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":9856,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":267,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1986,"ts_us":1792973724017524}}

data: [DONE]

