data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247664117}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Continue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247749524}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247749583}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8gin8wf4v5xfo0440h8srjst","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247750031}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247750114}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247750173}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247750224}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247751052}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247752590}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247752672}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247752915}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247752991}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247774595}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247774944}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247775002}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247775356}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809307}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" inspect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809374}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809422}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809481}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809589}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809658}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809705}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247809791}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247824110}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247824209}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247824314}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247824407}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247837825}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247837921}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247837992}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247838054}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247878757}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247878853}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247878923}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247878999}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247881613}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247881711}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247881865}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247881913}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247893005}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247893098}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247893150}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" remaining"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247893306}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" control"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247914927}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sections"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247915062}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247915109}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5083,"ts_us":1792975247915217}}

data: {"id":"99db4c17c3f1c8f04712f820bd27fb9a","object":"chat.completion.chunk","created":1792975247,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":274379,"completion_tokens":82,"total_tokens":274461,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":270848,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":2,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":5083,"ts_us":1792975248012454}}

data: [DONE]

