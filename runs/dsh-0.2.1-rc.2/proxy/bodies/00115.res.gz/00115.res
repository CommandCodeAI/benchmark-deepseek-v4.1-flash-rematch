data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388193007}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388249676}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSearch for other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388249770}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" common"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388249836}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" typos:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388349455}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388349526}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"sp` used anywhere"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388349570}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" incorrectly?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388349618}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rpdrduzbarhsosqgv0j2g3ow","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388365099}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388365272}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388365392}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388365649}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388382364}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388382507}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388382611}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388382787}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388400148}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388400237}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388400389}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388400479}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388425511}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388425573}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-zA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388425628}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-Z"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388425842}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388443541}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388443723}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388443848}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388443905}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388471883}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388472121}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\[\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388472207}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388472350}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388479412}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388479479}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388479526}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388479588}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388498213}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388498294}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388498364}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388498465}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388500433}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388500507}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388500576}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388500636}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388518633}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388518747}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388518848}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388520585}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388535305}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388535362}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388535494}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388535550}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388537209}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388537285}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388537356}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388537402}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388557750}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"undefined"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388557855}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388557908}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388557976}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388576831}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388576960}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388577038}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388577188}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388578068}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388578307}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388578419}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388578555}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388624946}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388625027}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388625100}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388625152}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388634814}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388634916}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388635004}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Scan"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388635083}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388649449}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" property"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388649582}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ty"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388649744}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pos"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388649812}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388743293}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7112,"ts_us":1792977388743436}}

data: {"id":"f8e9e548ce2202c5088fb549405bd7cd","object":"chat.completion.chunk","created":1792977388,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":478337,"completion_tokens":125,"total_tokens":478462,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":477696,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":16,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":7112,"ts_us":1792977388743572}}

data: [DONE]

