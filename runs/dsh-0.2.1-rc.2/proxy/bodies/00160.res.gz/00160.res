data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978235538718}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"File"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236511927}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236618243}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" latest"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236618502}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236618569}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236618675}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236649066}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236649119}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"inal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236649167}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236649294}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236649341}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236668919}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236668996}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236669047}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236669111}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236682567}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" class"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236682637}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unused"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236696485}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236696533}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236696583}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236715840}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236715905}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236715960}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" creation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236735025}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236753170}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236753222}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236770424}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236770480}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236770542}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236770592}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236770636}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"const"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236784352}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236784395}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236800780}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" w"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236800834}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" <"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236811046}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236811096}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"690"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236811144}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236811190}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236811235}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236826132}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236826188}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236826226}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" w"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236843069}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236862071}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"650"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236862136}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236862185}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236862239}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236862282}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236862324}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" All"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236878425}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236878482}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" syn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236893906}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236893950}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236909838}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236909890}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" consider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236909931}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236909970}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236933271}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236933349}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236933413}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"inal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236947987}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236948061}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unused"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236948107}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236964312}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236964373}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" harmless"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236964434}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236982236}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978236982334}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237004450}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237004516}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237004572}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237014276}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237040001}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237040075}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237040138}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237040197}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237040255}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237040462}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" references"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237040526}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237085101}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237085224}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237085620}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237085704}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237085775}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237085841}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237086151}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237086227}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237086302}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237113159}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237133660}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237133742}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237133811}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237133878}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" this"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237133939}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" point"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237141418}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237141502}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237141571}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" answer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237151350}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237151443}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237151527}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237151600}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237151675}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237151750}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237164360}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237164442}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237164512}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237185942}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237186035}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" adding"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237203250}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237216676}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237216746}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285130}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285211}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285266}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" helpers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285318}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285369}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285439}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" had"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285740}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285806}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" smoke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237285860}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237300394}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237321888}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237321963}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237322024}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237328580}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237328657}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" description"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237328709}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237328772}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" say"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237343104}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237343174}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Built"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237343237}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237357089}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237374815}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237374887}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237374943}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237375008}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237375054}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" features"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237389465}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237389522}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237389576}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shouldn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237406045}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237406115}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237406172}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"state"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237435987}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237436063}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verification"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237439569}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237439611}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237464031}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" couldn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237464076}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237464150}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237464216}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" images"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237487452}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237487499}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237487559}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237487611}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237487794}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237487878}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237487934}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237511069}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ested"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237541036}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" behavior"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237541083}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237541208}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237541246}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237541286}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237541321}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237566872}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237566965}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237567148}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237567246}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" syntax"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237567296}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237588608}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237588679}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Keep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237588753}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237615576}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" answer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237615649}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237615706}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237615752}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237615856}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" short"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237615937}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paragraphs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237616004}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237616069}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bullets"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237634067}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237634112}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Des"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237634180}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ired"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237647120}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237647167}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"verb"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237647237}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"osity"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237647298}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237647337}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237647385}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237664379}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237664424}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" response"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237678660}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237698405}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237698459}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moderately"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237698509}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237698544}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237715220}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237715273}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237715321}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" asked"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237730064}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237730116}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237730196}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237730268}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" explicit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237742676}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" explanation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237761479}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237761521}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237761624}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'ll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237761661}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" summarize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237780451}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237780498}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237796485}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237796541}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" functionality"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237796592}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237815233}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237815304}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237815357}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237824286}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237824361}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Make"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237824431}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237843761}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237843821}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ext"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237843870}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rane"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237866111}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ous"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237866187}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" details"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237866244}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237866299}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237875347}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237892235}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fencing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237892285}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237921824}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237922051}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237922116}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237943315}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237943384}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237943440}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237943490}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237943557}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237959376}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" parameters"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237959459}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237968468}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" how"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237968533}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978237989831}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238028970}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" opens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238029075}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238046712}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238052620}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"240"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238064945}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238065008}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238081584}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238081647}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238081695}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238097643}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"G"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238097718}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238113452}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238113528}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238113581}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238130502}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"({"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238130579}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238130658}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238147154}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238147279}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" })"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238147344}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238147412}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238162299}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238179318}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238179383}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238179439}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" single"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238179496}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238179556}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238197600}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238197686}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238197787}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238197840}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238210512}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tested"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238210566}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238210601}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" desktop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238227175}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238244726}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"obile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238244795}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238244855}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238244914}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Avoid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238244942}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" saying"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238258703}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238258789}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238258849}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" couldn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238280143}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238280211}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238280250}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inspect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238298974}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\"\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238307843}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238307910}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238307964}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238308028}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" answer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238308087}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238325244}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238325309}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238325366}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cave"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238325393}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ats"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238356161}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238356257}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238356315}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238356365}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" list"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238368900}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" key"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238368979}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aspects"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238391716}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238391777}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238391833}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238391940}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ist"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238414497}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238414570}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238435524}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" journal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238435595}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238452630}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" noct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238452858}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ur"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238471847}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ne"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238471909}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238471960}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238472123}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chron"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238472168}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ometer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238498903}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238498966}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238516087}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238516168}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238538571}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238538640}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238538755}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238565726}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238565794}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238574332}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"iders"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238574417}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/sp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238587906}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238587947}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238616022}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238616139}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238616180}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238616343}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238616416}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238616468}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238657027}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238657091}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238657135}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238657235}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238679727}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238679771}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"determ"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238679847}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238684658}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"istic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238684729}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238684789}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238684842}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238684895}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\"\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238694860}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238694905}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Confirm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238694976}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seeded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238712366}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" determin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238729052}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238744385}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238744449}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238744503}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238744544}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238760691}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238760732}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238760784}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238778964}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tmp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238779024}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238792487}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238792539}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238792575}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"work"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238792621}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238808161}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238808217}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`.\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238808254}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238808298}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238808352}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238808404}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238833699}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238833763}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875212}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875265}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875321}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shouldn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875370}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875420}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875453}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875553}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238875615}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238907990}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ource"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238908087}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extras"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238908121}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238934622}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238948339}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tmp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238948393}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238948428}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238966245}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238966290}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238977672}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deliver"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238977755}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238977811}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238994312}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238994369}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238994408}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978238994458}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239008253}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239008310}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239008409}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fonts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239027604}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239027647}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" embedded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239042980}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239043032}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Nice"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239043069}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239060394}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239060441}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239060492}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239060536}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" offline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239077812}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239091449}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239091549}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239110240}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239142139}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Given"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239142181}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239159570}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" task"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239173060}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239173117}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" evaluated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239173162}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239188909}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239189023}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239189093}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239208951}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" message"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239209030}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" minimal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239222314}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239222433}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239222508}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239235252}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"down"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239275738}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239275824}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239275894}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" citations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239275959}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" needed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239276023}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239276090}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239289608}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" using"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239289705}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" web"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239299330}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" search"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239299428}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239319675}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239319759}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239319827}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239319886}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239327281}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" answer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239327358}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239327424}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239346470}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239346564}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239360139}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239360214}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239360275}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239388834}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-st"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239388895}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239390908}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239390975}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" completes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239408521}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239408608}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239428529}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239428591}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"240"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239428641}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239454720}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239454807}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239454863}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239466076}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239466147}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239466210}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239466280}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239482037}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239482085}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239500214}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239500280}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239500330}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239514844}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239514886}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239528876}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ask"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239528935}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239528993}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" question"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239552613}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239552672}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239552706}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" completion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239552781}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239552868}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239552912}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239552969}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239553010}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239553064}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239578132}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" goal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239578174}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239578234}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239590753}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239590796}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239590855}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" create"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239590903}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239590958}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239617249}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239626066}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" todo"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239626129}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" completed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239626170}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239637523}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239637590}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239637660}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239637723}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239637764}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239637828}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" thought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239650302}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239650341}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239650381}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239650416}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"B"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239695542}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"anner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702028}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702070}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702126}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702172}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702304}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702367}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702421}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239702447}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" true"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239750334}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239750386}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239750432}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239750552}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239750590}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shown"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239776541}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239776643}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" false"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239783658}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239783727}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Screen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239783778}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" readers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239783823}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239800724}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" navigate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239800803}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" into"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239815918}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239815963}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239837642}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239837689}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239853326}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239853391}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Ann"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239853431}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oun"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239865283}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239865333}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" handles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239865393}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239865439}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239865496}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239880960}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239881007}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239881047}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239881084}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239897253}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239897304}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942149}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942221}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" markup"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942269}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942363}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" valid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942467}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942540}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942669}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942733}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"nos"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239942787}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239966417}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239966488}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239966544}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239985686}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239985749}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239996204}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978239996249}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-enabled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240008600}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240026933}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240027002}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240027046}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240038694}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240038762}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240038822}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240038872}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240065226}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240065287}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240065337}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240065404}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URL"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097031}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097105}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097165}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097208}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097445}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097542}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097607}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Everything"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240097668}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240112878}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240112958}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240124914}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240124955}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240125017}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Built"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240125067}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240125120}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" single"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240135494}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240135560}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" deliver"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240135602}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240151056}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240151102}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240151176}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240151245}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240196307}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"`.\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240196370}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240196425}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" includes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240196598}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240222607}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240222662}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240222700}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240222741}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ist"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240222881}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"’"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240222959}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240253297}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240253337}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-j"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240253376}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ournal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240253483}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" composition"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240253534}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240281582}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240281632}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240281688}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" “"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240281790}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"spec"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240281856}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"imen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240314168}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" under"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240314237}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240314292}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":",”"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240314413}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" engraved"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240345979}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240369764}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" chron"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240369891}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ometer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240384835}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240384909}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" bes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240384971}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"poke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240385025}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240385107}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240397928}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" palette"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240397979}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240418106}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240418161}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240418214}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" reusable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240429079}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240443836}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240458287}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" system"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240458368}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240458420}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240458467}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240458512}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" deterministic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240476697}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" seeded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240490612}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ecosystem"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240490689}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" engine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240507150}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240507196}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240523550}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240523625}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240523695}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240539613}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240539676}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240539716}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ri"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240561215}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"kes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240561267}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240561307}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" mut"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240579305}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ating"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240594088}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" gene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240594149}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" vectors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240610201}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240610294}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" separate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240610377}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" rendering"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719433}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719503}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719556}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719613}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" access"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719658}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719713}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719753}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719809}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"G"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240719955}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"arden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720033}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720076}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720131}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720185}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"(..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720242}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720376}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720447}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720502}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" accelerated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720556}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240720650}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" support"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240732016}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240750008}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240750066}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" An"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240750116}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" integrated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240770957}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240771003}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240771061}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240771165}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240771219}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" rotary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240803681}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" mutation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240803784}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240832763}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240832815}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240832863}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" sl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240833031}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"iders"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240833122}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240833186}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ste"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240833241}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"pper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240865180}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240865221}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240865263}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" switch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240865385}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240865455}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240865494}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240887151}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240901185}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" effect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240901253}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240923468}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240923529}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240923610}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240923638}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240936034}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240936110}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" keyboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240936171}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240951826}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240971793}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240971880}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240971947}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" states"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240971999}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240988190}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240988272}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Automatic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240988327}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" drought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978240988401}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241033416}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" plague"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241033637}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241033689}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241033733}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" frost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241033808}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" schedules"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241033881}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241033977}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" tint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241034055}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241034138}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" lens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241047908}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" moments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241047999}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121011}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" banners"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121070}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121129}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121201}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"/t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121255}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"im"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121308}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"eline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121364}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121401}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121439}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121475}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" annotated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121509}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241121557}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241129571}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241129625}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" An"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241129673}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241152221}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241167871}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241167923}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241168010}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241181900}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241181968}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241182011}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241198265}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"rawn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241216445}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" census"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241216504}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" curves"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241216575}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241228876}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241228992}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241238516}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241251387}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-dr"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241251450}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ift"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241268266}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" matrix"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241268331}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" showing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241268384}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" mean"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241297568}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241297650}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ±"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241305646}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241305692}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"σ"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241305758}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241305839}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" gene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241333734}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241342656}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241342706}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241342743}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241342777}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Respons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241342817}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241365392}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" layouts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241365455}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241365524}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" reduced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241365585}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241378019}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"otion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241378090}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" support"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241378146}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241378200}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241378263}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241378317}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" libraries"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241398381}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241410420}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241410465}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241431007}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241431089}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241431159}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241441923}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Verified"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241442021}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241442086}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Chrom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241458693}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241458785}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" across"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241458865}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" desktop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241458951}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241467429}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" tablet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241467503}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241485492}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241485572}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241485646}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" view"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241485717}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ports"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241485784}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241506250}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" including"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241506346}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" deterministic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241506410}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" engine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241517379}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" replay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241535053}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241549766}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241566104}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" automatic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241566196}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241589703}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"240"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241589759}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241589905}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241604900}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" completion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241616092}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1874,"ts_us":1792978241616147}}

data: {"id":"f7de8e50194fe48ad88b7d742f98c406","object":"chat.completion.chunk","created":1792978235,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":593442,"completion_tokens":829,"total_tokens":594271,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":593280,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":592,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1874,"ts_us":1792978241616327}}

data: [DONE]

