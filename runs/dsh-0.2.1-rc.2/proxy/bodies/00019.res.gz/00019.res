data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092873828}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092916096}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" average doesn't increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092916150}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092916243}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092956910}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", because moths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092956972}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092957336}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974092957412}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093099313}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The system"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093099370}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is consumer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093099421}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-controlled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093099468}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093129715}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093129859}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" standing crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093130205}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", reduce consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093130264}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093208585}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093209180}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093209227}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093209715}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093306436}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Moth population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093306760}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093306820}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093306871}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093416048}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093416253}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093416422}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093416598}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093463034}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300? M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093463107}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oths consume quickly."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093463600}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093463669}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moth count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093517339}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093517418}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093517566}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093517944}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093599479}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093599532}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093599587}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093599663}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual lushness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093736128}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", increase plant glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093736365}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" footprint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093736559}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / clusters"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093736636}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Or add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093753476}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" non"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093753549}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-ed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093753707}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible decorative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093753761}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093873817}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093873936}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093874008}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" honest simulation. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093874070}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093923228}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093923295}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant with 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093923394}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974093923733}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" halo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094003651}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094003728}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants in 660"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094003809}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px circle,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094004155}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094077641}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" about 6px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094077744}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094077972}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough dots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094078470}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but not carpet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094180345}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094180438}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094180498}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094180539}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moss texture not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094261662}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" part of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094261926}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation? Avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094261992}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" misleading"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094262122}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094351480}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094351558}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094351802}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glyphs larger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094351862}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and more elaborate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094398868}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", like colonies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094398919}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094399192}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" colonies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094399239}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" across lens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094501600}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~ reasonable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094501678}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094501737}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094501810}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094559301}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" collapse to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094559365}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300. After initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094559423}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094559996}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094634333}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094634417}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at ~5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094634552}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s could show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094634639}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 800"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094714298}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nThe population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094714496}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094714737}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094714812}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094799102}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unstable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094799185}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094799257}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094799325}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094881323}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Shri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094881400}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094881462}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pinned"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094881526}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094953080}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094953150}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16. That's not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094953299}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ideal scientifically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974094953378}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (art"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095002742}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ificial cap),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095002829}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but okay for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095002868}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095002914}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We could implement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095085865}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strict"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095086238}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095086294}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095086354}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better reason"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095149409}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": territorial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095149478}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095149541}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16) is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095149621}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plausible in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095284751}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095284816}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closed jar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095284966}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Ex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095285146}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pose maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095307035}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"capacity\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095307110}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not required"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095307168}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095307224}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095379283}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095379358}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095379403}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 16 many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095379467}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" times; charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095453769}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less interesting."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095453847}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095453927}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095453997}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould increase sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095523582}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike cap to 24 to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095523858}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095523977}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095524559}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095599505}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 44"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095599800}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Earlier cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095599848}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30 gave more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095599917}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095667684}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095667779}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095667910}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095667988}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survived"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095846019}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095846098}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095846149}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? With current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095846207}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095859354}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095859425}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and food "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095859470}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095859537}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095904310}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095904379}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095904532}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's test sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974095904776}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike cap 24 or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096050426}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20 with food 36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096050542}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/44. May"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096050638}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yield more dynamic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096050730}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves and plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096074532}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096074615}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" More predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096074663}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lowers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096074916}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moths,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096252386}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" potentially"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096252583}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" raises"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096252677}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants. Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096252749}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096276552}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096276609}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096276752}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096277760}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096349185}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more. Try"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096349232}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096349295}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096349452}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096412276}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096412333}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096412545}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096413090}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strict cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096510705}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096511152}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's test cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096511240}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24, food "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096511302}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"36 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096580124}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 44."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096580225}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_mhluptnxi213cyp46j7pm7pc","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096580605}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096580720}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096580824}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096581304}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096581410}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096581505}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096602997}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096603189}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096603292}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096603371}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096618968}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096619063}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096619328}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096619422}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096629904}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096630222}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096630668}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096631092}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096631192}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096631279}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096632055}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096632152}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"16"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096650417}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096650523}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096650629}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096650725}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096663745}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096663803}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096664071}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096664451}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096664523}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096664582}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096664999}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096665054}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096800383}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096800473}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096800553}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096800672}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096819785}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096819873}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096819939}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096820030}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096820089}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096820182}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096820243}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096820300}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096874367}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096874459}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096874586}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096874695}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096881676}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096881740}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_SH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096881805}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096881894}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096881963}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096882026}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096882075}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"16"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096882135}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096882276}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096882345}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096882397}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096883883}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_SH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096886845}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096886939}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096887047}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096887105}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096888302}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096888360}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096888422}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096888494}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096893650}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096893721}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894431}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894486}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894537}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894586}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894722}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894772}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894812}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894859}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096894900}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096895908}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096907195}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096907245}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096907382}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096907445}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096913977}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096914054}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096914159}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096914235}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096916077}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096916153}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096916302}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096916361}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096920897}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096921001}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096921038}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096921438}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096921575}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096921652}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096921907}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096921965}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096937530}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096937611}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096937715}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096937778}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096957338}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096957390}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096957446}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096957503}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096967292}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096967379}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096967492}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096967544}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096968447}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096968544}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096968641}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974096968705}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097000308}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097000372}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097000477}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097000551}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097010426}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097010502}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097010553}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097010639}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097011590}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097011682}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097011752}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097011817}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097031307}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097031386}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097031985}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097032027}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097049421}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097049499}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097049565}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097049613}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097049792}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097049871}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097049942}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097050024}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097061374}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097061439}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097061499}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097061880}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097081115}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097081218}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097081424}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097081811}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097081903}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097081976}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097082070}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097082207}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097124245}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097124307}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097124492}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097124562}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137402}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137513}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137584}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137649}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137716}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137799}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137872}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097137943}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097156516}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097156598}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097156668}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097156750}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097170486}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097170634}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097170720}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097171182}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097171248}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097171329}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097171393}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097171464}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097174628}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097174717}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097174786}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097174847}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097199905}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097199966}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097200021}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097200175}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097200252}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097200326}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097200388}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097200445}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097211061}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097211162}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097211267}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097211677}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097227455}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097227530}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097227635}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097227707}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097228291}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097228380}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097228551}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097228627}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097266737}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097266830}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097266876}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097266921}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097267357}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097267404}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097267569}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097267635}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097283216}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097283306}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097283441}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097283590}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097301589}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097301672}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097301731}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097301870}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097302270}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097302320}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097302451}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097302615}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097316089}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097316164}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097316207}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097316274}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097334423}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097334505}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097334620}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097334725}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097353807}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097353872}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097353961}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097354009}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097354620}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097354704}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097354769}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097354820}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097370905}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097371048}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097371242}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097371374}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097398459}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097398545}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097398643}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097398703}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097398809}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097398877}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097398945}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097399001}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097449239}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097449296}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097449356}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097449424}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097450554}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097450642}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097450707}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097450759}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097450891}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097450951}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097450999}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097451056}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097458857}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097458931}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097459099}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097459456}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097459511}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097460119}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097460233}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097460345}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097460770}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097460829}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097460893}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097460957}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097502133}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097502230}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097502315}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097502480}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507113}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507165}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507224}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507359}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507447}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507515}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507580}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097507641}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097528124}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097528192}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097528234}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097528308}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097551036}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097551196}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097551286}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097551369}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097551954}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097552074}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097552119}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097552199}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097598071}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097598146}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097598211}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097598262}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097599051}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097599127}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097599195}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097599260}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097605036}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097605085}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097605169}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097605300}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097625027}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097625173}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097625253}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097625340}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097668384}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097668456}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097668521}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097668711}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097669387}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097669448}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097669580}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097669768}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097687887}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097687987}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097688136}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"filter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097688240}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097708235}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097708302}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097708349}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097708459}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097752838}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097752918}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097752985}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097753053}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097763363}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097763442}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097763586}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097763673}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097781154}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097781254}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097781369}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097781691}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097782243}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097782306}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"36"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097782652}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097782726}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"44"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097802456}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097802554}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097802657}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097802722}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097817134}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097817239}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097817482}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097817547}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097865655}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097865736}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097865806}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097865875}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097866281}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097866355}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097866422}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097866498}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097878608}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097878689}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097879413}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097879523}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097879784}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097879858}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097879924}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"07"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097879991}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097921085}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097921158}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"URE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097921220}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097921304}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097923738}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097923811}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097923874}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097923988}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"NOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097924053}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"TH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097924358}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097924476}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097924547}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097931295}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097931386}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097931554}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097932137}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097948557}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097948698}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097948787}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097948884}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097948960}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097949014}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097949057}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097949216}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IDE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097987699}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097987771}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097987821}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097988156}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097988360}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097996949}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097997012}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097997066}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097997122}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097997176}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097997233}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974097997284}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098001644}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098001716}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098001772}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098001913}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098019391}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098019484}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098019601}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098019879}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098047317}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098048048}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098048123}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098048208}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098048283}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098048336}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098048381}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098048454}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098060491}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098060561}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098060612}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098060746}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098107179}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098107268}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098107387}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098107489}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098108389}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098108447}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098108502}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098108993}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098111730}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098111804}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098111886}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098111961}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206046}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206116}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206151}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206275}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206653}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206735}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206836}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098206886}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098222364}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098222438}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098222623}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098223438}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098231700}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098231783}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098231859}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098232192}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098232283}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098232413}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098232481}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098232646}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098250075}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098250198}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098250275}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098250337}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098254253}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098254328}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098254383}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098255379}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098255459}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098255523}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098255596}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098255691}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098257269}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098257364}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098257985}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098258070}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098258985}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098259048}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098259106}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098259163}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098259224}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098259362}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098259480}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098259556}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098280490}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098280582}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098280650}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098280996}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098300995}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098301079}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098301163}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098301233}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098301319}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098301653}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098301732}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098301809}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358110}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358197}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358265}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358333}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358407}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358720}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358790}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098358860}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098373466}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098373532}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098373649}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098374271}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098401767}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098401848}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098401913}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" intermediate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098401983}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" predator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098428789}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098428957}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098429076}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3816,"ts_us":1792974098429203}}

data: {"id":"5bc50d6da6857fe096c071cb66d7fe35","object":"chat.completion.chunk","created":1792974092,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":96087,"completion_tokens":948,"total_tokens":97035,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":94720,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":399,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3816,"ts_us":1792974098585925}}

data: [DONE]

