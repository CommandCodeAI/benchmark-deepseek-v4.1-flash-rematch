data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230649993}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230697974}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230698045}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output identical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230698089}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230751897}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18 earlier?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230751962}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230752016}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because config still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230752078}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230831608}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230831794}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230831838}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18? We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230832256}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replaced `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230945498}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"foodReg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230945576}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth: 36,`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230945654}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in DEFAULT_CONFIG only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230945764}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not constructor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230985967}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230986338}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230986488}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18. Ah"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974230986600}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231086329}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231086404}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for WEST"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231086477}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231086546}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ERE matches food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231128087}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231128286}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We didn't change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231128325}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231128609}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231195879}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231195940}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps raised"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231195988}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231196040}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"900/110. Output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231284526}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231284575}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18 now differs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231284612}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231284699}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231387273}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds due caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231387339}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231387404}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231387462}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231459323}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231459614}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231459669}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231459808}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231520859}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" table"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231520911}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would match"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231521333}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food28 above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231521626}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231598139}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231598187}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/110."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231598250}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need decide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231598329}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nEngine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231676523}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constructor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231676580}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231676752}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"115 must be changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231676793}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231761722}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231761997}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pass food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231762207}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231762509}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth from control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231870340}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231870404}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so DEFAULT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231870454}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_CONFIG doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231870547}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t matter;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231914541}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231914645}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can set default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231914718}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231914815}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231984163}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231984364}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should match"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231984504}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's explicitly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974231984632}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232064116}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28 in constructor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232064190}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232064253}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232064319}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28.\n\nR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232138316}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aising"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232138460}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard caps allowed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232147913}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232147977}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232236343}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 86 in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232236410}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" VIOLET"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232236458}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-5, etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232236548}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232309628}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232309771}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232310027}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Soft density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232310109}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keeps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232422262}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232422320}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232422383}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"50. MAX"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232422429}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232519499}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"110."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232519617}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232520032}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232520077}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232580096}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232580419}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n\nWith"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232580556}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232580758}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232636147}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232636203}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/110, test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232636340}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232636419}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232725191}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after changing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232725236}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232725653}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232725700}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s do."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787286}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_cq2r0it2667bcx9jami9j5ie","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787367}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787417}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787470}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787520}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787573}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787621}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232787681}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232806268}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232806323}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232806367}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232807427}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232821429}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232821476}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232821603}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232821649}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232824747}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232824824}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232824898}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232825064}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232872086}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232872150}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232872212}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232872268}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232880961}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232881012}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232881067}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232881671}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232881764}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232881846}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232881912}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232881966}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232896120}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232896190}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232896252}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232896337}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232927475}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232927589}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232927646}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232927938}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232935315}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232935437}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232935546}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232935689}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232936396}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"18"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232936674}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232936805}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232936847}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232948629}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232948674}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232948743}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232948815}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232964543}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232964589}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232964711}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232964763}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232966172}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232966301}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232966358}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232966594}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232986278}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232986328}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232986481}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974232986533}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233002562}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233002638}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233002717}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233002774}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233003249}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233003350}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233004049}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233004099}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233036666}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233036719}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233036822}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233036866}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233049739}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233049800}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233049867}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233049936}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233049994}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233050126}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233050196}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233050241}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233063509}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233063557}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233063610}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233063660}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233079495}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233079562}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233079607}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233079716}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233100886}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233100941}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233100996}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233101047}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233119004}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233119068}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233119139}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233119222}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233132020}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233132208}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233132266}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233132390}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233134903}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233134980}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233135060}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233135201}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233156054}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233156103}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233156144}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233156209}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233170298}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233170380}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233170424}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233170523}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233171021}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233171080}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233171201}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233171251}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233197751}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233197799}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233197841}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233197894}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233218409}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233218536}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233218605}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233219952}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233251472}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233251591}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233251676}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233251721}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233251806}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233251879}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233251946}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233252003}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233269246}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233269307}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233269354}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233269520}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233304599}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233304659}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233304711}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233304770}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233311717}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233311770}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233311835}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233311894}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233312125}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233312197}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233312261}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233312323}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233324361}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233324583}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233324631}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233324789}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351033}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351120}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351186}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351290}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351364}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351465}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351519}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233351562}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233368482}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233368564}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233368620}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233368747}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233377586}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233377671}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233377737}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233377875}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233379707}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233379821}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233379897}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233379962}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233399399}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233399567}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233399647}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233399761}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233412587}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233412650}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233412694}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233412768}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233413062}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233413167}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233413249}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233413734}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233455387}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233455440}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233455523}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233455701}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233455784}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233455835}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233455968}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233456030}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233456114}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233456191}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233456258}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233456308}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233487122}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233487189}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233487290}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233487383}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233487428}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233487520}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233488194}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233488288}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233510228}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233510284}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233510337}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233510451}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233510838}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233510889}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233511008}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233511060}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233529883}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233529959}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233530018}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233530200}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233559865}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233559909}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233559949}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233560255}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233562063}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233562123}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233562181}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233562236}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233580352}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233580416}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233580463}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233580536}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233658535}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233658585}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233658646}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233658735}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233669843}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233669914}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233669976}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233670103}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233671315}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233671366}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233671430}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233671654}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233679285}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233679370}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233679444}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233679512}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233726429}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233726510}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233726578}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233726626}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233727967}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233728020}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233728070}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233728319}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233745785}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233745838}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233745908}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233745990}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233749153}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233749230}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233749304}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233749355}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233750304}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233750512}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233750627}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233750707}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233813092}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233813152}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233813191}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233813368}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233815414}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233815476}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233815526}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233815580}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233816576}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233816799}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233816877}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233816961}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233821266}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233821476}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233821536}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233821675}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233826072}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233826300}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233826371}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233826497}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233828234}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233828301}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233828350}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233828380}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233829696}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233829748}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233829826}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233829913}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233831418}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233831481}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233831539}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233831599}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233835359}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233835424}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233835487}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233835540}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233865764}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233865824}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233865879}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233865959}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233873860}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233873910}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233873961}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233874119}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233887147}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233887198}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233887264}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233887355}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233905877}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233905938}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233906019}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"07"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233906219}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233929944}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"NOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233929993}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"TH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233930048}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233930149}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233930435}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233930512}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233930581}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233930640}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233946235}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233946307}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233946360}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233947018}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233976708}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233976774}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233976817}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233977490}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233998159}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IDE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233998209}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233998280}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974233998342}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234023914}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234023967}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"URE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234024018}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234024174}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234027240}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234027309}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234027360}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234027452}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234029599}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234029675}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234029743}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234029792}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234036725}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"03"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234036782}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234036927}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234037310}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IGHT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234037367}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234037482}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234037541}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234037600}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234055259}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234055308}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ET"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234055352}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234055880}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234069007}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234069083}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234069136}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234069167}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234071106}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"11"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234071173}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234071295}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234071646}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234086476}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234086518}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234087713}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234087787}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234112559}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234112613}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234112668}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234112717}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234113865}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234113968}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234114066}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234114175}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234131447}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234131497}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234131629}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234131681}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234153070}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234153119}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234153178}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234153232}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170166}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170222}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170291}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170358}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170555}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170607}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170714}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234170812}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234184822}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234184868}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234184924}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234185003}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234208549}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234208606}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234208829}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234208882}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234210882}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234210966}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234211021}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234211133}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234226594}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234226663}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234226739}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234226853}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234256112}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234256176}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234256227}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234256268}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234273481}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234273539}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234273597}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234273815}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234273897}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234273948}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234274079}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234274126}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326325}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326394}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326486}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326528}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326576}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326647}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326703}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326911}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234326966}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234327012}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234327572}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234327649}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234327724}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234327813}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234327897}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234328004}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234328053}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234328115}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234328167}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234328216}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234366541}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234366587}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234366630}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234366747}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371282}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371338}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371378}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371419}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371636}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371703}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371741}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234371837}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234397878}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234397961}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234398041}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234398125}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234433947}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234434014}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234434101}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234434191}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234459140}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234459516}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234459559}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234459763}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234534892}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234534942}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234535021}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234536059}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ret"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234538662}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234538717}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234538762}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" caps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234538862}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234605539}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2995,"ts_us":1792974234605592}}

data: {"id":"6c837c45c99f8b20d6635d08a791a08c","object":"chat.completion.chunk","created":1792974230,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":113264,"completion_tokens":763,"total_tokens":114027,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":111488,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":247,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2995,"ts_us":1792974234605888}}

data: [DONE]

