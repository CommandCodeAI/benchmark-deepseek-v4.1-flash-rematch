data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829489773}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829539636}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background job output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829539763}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only wraps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829540307}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829610068}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" command because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829610190}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the process was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829610505}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" launched with &"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829610583}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inside;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829691875}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the actual output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829691984}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file has the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829692169}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" result. Read file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829692244}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829787393}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_oy28tr3iclk0c71tjp28yrel","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829787605}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829787811}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829788071}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829788412}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829788482}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829788554}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829788615}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829788680}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829788721}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829789938}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829790023}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829903008}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829903069}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829903273}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829903463}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829937922}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829938080}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829938243}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829938441}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829938614}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829938716}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829938830}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829938894}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829950835}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829951077}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829951254}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829951325}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829956522}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829956610}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" running"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829956683}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829956810}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829981601}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829981653}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829981745}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829981789}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829989025}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"af"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829989123}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829989315}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829989572}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829990059}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829990138}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829990285}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977829990376}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830000268}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830000363}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830000451}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830000496}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830054967}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830055026}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830055135}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830055575}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830064382}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" completed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830064439}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830064561}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830064610}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" output"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830129696}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830129753}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11733,"ts_us":1792977830129838}}

data: {"id":"039f3428e19d9ad4552fdbc24f6eb2cf","object":"chat.completion.chunk","created":1792977829,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":507205,"completion_tokens":122,"total_tokens":507327,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":507008,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":29,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":11733,"ts_us":1792977830139585}}

data: [DONE]

