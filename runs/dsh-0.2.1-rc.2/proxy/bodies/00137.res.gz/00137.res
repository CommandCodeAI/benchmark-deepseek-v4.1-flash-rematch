data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912366029}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912698060}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912805889}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contrast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912819260}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912832648}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ≥"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912848652}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912848710}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912848763}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"98"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912848822}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912864519}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912864571}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912864631}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912887296}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912887358}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912897951}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912898051}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912898109}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912898172}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912898271}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912912607}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contrast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912912673}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912928574}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912951362}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912951424}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912951465}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912951512}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912960788}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912960850}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"11"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912960893}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912960944}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912960982}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912978939}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Great"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912979017}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912979075}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912979105}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912979160}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912995546}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977912995595}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-w"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913015433}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913026190}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913026251}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913026311}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913026368}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913041013}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913041078}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rgba"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913041138}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unaffected"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913041196}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913061509}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913061572}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913061625}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913061707}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913061768}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913072216}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913072265}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913091991}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913092066}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913110304}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913110378}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913126299}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913126368}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913139140}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913139200}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contrast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913139243}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913158169}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913173220}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913173291}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913173349}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913173419}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913188308}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913207988}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913208049}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913231515}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913231595}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913231645}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913231697}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913231755}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" markers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913231877}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913247815}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913247860}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913247951}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913248006}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" legend"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913248044}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913264515}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"atches"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913280620}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913280686}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913295929}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913296011}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913296078}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913296141}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913313048}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913340397}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"--"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913340482}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913344027}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-b"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913344084}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"right"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913359870}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913359951}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" isn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913360016}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913378515}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" used"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913378578}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913378635}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913378699}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913392731}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913392863}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913392928}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913393121}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913393176}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913410529}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913410594}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913426108}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913426193}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913426296}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913426823}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913442036}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913442101}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913465492}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913465565}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913465619}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913465677}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" palette"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913465732}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913478734}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cohesive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913492292}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913492338}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913507496}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" och"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913507566}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913523253}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" darker"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913523312}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913537389}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plague"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913537450}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plum"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913537524}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913553675}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" frost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913553748}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" te"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913553803}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"al"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913571130}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913571192}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913584697}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913605845}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" distinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913605967}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913620119}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913620188}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913620242}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913620307}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913634860}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913634908}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913651726}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913670175}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913670236}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" close"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913688050}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913698981}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" brass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913699056}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913714651}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913714732}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913714794}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913714855}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913714922}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913729412}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913729456}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"W"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913729512}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913749137}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913749210}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913749266}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913760786}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" warmer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913776893}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913776968}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913777012}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913793867}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913793959}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913794047}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913794117}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913794170}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913810024}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913810108}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-k"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913825047}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icker"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913844231}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913844292}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913844355}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913862522}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913862608}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913862663}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913862716}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913876102}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"present"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913901983}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913902052}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913906635}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913906728}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913906799}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913906864}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913906923}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913906988}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Gly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913921741}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913921813}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913921886}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913940467}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913940525}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913965118}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" get"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913977058}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913997577}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913997629}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913997684}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913997728}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913997767}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977913997805}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914021465}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914021567}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914021637}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cream"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914039615}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914039670}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914039716}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914039751}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914059094}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914059185}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914059231}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914059272}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914068298}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914085630}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914085681}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" distinctions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914098072}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914098151}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914098205}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914114175}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914114233}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Drought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914114274}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" #"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914130257}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914147328}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"f"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914147392}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"652"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914161815}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914161878}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" och"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914161925}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914185857}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914185933}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914185972}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914186079}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" #"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914186134}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914198293}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914198366}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"671"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914213029}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914213099}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gold"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914213154}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914213203}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" both"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914213253}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" similar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914245928}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914246039}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914261270}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914261327}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914277342}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914292400}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914309565}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914324567}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914324628}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914324694}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914345541}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914345598}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914355311}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914355373}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914355416}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914355468}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914355514}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914370193}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" och"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914386845}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914386899}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914386948}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914410923}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914410999}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914427683}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gold"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914457100}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914457211}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" look"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914457531}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" similar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914457617}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914487315}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914487394}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914487466}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" markers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914487756}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914487835}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" their"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914530023}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914530507}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914530603}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914530683}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914551944}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"abels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914559143}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914559241}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914559322}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914559397}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914559467}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914559539}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914586720}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914586835}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914604604}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914604783}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914631216}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914631454}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914631589}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914631972}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914632057}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" palette"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914632128}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914651290}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914673828}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914673913}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" another"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914674011}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessibility"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914674078}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914682137}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914691715}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914691854}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914712526}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"--"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914712610}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914732437}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ague"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914753060}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914753166}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914753237}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914772415}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914772506}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914784212}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" used"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914795703}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" anywhere"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914795783}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914813276}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914813340}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914828142}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914844394}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914844450}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914844488}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914844523}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914861387}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914861451}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914861508}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914877538}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914877618}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914892518}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rgba"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914892587}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914908381}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914908423}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914908459}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914908496}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914932916}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" legend"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914933004}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914943659}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914943739}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"atches"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914963389}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914963448}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914973273}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914973329}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914973391}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977914988383}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915008847}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915008910}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915019618}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915019675}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915019742}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915031586}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915051794}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915066193}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915066252}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915066316}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915080620}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915080689}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" style"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915101798}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915101849}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"--"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915111597}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915111671}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915111729}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915111785}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"var"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915111841}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"(--"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915127539}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915127611}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915127665}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915127722}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" updates"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915127773}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915143668}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915143741}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915143789}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915163315}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915163391}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915163438}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915163485}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915177487}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"EV"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915177572}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ENTS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915201105}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915201165}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915201217}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" match"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915216167}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915216225}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915225275}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915225377}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915242096}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915242197}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915242271}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" quick"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915242349}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915256143}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915256199}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915270527}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915270581}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915289740}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915289797}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915289849}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915289917}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" just"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915289974}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915290024}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915303091}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915303148}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issues"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915322199}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915360676}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915360730}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915360812}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915360894}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915360942}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915361002}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915361039}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"458"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915370922}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"KB"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915387468}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915387526}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915387567}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915387615}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remove"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915387654}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unused"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915403799}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" resources"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915403856}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915403906}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915424889}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" variants"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915424947}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915435059}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915447409}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" embedded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915447532}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915463783}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915463855}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fonts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915463930}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915479985}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915480032}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Corm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915480095}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915497965}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915498028}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" regular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915498101}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915524259}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"italic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915524326}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915524367}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915528351}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Sans"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915528425}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" variable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915528479}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915544199}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" IBM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915544241}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" P"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915544323}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lex"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915544392}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Mono"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915544448}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" regular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915559191}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915575459}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"500"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915575531}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915575567}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915575629}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915575680}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915602060}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Corm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915602137}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915602195}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915602256}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" normal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915610794}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915629424}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"italic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915629497}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915629577}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915645761}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Sans"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915645810}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915645885}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"400"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682348}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682425}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"600"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682479}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682533}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" IBM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682576}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" P"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682625}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lex"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682682}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Mono"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915682726}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915691481}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"400"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915691558}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915691611}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"500"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915691691}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915691754}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915691790}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915705035}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915705085}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915705123}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915705165}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" files"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915719522}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915719581}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Latin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915719630}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915739617}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915754076}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915754142}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" punctuation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915771291}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915771344}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915795565}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915795660}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915795731}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915795803}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" curly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915812259}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" quotes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915812310}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915826970}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915827034}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915841622}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915841690}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915841736}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915841793}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915841843}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915855733}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915872665}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915872744}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915872805}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915890213}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915890259}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" string"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915890329}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915903249}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915903313}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915903365}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915927477}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915927552}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915946411}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915946475}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915946529}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915946580}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915946630}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915960922}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915960995}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915980503}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ix"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915980569}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915980637}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915980700}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915987689}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977915987736}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916001257}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916001314}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916001417}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916001480}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916015618}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916015695}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916015754}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"drop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916015814}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-filter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916031032}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916031098}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916031154}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916053546}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"mix"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916053620}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-bl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916072523}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916072619}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-mode"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916072666}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`.\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916095041}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916095088}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916095143}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916095213}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916095285}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-w"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916095323}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916118754}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916118802}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916118852}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916130445}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"mix"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916130491}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-bl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916130567}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916130624}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-mode"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916130654}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916146776}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916146860}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916146914}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916146952}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916146995}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916160677}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rgba"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916160747}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916176425}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916176499}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916197929}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916197979}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916209213}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916209314}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916224263}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916224331}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916224417}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916224474}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916240785}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916258482}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916258554}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" noise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916274447}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916274521}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916290495}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916290573}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916305200}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916305258}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916305305}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916327551}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916327630}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916327701}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916327762}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916327836}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916349723}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" transparent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916354829}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916371407}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916371461}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916389679}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916410927}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sticky"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916427182}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916427228}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916440142}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916440191}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916440245}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" print"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916440300}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916440348}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916453140}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" journal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916464250}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916480986}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916481033}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916481088}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916481131}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916481170}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916497461}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916497542}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916513388}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916535664}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916535751}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916544467}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ening"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916560378}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916560424}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"query"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916578137}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" --"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916592432}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916612160}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916612233}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916625346}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916644090}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916644159}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916644218}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916660763}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916660832}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916660882}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sample"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916660954}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contrast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916679668}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916716897}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_W1Vm3rX5kJHGe4BITsSF6735","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916750723}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916750911}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916751274}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916751346}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916751409}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916751453}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916758243}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916758315}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916758364}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916758419}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916758472}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916758522}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916782452}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916782539}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916782605}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916782652}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916782747}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916782833}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916794895}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916794969}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916795031}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916795091}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916795151}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916795210}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916809578}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916809653}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916809715}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916809777}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916809838}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916809890}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916831869}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916831950}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916832018}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916832082}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916832149}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916832224}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916841737}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916841815}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916841873}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ools"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916841938}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916842005}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916842071}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916855350}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916855420}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916855480}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916855541}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916855597}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916855653}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916867671}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916867747}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916867813}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916867904}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916868051}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916868094}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916883795}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".l"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916883868}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916883968}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"unch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916884028}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916884093}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916884158}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916899342}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916899421}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916899492}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916899576}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"args"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916899644}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916899723}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916916443}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"--"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916916514}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916916575}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916916636}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916916700}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916916753}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916934093}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916934174}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916934243}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916934284}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916934338}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916934425}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916950476}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916950580}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916950643}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916950705}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"viewport"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916950779}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916950854}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916982823}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916982888}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916982953}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983013}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983069}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983124}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983234}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983276}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983374}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983456}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977916983505}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" err"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917040883}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917040942}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917040986}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"[]"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041043}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041087}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041145}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041240}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041301}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"page"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041381}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041452}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041520}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041565}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041639}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041687}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041726}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041791}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041843}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".message"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917041913}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917056618}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917056665}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917056714}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917056762}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917056796}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917056841}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917065450}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917065500}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917065566}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917065619}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917065668}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917065706}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103542}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103625}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103688}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103748}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103810}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103869}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103929}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917103992}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917104053}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917104112}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"())"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917104171}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917104228}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917116162}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917116244}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917116315}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"oto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917116377}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917116437}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917116501}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917136099}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917136175}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917136241}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917136306}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917136366}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917136454}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158270}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158356}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158427}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158494}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158559}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158602}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158859}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917158911}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"500"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917159001}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917159085}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917159148}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917159209}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917181261}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917181348}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917181423}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917181493}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917181557}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917181623}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917210508}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917210603}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917210660}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917210721}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917210787}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917210855}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"._"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917210980}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"trigger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917211044}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Cat"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917211124}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917243797}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rophe"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917243872}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917243935}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917243984}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917244148}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917244213}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917244262}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917244311}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917244357}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917244404}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917267829}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917267929}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917267998}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917268096}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917268180}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917268232}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917272754}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917272831}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917272883}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917272951}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917273018}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917273081}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917284541}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917284610}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917284686}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917284803}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917284899}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"anner"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917284987}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917300179}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917300257}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917300316}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Com"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917300375}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"puted"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917300432}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Style"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917300504}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(document"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917319688}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917319769}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917319833}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917319897}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917319990}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"anner"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917335657}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'))."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917335726}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917335800}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Property"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917335867}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Value"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917335932}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917336003}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"--"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917348981}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917349031}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917349104}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917349171}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"trim"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917365309}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917365377}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" title"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917365444}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917365516}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917365562}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917383852}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917383923}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917383977}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Title"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917384020}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917384059}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917384130}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917404436}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917404500}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" timeline"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917404558}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Mark"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917414993}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917431433}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917431499}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Com"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917431539}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"puted"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917431638}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Style"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917431749}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(document"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917431834}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917456974}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917457051}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917457097}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-mark"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917457204}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'))."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917457284}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917457346}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Property"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917466692}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Value"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917466783}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917466861}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"--"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917466926}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"mark"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917466994}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917467078}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"trim"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917479398}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917479450}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917479518}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Icon"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917479578}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917494587}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917494644}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917494710}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Com"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917494822}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"puted"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917494878}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Style"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917494967}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(document"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917511031}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917511094}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917511181}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917511273}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-icon"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917511329}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'))."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917525311}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917525374}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917525466}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" spark"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917525539}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917542215}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917542297}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917559456}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917559563}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" errors"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917573368}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917573444}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917573503}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}))"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917589769}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917606674}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917606731}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917622138}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917622191}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917622245}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917622318}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917622394}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917622476}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917640842}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917640934}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917641032}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917641114}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917641188}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917641328}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917656466}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917656599}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917656710}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917656788}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917656847}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917740950}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741107}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741188}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741268}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741340}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741419}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Verify"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741501}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741579}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741719}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" usage"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741811}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917741895}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" palette"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917757021}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" change"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917757113}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917757250}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2502,"ts_us":1792977917769297}}

data: {"id":"87f1e732fb0a3bbfa30cb4a5cbb83db6","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":515907,"completion_tokens":976,"total_tokens":516883,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":515712,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":622,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2502,"ts_us":1792977917804179}}

data: [DONE]

