data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630013932}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630056145}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"undefined` count 2 likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630056236}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in code e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630056642}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g. `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630120845}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"typeof undefined`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630121046}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630121222}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630121267}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_nb9h0o29v4ji2tz9ggf9kgxf","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630162199}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630162299}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630162577}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630162926}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630178805}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630179232}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630179278}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630179340}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630179742}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630180285}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630180367}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630180416}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630198450}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630198522}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630198617}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630198849}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630219377}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630219432}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630219515}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630219684}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"undefined"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630220058}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630220122}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630220192}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630220261}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630237476}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630237575}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630237683}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630237756}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630258466}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630258540}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630258654}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630258724}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630259209}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630259273}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630259486}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630259545}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630291347}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630291430}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630291496}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630291561}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630310096}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630310210}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630310319}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630310373}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630335572}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Loc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630335650}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630335779}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" undefined"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630335843}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" occurrences"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630405701}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630405762}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6582,"ts_us":1792976630405865}}

data: {"id":"de29b086ae1354c141f48deeaecca9c6","object":"chat.completion.chunk","created":1792976629,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":408623,"completion_tokens":105,"total_tokens":408728,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":405632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":19,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6582,"ts_us":1792976630412787}}

data: [DONE]

