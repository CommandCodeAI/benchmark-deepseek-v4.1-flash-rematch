data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381736532}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381750602}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381750665}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381750718}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381810475}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381810565}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381810637}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381810710}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" installed globally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381922432}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381922617}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_w0i6nlgf9ezi67580kw7eqft","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381922838}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381923538}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381923630}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381923718}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381923801}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381923998}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381936796}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"npm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381937020}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381937216}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381937560}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381937789}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381949867}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381949971}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381950052}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381966704}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381966799}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381966873}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381966950}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381977993}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381978188}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381978278}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973381978357}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382001734}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382001831}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382001915}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382001992}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382037825}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"root"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382037924}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382038008}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382038088}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382038168}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382038554}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382038641}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382038722}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382066036}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382066125}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382066197}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382066262}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382085504}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382085591}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382085661}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ~"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382085734}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382103917}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382103998}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382104060}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382104139}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382121243}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382121322}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382121383}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382121442}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382123847}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382123915}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382124016}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382124132}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382135851}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382135940}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382136011}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382136069}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382154082}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382154164}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382154229}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382154296}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382171296}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382171380}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382171443}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382171508}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382199043}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ame"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382199114}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382199169}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382199233}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382206180}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382206250}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382206338}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382206494}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382224700}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382224751}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382224791}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382224831}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382251617}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382251705}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382251786}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382251849}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382274807}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382274904}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382274966}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382275023}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382275206}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382275279}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382275342}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382275400}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382311993}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Look"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382312066}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382312268}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382312360}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382399587}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382399670}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tool"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382399735}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382399801}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461105}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461196}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_nz022hljnylaadoyczwmyaxt","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461275}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461349}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461419}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461483}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461545}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382461610}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500255}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500332}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500392}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500452}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500535}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"eline"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500597}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500666}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382500705}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382520705}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382520788}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382520854}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382520934}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382547709}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382547780}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382547841}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382547899}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382570500}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"short"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382570587}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382570693}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382570762}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382570846}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382570911}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382570974}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382571033}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382581962}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382582042}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382582108}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382582172}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382600479}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382600571}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" fc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382600635}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382600704}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382600824}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382600890}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382602081}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382602147}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382621435}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382621505}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382622106}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382622172}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382634216}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382634313}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382634378}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382634431}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676225}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676345}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" fc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676426}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676488}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676647}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676711}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676803}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382676892}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382700934}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382701045}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382701289}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382701372}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382731463}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382731538}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382731650}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382731963}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382732065}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382732248}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382732338}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382732403}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382805595}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382805650}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382805723}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382805784}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382825128}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382825211}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382825451}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1004,"ts_us":1792973382825532}}

data: {"id":"2caba1204ef5b6c83b5b7eafdc86438d","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":6964,"completion_tokens":248,"total_tokens":7212,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":6016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":10,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1004,"ts_us":1792973382882965}}

data: [DONE]

