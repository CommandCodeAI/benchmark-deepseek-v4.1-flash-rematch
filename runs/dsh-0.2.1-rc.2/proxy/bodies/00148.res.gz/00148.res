data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978106464753}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107328008}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107434560}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107450489}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107450557}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107466356}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" replacement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107466423}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107481878}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_X2vf9mOjgtZr3ZeUO1cC4471","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107516347}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107531409}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107531490}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107531609}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107531672}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107531739}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107554795}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107554880}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107554955}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107555006}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107555047}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107562187}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"stat"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107562242}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-number"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107562322}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107562402}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107562474}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107579904}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107579987}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107594863}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107594936}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107594985}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107612484}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107612540}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/app"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107612584}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107612640}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107612672}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107612723}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107651460}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107651547}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107651627}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107651693}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107651777}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107651849}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107651941}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107652037}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Led"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107652105}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107659395}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".innerHTML"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107659479}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107675030}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107691138}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107691227}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107691289}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107691381}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107691443}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107706558}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107723043}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107723159}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107723227}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107723285}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107723349}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/app"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107723391}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107739359}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107739413}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107739467}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107739522}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107739563}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107739626}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107755175}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107755227}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107755287}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107755350}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107755427}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107755462}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107772903}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107772973}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107773028}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107773086}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107798443}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107798520}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107798590}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107798658}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107798719}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/app"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107798785}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107804633}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107804693}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107804772}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107804856}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107804923}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107819586}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107835909}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107835972}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107836014}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107836075}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107836123}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107854030}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Verify"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107854115}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ledger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107854178}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107868145}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" stats"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107886332}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" unit"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107886413}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107886473}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107901544}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2427,"ts_us":1792978107901594}}

data: {"id":"65bacdb987c8ca5b75d496cf8f884ce3","object":"chat.completion.chunk","created":1792978106,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":543759,"completion_tokens":135,"total_tokens":543894,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":542592,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":7,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2427,"ts_us":1792978107936627}}

data: [DONE]

