data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212495410}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212537856}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212537956}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212538063}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"36 results in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212618929}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212619013}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212619094}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212619131}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212704052}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Shri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212704395}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes hit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212704455}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212704652}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 64 often"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212760418}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212760767}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212760837}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212760892}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soft damp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212835149}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212835431}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212835478}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 36 default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212835711}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yields"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212921927}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212922162}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212922302}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212922457}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212983860}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-180"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212983945}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 plants and "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212984020}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974212984234}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moths all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213071706}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213071810}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213072016}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shrike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213072099}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213181905}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 64 common"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213182001}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213182074}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213182150}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64 sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213234668}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213234742}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213234882}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213234932}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213322240}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213322311}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could raise hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213322523}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213322763}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100 and soft density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213395278}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keeps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213395328}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213395371}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213395433}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213458666}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213458740}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213458840}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reach 64 due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213459170}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213539037}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213539102}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" larger cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213539140}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213539835}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dependent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213601272}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213601525}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213601571}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213601635}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 64 vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213684637}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soft 34:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213684857}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213685042}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-(64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213685090}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/34)^2.15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213783053}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213783143}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" negative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213783335}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -> clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213783582}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .035, so few"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213882369}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213882440}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213882540}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213882628}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64 is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213978426}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reached though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213978553}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213978764}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard cap they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974213978817}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might go"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214046287}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214046365}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"70. Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214046423}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a big flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214046485}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214114541}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" raise hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214114608}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap to 90,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214114731}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resulting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214114778}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214196920}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes but maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214197001}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214197198}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214197277}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214306354}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214306435}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be adjusted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214306583}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214306683}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n\nFor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214436683}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214436762}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-looking"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214437004}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214437063}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214457525}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214457606}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rarely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214457703}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hit if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214457786}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214527659}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" > expected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214527735}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214528999}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"36, many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214529045}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214596506}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214596554}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64 indicates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214596621}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214596681}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214678770}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214678911}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Raise MAX"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214679144}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_SHRIKES"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214679198}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 100. Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214725238}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214725310}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reach"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214725530}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 70,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214725583}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214815910}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214816137}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pressure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214816211}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214816272}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214899810}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214900056}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214900111}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214900155}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dependent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214963498}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214963547}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .035"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214964698}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974214964741}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215045062}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215045120}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215045165}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" artificial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215045221}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215146365}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leave"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215146428}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215146488}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215146532}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215188590}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215188638}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" notice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215188735}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nFood "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215188851}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215280380}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215280463}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" balance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215280525}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215280589}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215348881}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fewer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215348974}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215349045}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215349107}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28, WEST"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215428989}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215429195}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ERE-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215429261}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"07 final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215429424}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215506831}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"741/308"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215507163}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/35; avg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215507213}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215507466}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1558, moths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215611687}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"301"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215611767}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", shri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215611840}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes47. GL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215611976}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ASS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215657554}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215657830}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 449"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215657915}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/333"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215658059}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/29. Most"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215730766}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215730833}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215731427}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UREL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215731504}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IA-4 all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215848126}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Some sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215848204}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215848338}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215848453}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 64 but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215882660}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215882724}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Food "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215882778}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28 might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215882853}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be a sweet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215962350}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spot. Control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215962415}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215962661}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28 units seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974215962735}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216044421}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216044500}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0–48"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216044554}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216044659}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216124505}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28, max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216124564}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe 48"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216124780}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Actual reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216124920}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth slider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216189952}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" currently max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216190087}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216190268}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64; design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216190311}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sensible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216304176}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216304273}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2–48."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216304433}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216304483}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clamp "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216340269}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-64."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216340428}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216340473}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range 2-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216340552}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"48. Default "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216443391}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"28. \nFood"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216443570}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216443633}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216443681}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216487923}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216487997}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"155"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216488096}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 avg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216488201}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants, 301"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216554274}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216554499}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moths, 47"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216554549}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216554658}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216625603}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216625671}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216625727}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; lovely."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216625778}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216713168}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216713238}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2400, increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216713422}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216713477}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 261"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216764958}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216765012}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216765109}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216765274}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216858755}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216858811}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nAt "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216858853}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216858903}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216914268}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" die"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216914371}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-offs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216914479}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216914694}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216992384}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216992486}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216992591}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nDefault"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974216992637}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217068160}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217068214}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=240."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217068262}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plant count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217068393}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217135381}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217135643}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217135806}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217135852}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217237574}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217237624}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217237720}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217237948}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" MAX"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217296123}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_SH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217296390}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"RIKES hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217296439}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 64 issue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217296527}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217449884}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food28,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217449950}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217450002}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike 35"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217450523}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217476299}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217476349}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217476494}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217476546}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217611155}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" census chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217611253}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217611507}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217611588}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217624857}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 64 for maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217624950}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some period"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217625175}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217625264}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217674772}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217674866}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217675140}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217675223}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" point. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217760624}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217760690}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217760865}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can style chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217760914}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y-scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217873395}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217873466}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217873525}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"70"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217873571}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217929078}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flat line at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217929147}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top would show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217929414}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We could draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217929466}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217997006}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217997060}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"room to max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217997103}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974217997154}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.1. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218072797}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218072911}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" period"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218072996}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218073047}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be visible near top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218161924}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Not a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218162005}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deal breaker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218162207}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218162335}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can raise cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218233421}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 96"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218233471}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218233878}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218233952}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218304961}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limit."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218305066}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218305130}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" larger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218305261}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218375345}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218375390}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- MAX_SH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218375710}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"RIKES 96"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218375758}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", soft "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218489797}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"34"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218489887}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" => same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218489934}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction suppression"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218490068}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218566394}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218566534}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exceed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218566590}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64 slowly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218566661}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218622349}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3.5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218622439}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218622477}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218622727}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218694061}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Likely settles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218694167}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218694330}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-70. Hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218694373}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218769437}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" touched.\n- MAX"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218769511}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_MOTHS 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218769619}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", soft "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218769684}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"360 => same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218865276}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218865541}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may exceed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218865612}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"360"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218865773}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218913138}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218913187}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \nThe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218913401}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974218913451}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limit maximum"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219001392}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219001445}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density-dep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219001547}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's raise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219001939}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219119756}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800/100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219119827}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219119995}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density handles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219120109}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219178461}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We should test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219178512}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outcome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219178853}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219178895}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yscbpzpf6yiovq579dgrgjvr","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219206884}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219206956}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219207160}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219207225}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219263844}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219264606}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219264693}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219264816}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219264878}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219265001}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219265073}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219265132}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219265179}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219265556}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219265622}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219265695}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219279241}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219279298}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219279429}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219279742}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219301974}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219302034}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219302090}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219302224}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219319891}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219319955}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219320135}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219320215}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219320580}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219321023}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219321292}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219321354}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219334969}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219335204}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219335311}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219335382}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219355228}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219355438}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219355511}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219355610}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219356112}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219356253}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219356450}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219356519}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219370300}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219370391}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219370500}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219370562}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390186}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390239}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390505}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390611}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390683}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390784}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390842}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219390893}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"HS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219411448}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219411681}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219411738}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"650"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219411785}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219429781}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219429839}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219429924}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219430102}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219430261}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219430328}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"HS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219430591}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219430644}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219447554}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219447604}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219448025}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219448085}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477071}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477141}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477275}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477362}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477529}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477587}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_SH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477822}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219477898}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219485285}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219485560}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219485610}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219485653}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219509859}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219509916}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219510002}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219510078}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_SH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219510177}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219510427}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219510490}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219510601}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219527611}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219527703}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219527792}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219527852}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219545916}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219546006}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219546120}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219546198}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219567183}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219567580}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219567631}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219567739}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219587594}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"36"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219587653}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219589810}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219589879}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219606908}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219606960}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219607073}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219607174}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219607420}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219607475}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219607529}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219607647}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219619705}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219619768}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219620461}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219620511}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219639090}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219639199}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219639268}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219639327}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219639649}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219639766}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219639981}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219640049}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219661866}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219661927}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219662093}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219662160}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219704335}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219704397}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219704559}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219704667}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219704990}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219705065}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219705209}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219705320}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219711704}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219711783}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219711852}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219711911}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219718149}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219718197}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219718253}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219718370}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219738102}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219738167}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219738304}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219738371}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219759064}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219759111}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219759223}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219759390}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219779973}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219780032}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219780084}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219780134}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219797898}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219797945}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219797999}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219798099}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219816540}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219816616}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219816676}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219816816}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219839501}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219839570}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219839680}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219839727}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219905154}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219905260}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219905367}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219905454}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219906438}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219906515}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219906593}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219906657}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219907108}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219907167}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219907326}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219907403}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219913968}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219914146}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219914249}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219914482}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219918257}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219918329}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219918443}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219918537}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219918903}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219919084}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219919206}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219919407}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219980181}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219980234}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219980284}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219980339}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219992584}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219992731}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219992790}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219992948}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219993498}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219993562}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219993631}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974219993714}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220001643}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220001704}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220001749}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220001838}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220006163}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220006236}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220006288}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220006379}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220010056}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220010116}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220010200}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220010299}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220017853}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220017905}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220018064}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220018116}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038158}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038212}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038262}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038312}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038359}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038446}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038544}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220038613}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220112786}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220112924}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220113000}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220113042}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220113183}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220113259}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220113363}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220113405}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176437}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176491}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176535}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176642}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176690}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176732}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176899}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220176952}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220177023}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220177484}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220177544}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220177594}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220190797}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220190865}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220191052}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220191130}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220207449}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220207520}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220207643}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220207699}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220207841}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220207967}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220208025}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220208066}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220208940}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220209014}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220209166}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220209329}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220211743}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220211817}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220212022}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220212073}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220214464}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220214625}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220214695}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220214747}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220221583}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220222374}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220222448}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220222513}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220222566}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220222639}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220222710}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220222884}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220240926}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220240979}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220241061}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220241138}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220260827}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220260884}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220260966}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220261082}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220261158}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220261563}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220261639}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220261819}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220281295}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220281516}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220281609}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220281681}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301182}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301271}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301337}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301438}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301817}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301884}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301955}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220301994}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220330651}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220330707}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220330777}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220330855}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220347326}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220347394}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220347443}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220347508}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220357374}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220357460}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220357526}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220357584}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220357702}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220357971}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220358071}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220358159}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220379578}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220379648}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220379785}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220379873}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220405548}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220405640}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220405858}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220405946}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220406085}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220406141}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220406220}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220406310}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220445649}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220445708}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220445759}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220445802}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220445891}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220445949}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220446004}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220446053}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220455311}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220455376}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220455417}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220455507}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220476480}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220476559}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220476618}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220476720}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220492014}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220492172}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220492252}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220492323}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220492500}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220492619}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220493224}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"07"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220493325}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220510249}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"NOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220510362}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"TH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220510436}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220510508}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537163}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537251}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537332}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537410}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537487}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537577}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537659}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220537740}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220550843}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220550947}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220551193}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220551274}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220588403}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IDE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220588500}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220588583}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220588659}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220593737}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220593881}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"URE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220593989}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220594085}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220594554}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220594645}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220594722}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220594791}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220612128}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220612233}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220612294}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220612349}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220641534}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"03"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220641645}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220641734}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220641813}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IGHT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220641893}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220641976}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220642054}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220642143}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220675205}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220675388}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ET"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220675565}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220675687}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220745356}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220745429}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220745495}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220745700}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220756748}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"11"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220756820}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220756896}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220756979}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220759640}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220759768}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220759858}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220759951}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220788112}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220788162}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220788226}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220788367}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220789094}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220789391}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220789447}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220789552}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220799324}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220799379}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220799421}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220799478}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220820763}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220820820}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220820880}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220820953}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220821107}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220821225}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220821400}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220821475}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220834452}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220834512}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220834653}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220834745}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220855849}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220855923}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220856111}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220856194}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220856321}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220856398}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220856455}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220856585}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220886736}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220886823}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220886966}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220887052}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220892903}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220892989}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220893166}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220893249}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220935246}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220935331}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220935581}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220935653}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220935960}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220936011}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220936064}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220936182}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220940514}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220940578}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220940714}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220940769}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220953390}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220953505}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220953550}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220953590}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220954454}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220954539}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220954585}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220954650}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220974291}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220974390}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220974457}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220974556}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220990955}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220991025}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220991103}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220991266}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220991700}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220991768}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220991838}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974220991911}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221014384}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221014437}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221014482}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221014552}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221045636}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221045691}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221045747}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221045812}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221045869}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221045941}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221046013}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221046054}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221047701}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221047767}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221047957}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221048008}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221080010}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221080324}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221080396}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221080442}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221101727}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221101829}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221101988}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221102043}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ra"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221126462}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ise"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221126540}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221126657}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" caps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221127755}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221238780}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221238851}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221238958}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221239022}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221302564}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221302649}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2524,"ts_us":1792974221302700}}

data: {"id":"b9b17089d0bda15ef3a8298b1b25f1b0","object":"chat.completion.chunk","created":1792974212,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":111558,"completion_tokens":1288,"total_tokens":112846,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":109696,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":730,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2524,"ts_us":1792974221306295}}

data: [DONE]

