data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969527706}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969570156}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" oscillations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969570228}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but coexistence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969570336}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969703452}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Shrike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969703574}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969703665}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hitting 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969703747}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" despite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969750622}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max 42 due births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969750769}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969750974}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969751048}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oth often"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969819345}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969819470}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 520."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969819553}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plants swing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969819866}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969887004}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"27–280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969887199}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0. In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969887545}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gest."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969887634}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need perhaps reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969961313}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969961523}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969961591}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973969962043}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970182858}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970182909}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moderate. More"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970183002}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" importantly, some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970183293}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970234266}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" snap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970234349}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"shots "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970234405}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"156"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970241280}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970330460}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"255"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970331493}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970331543}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/46 shrike looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970331608}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparse plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970463940}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970464008}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970464504}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Aesthetic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970464915}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would benefit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970550138}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970550464}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not dropping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970550577}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 27"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970551133}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970585327}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implement plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970585475}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970586208}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bank"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970586292}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" separate?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970630502}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or easier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970630573}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase food reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970630625}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth default to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970630693}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"35 and local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970747038}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeding; this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970747159}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will raise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970747513}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora minimum"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970747558}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970788133}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970788335}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970788523}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970788613}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rike control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970877440}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970877540}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s test regrowth defaults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970877606}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970877804}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate. Because control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970967306}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970967409}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970967650}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973970967725}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"22. Maybe set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971031482}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 32. Our current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971031569}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971031746}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971031894}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 22; initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971116327}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971116435}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1900. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971116538}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971116751}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 flora "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971186214}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"665, gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971186279}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60 767"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971186503}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", etc. Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971186561}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too few due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971486544}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971486613}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971487523}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrowth would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971487585}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" help. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971533916}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s test different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971534047}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971534266}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971534360}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971613656}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 40 +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971613742}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local rates."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971613800}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971613996}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971621465}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only for tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971621597}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971621886}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" options food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971621954}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Regrowth (runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971642740}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less accepts). But mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971642864}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971643017}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Use options."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971643116}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Initial premium."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971720488}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971720571}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971720620}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with food 32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971720723}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and 42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971781285}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971781404}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"033"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971781656}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971781721}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_2vtdfdzva5orir8xj8lvgfzd","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971806999}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971807164}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971807345}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971807511}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971811715}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971811902}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971812103}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971812176}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971816319}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971816387}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971816496}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971816539}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971879069}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971879170}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971880291}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971880344}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971880385}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971880425}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971880465}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971880508}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971895929}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971895982}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971896422}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971896536}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971906267}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971906531}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971906633}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971906828}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971923718}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971923808}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971924055}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971924117}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971928731}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971928877}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971928950}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971928989}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971935548}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971935665}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971935838}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971935888}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971958628}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971958798}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971958900}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971958954}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971980772}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971980867}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971980959}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971981052}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971981134}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971981203}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971981285}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973971981368}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972000043}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972000193}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972000342}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972000431}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972032872}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972033062}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972033137}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972033316}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972034270}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972034394}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972034799}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972034898}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972037708}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972037908}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972038040}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972038161}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972068492}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972068559}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972068782}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972068853}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972078632}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972078730}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972078792}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972078846}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972094833}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972094994}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972095137}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972095212}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972095785}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972095873}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972095999}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972096070}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972142013}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972142085}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972142140}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972142195}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972160811}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972160883}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972160944}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972161006}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972178068}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972178149}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972178215}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180093}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180289}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180354}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180415}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180478}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180554}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180672}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180742}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972180793}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972200753}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972200833}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972201070}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972201137}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972211482}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972211568}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972211753}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972211940}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972212100}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972212267}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972212327}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972212450}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972231519}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972231608}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972231669}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972231748}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972297290}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972297398}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972297478}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972297560}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972297637}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972297705}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972299245}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972300219}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972312685}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972312797}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972313363}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972313468}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972321479}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972321573}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972322219}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972322582}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972322672}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972322751}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972323475}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972323563}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972333233}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972333323}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972334516}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972334619}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972338476}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972338555}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972338640}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972338723}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972346777}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972346881}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972346968}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972347057}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972347141}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972347228}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972347314}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972347401}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972370726}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972370826}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972370911}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972371951}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972389083}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972389168}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972389465}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972389545}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972455701}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972455800}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972455883}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972455974}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972456059}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972456172}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972456320}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972456442}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972481338}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972481432}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972481506}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972481578}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499293}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499435}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499520}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499633}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499713}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499787}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499863}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972499934}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972507957}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972508056}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972508133}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972508213}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972517716}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972517824}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972517902}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972517996}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972518076}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972518165}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972518298}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972518383}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972544770}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972544871}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972544952}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545026}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545104}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545180}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545261}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545334}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545410}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545482}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545555}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972545628}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972547671}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972547773}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972547873}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972547950}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580423}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580496}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580571}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580642}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580713}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580783}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580852}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580925}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972580998}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972581068}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972581139}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972581207}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972597949}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972598049}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972598119}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972598181}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972635163}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972635298}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972635477}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972635536}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972641032}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972641119}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972641196}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972641263}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972662473}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972662559}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972662732}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972663210}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972679599}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972679687}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972679755}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972679822}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972743692}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inct"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972743764}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972743824}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972743977}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972766468}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Entries"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972766534}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972766773}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972766845}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972767010}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972767131}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972767208}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972767376}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972779413}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972779491}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972779547}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972779584}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972788979}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972789056}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972789195}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972789433}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972834896}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972834971}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972835066}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972835114}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972835506}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972835626}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972835876}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972835937}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972847517}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972847647}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972847740}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972847790}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972867660}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972867729}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972867833}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972867898}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972893108}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"??"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972893207}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972893349}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972893483}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972894172}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972894256}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972894344}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972894587}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972921048}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972921132}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972921272}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972921395}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972942428}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"36"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972942536}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972942604}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"44"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972942674}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972958233}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972958337}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972958481}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972958611}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972970471}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972970599}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972970680}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972971219}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972971885}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972971990}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972972107}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973972972929}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018130}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018192}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018252}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018435}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018484}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018549}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018619}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018676}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018747}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018791}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"07"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018835}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973018893}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973042419}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"URE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973042503}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973042573}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973042647}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973048852}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973048960}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973049012}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"NOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973049057}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"TH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973049479}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973049558}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973049709}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973049758}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973082968}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973083052}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973083215}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973083331}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973085653}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973085746}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973085867}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973086318}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973086469}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973086541}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973086709}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IDE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973086768}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973107206}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973107298}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973107406}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973107481}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973168865}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973168950}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973169210}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973169276}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973169782}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973169849}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973169904}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973169960}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973192187}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973192291}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973192527}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973192601}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973209356}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973209429}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973209488}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973209545}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973214545}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973214622}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973214690}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973214750}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973243379}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973243480}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973243700}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973243806}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973256605}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973256675}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973256788}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973257286}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973257335}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973257825}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973258234}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973258281}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973277793}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973277883}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973277956}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973278027}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973299028}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973299112}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973299236}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973299351}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973321609}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973321699}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973321841}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973321947}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973350264}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973350347}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973350441}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973351183}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973354776}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973354892}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973354989}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973355133}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973355234}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973355460}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973355527}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973355585}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973379537}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973379620}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973379720}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973379775}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973395312}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973395385}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973395474}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973395783}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973395906}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973396248}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973396306}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973396371}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973435494}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973435578}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973435637}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973435729}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973445994}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973446058}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973446104}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rike"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973446239}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973446519}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973446712}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973446834}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973446932}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973499833}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973499945}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973500032}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inct"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973500196}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973512193}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973512278}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973512523}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973512633}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973517589}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973517693}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973518079}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973518152}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973519499}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973519578}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973519715}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973519793}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973519956}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973520419}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973520548}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973520702}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973532108}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973532212}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" effects"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973532302}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973532377}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2586,"ts_us":1792973973592360}}

data: {"id":"1e84f40acf31b7a584efa196afce0ff6","object":"chat.completion.chunk","created":1792973969,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":84682,"completion_tokens":736,"total_tokens":85418,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":79872,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":248,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2586,"ts_us":1792973973592478}}

data: [DONE]

