data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816795671}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816845285}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" job finished. Read."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816845338}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5ildotphizz39wlqc63oauuj","type":"function","function":{"name":"job_output"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816846016}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816866149}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816866265}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"job"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816866382}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816866479}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816873010}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816873082}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816873135}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816873197}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816890452}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"54"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816890538}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816890612}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816890745}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816903624}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816903717}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"045"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816903820}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816903931}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816905239}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816905292}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816905346}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977816905392}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16532,"ts_us":1792977817025631}}

data: {"id":"7646a2f86402333fe9980327a711e2d7","object":"chat.completion.chunk","created":1792977816,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":507117,"completion_tokens":56,"total_tokens":507173,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":504704,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":6,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":16532,"ts_us":1792977817025756}}

data: [DONE]

