data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978216854799}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Oops"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978217857999}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218078661}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accidentally"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218095354}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" started"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218110450}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218145524}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218145578}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218157541}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218157593}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" again"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218157646}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218157705}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218176385}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"&"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218176454}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218176508}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218176569}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218193516}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" will"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218193591}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218207347}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218207426}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218207472}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218234623}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218234693}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"33"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218234759}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218247510}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218247588}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218247657}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218258741}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" call"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218258803}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218258846}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"node"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218278430}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218278513}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218295247}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218295294}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218295369}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218295432}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218305531}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218305618}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/null"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218305681}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218305719}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218305792}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">&"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218305864}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218335810}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" &"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218335882}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218335935}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218335982}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" echo"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218336033}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" returns"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218345697}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218359258}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218359333}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218359386}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218359453}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218380113}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" process"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218380195}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218395231}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tracked"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218395311}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218395383}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218415110}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218415216}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" job"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218438589}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218438678}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218438741}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218439049}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" launched"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218439117}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218439227}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218458661}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shell"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218458741}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218458823}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" &"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218458883}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218477209}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218492569}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shell"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218492644}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exited"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218508955}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218509044}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" node"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218509107}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218509171}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" continue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218528229}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557258}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557337}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557406}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" kill"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557471}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557606}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557671}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" avoid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557753}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extra"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557839}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218557891}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218564272}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218564364}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" conflicts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218587118}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218587171}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218604761}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218604821}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" writes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218627441}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" except"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218627517}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218627735}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218627796}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/null"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218650552}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218650616}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218650668}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218658482}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kill"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218675053}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218675120}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218675177}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218675230}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218698747}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218698860}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" relevant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218708614}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218728477}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_pxriG9xAJItp7G4Z2uso8635","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218756818}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218780289}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218780371}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218780436}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218780499}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218780559}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218800574}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218800649}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"kill"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218800708}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218800769}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218800828}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218800889}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218816091}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218816161}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218822094}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218822173}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218822238}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218822300}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218822377}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218822446}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218844289}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218858143}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218858213}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218858297}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218859261}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218879315}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218879395}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218879463}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218879534}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218879596}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218879658}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218895623}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218895692}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218895752}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218895813}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218895871}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218895935}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218919149}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218919231}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218919294}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218919378}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" pg"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218919461}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218919548}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218923082}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"af"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218923179}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218923301}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218923384}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218924490}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218924593}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218936397}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218936463}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218955023}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218955098}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218981688}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218981764}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218981827}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218981885}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218994723}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218994792}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Stop"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218994847}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" accidental"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978218994910}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" background"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978219003440}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978219019207}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" process"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978219019299}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978219035270}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2186,"ts_us":1792978219035325}}

data: {"id":"2e1e45f3cce011579da0576d82b8709f","object":"chat.completion.chunk","created":1792978216,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":574171,"completion_tokens":207,"total_tokens":574378,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":573824,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":106,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2186,"ts_us":1792978219084093}}

data: [DONE]

