data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740860912}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740883080}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Instrument Sans"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740883308}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might variable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740883440}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file same URL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740933673}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for weights"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740933901}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; likely variable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740934195}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973740934517}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" support "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741014791}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400-700"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741014857}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741014912}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Cormorant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741014963}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741091854}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741092342}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per style"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741092417}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" covers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741092545}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weights? Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741169644}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" static but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741169696}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has all?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741170149}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could declare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741170199}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font-weight range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741277944}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" without issue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741278106}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Better just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741278368}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" download Corm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741278402}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"orant normal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741331100}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and italic ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741331194}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741331284}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variable-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741331538}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?) and Instrument"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741400495}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Sans,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741400542}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" IBM Plex Mono "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741400593}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400/500. Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741400638}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" @font-face weight"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741484109}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ranges. Browser can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741485237}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use synthesize if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741485316}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needed. Corm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741485381}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"orant 400-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741620277}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"600 likely the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741620339}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same file contains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741620439}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variable weights"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741620875}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Size"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741675647}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741675842}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741676173}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1hhjqi2xwzb8ed2ntqfbylua","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741676226}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741676599}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741676690}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741676763}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741677307}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741707424}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741707563}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741707703}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741707772}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741710074}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741710137}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ont"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741710269}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741710411}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741710650}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741710761}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" u"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741711328}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741711423}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741728820}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741728892}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741729024}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741729111}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741764505}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741764556}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741764613}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".com"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741764676}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741764747}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741764798}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741764984}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"or"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741765031}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741785406}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gar"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741785483}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"am"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741785620}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ond"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741785734}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741793677}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"21"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741793737}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741793799}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741793845}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741819220}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Zm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741819597}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"X"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741819707}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741819759}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741819940}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"CN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741819992}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"u"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741820175}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"HL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741820238}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741831938}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741832228}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741832527}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741832577}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741852749}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741852808}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"MK"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741852852}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741852902}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741855149}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"WM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741855213}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741855266}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"j"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741855310}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741878517}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741878591}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Et"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741878663}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741878756}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"So"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741891483}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741891684}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741891746}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741891832}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741907801}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741907862}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741907989}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741908085}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741908548}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741908622}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741908778}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973741908854}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742021180}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".com"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742021272}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742021328}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742021397}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742025464}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"or"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742025524}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742025646}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gar"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742025685}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"am"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742026071}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ond"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742026137}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742026649}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"21"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742026693}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742029336}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742029400}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742029489}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742029576}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"X"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742032537}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742032599}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742032716}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"CN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742032794}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"u"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742033283}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"HL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742033504}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742033557}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742033587}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742034311}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742034437}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742034488}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742034536}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"MK"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742040865}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742040911}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742040951}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"WM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742041016}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742041065}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"j"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742041111}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742041163}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742041202}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Xt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742055150}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742055253}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742055373}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742055513}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742065514}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742065576}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742065674}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742065744}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742065814}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742065953}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742066019}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742066066}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742087784}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742087838}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".com"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742087926}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742088089}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742127722}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"struments"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742127794}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ans"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742128002}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742128064}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742156675}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742156755}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"px"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742156916}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742156995}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Typ"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742202045}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742202107}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742202253}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742202345}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742246163}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742246271}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"051"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742246402}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"U"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742246608}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742246785}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742247076}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742247159}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742247259}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742280872}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742281039}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742281112}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742281217}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742323830}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742323929}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742324016}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742324153}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742324233}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742324330}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"To"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742324459}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742324541}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742328845}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742328949}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742329030}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742329182}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742345227}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ze"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742345340}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742345520}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742345626}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742345789}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742345869}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742346105}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742346212}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742366277}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742366380}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742366450}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742366499}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742378872}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742378958}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742379032}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742379169}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".com"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742379723}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742379852}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742379938}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742380005}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742404972}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plex"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742405052}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mon"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742405093}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742405225}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742417934}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742418014}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742418154}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742418211}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"63"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742434783}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fj"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742434899}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742434986}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ag"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742435104}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742458048}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742458138}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742458201}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742458269}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742519287}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742519365}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742519442}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742519523}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"U"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742521355}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742521451}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742521527}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742521596}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742522002}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742522074}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742522244}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742522337}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742522732}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742522832}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742522959}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742523006}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742576447}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742576525}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742576653}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742576732}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742577504}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742577555}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fonts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742577623}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742577685}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742586655}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".com"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742586747}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742586841}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742586912}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742630945}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742631002}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plex"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742631090}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mon"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742631173}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742631259}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742631316}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742631362}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742631452}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742635278}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742635361}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742635479}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fj"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742635756}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641046}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ag"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641102}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641228}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641280}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641502}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641725}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641805}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742641869}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"q"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742664627}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742664714}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"U"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742664782}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742664847}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742710263}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742710343}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742710475}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"J"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742710565}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742729210}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742729292}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742729358}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742729430}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742730004}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742730528}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742730592}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742730666}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ;"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742735150}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" do"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742735204}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" curl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742735262}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742735318}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742741575}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742741655}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742741720}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"O"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742741794}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742767769}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"u"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742767850}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742767921}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" done"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742767986}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742768066}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742768143}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742768205}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742768270}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742783414}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742783504}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742783573}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742783634}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742813619}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742813719}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742813780}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742813871}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742831230}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742831324}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742831393}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Download"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742831569}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Latin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742853003}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" WO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742853061}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742853173}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742853329}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742893514}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" files"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742893626}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742893717}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1656,"ts_us":1792973742893796}}

data: {"id":"f2b004769d382f5aa0d9f05b44447dcd","object":"chat.completion.chunk","created":1792973740,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":48377,"completion_tokens":438,"total_tokens":48815,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":47616,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":106,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1656,"ts_us":1792973742921311}}

data: [DONE]

