data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151068709}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151114445}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height 1014 > view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151114536}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port 900; instrument"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151114616}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel 870 height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151171711}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exceeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151171814}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151172081}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-height? It starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151172169}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 96 ends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151291622}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 966, because max-height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151291757}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calc(100vh-30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151291975}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")=870 but starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151292016}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 96, extends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151356756}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151357258}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151357322}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Since sticky"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151357886}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top 15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151434406}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151434705}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151434753}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151434902}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"96 because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151518066}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151518115}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appears after header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151518295}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151518526}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sticky"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151600940}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top 15 but it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151601677}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems at y96."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151601726}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It should be sticky"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151601776}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151755080}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y 96. Page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151755153}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height 1014 ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151755408}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151755495}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" beyond"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151793398}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At 900 screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151793480}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151793587}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page includes "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151793647}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1014. Need fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151884199}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" main better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151884297}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe performat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151884347}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Instrument"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151884491}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151976778}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 870, top "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151976874}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"96 -> 966, page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151976958}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975151977051}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" beyond."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152036803}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152036873}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-height 870? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152037510}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s actually "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152037596}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"870 exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152140233}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (calc(100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152140339}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"vh - 30)=870"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152140465}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152140547}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sticky"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152301922}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152302014}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"15 means max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152302091}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" available should be "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152302161}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"885. It extends below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152372876}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" viewport (96"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152373009}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+870=966)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152373110}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152373237}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height relative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152416293}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152416380}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152416442}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152416527}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152484068}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if sticky"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152484153}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152484222}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrolls, panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152484284}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top at 15 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152558099}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152558152}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 870 fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152558188}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152558225}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152648427}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" On initial,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152648696}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152648747}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occupies."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152648793}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152834700}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-page "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152835164}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1014. Design likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152835228}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152835709}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152869153}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port not full page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152869510}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But we want page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152869822}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" composition fit within 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152869993}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152941409}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" possible. Need view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152941474}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152941833}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's open image"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975152941900}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153027629}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ckn455f6re24cjv7soc3nyf0","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153027695}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153028030}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153028091}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153028905}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153028991}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153029037}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153029085}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153029673}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153029950}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153030453}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153030598}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153051591}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/main"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153051653}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153051696}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153051765}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153074849}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153074902}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153074963}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5898,"ts_us":1792975153075020}}

data: {"id":"2c6e459b065d19cf2450a4f6f9cc48ed","object":"chat.completion.chunk","created":1792975150,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":261826,"completion_tokens":296,"total_tokens":262122,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":260608,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":249,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":5898,"ts_us":1792975153171512}}

data: [DONE]

