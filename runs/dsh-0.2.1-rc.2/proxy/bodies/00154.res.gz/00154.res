data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978196870119}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Oops"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197596585}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197771984}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197799147}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197799212}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197807252}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"iner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197807311}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197807363}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exploded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197807414}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197821386}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" checking"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197821453}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197835658}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197853770}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tags"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197853828}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197853889}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197867824}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197867875}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".split"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197867956}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"('<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197883788}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197883858}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"')"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197883911}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197883965}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" printed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197884021}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197899705}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" massive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197899778}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chunk"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197915623}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197915689}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197915744}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197942311}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197948379}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197948449}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197948507}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197948573}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" confirm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197948662}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197963632}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197963702}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197963747}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197979295}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197979368}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197979418}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197979463}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197994877}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978197994959}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198033378}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198033449}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198033506}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198033539}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198033591}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198033635}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198046011}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" random"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198059772}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198059846}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198059890}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fetch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198059942}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198077289}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198077349}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198077390}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198077463}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198077515}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198077552}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" very"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198094476}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" long"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198094533}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198132517}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198132581}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198132637}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198132693}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198132750}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198132803}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simply"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198132854}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198141742}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"g"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198141806}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198156573}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" '<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198156618}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198156660}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198156699}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198171939}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198171992}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198172042}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_A5V6OtcfNj50jCnoEBte7172","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198205898}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198220043}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198220117}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198220166}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198237413}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198237459}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198237519}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198237568}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297542}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297591}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297635}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297709}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"link"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297756}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297835}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297911}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198297959}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]*"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298005}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298041}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298085}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298151}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298220}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298252}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298283}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298328}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298429}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198298471}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198306049}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198306118}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198306171}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198306234}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198306282}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198319086}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198319133}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198319193}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198319246}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198319291}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198336780}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198336849}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198336908}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198336968}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198337021}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198355132}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198355235}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198355288}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198355351}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198355413}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198355462}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198368446}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198368502}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198368550}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198368596}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198368655}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198385898}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198385951}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198386022}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198386106}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198386157}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198386193}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198418928}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198418989}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198419064}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198419149}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198419213}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198422397}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198422477}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198422575}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198422640}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467204}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467257}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467311}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467367}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467419}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467459}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467502}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467539}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467581}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467612}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467673}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198467692}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198468717}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198468814}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198468880}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198468922}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198468970}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198469034}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198488785}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198488874}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198488942}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198488993}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198489056}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198489094}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198506149}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198506204}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198506257}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198506300}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198506353}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198506398}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198534649}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198534701}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198534793}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198534883}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198534955}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198535047}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198535147}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198535250}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198535353}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198535435}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198535495}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198535584}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198549386}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198549461}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198549521}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198549579}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198549629}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198549696}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198572502}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198572580}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198572658}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198572732}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198572808}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198572972}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198580055}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198598030}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198598081}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198612752}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198612814}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198612868}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198612949}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198613037}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198613100}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198629100}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198629152}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198629238}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198629318}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198644203}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" )"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198644287}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]*"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198662445}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198662494}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198662576}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198662660}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198662718}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198662758}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198679169}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198679252}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198679305}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198679363}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198679424}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198679488}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198693361}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198693413}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198693478}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198693552}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198693613}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198693652}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198710119}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198710201}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198710253}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198710302}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198710362}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198710412}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198725436}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198725511}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198725581}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198725644}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198725704}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198725784}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198741351}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198741416}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198741475}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198741538}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198741577}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198741614}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198763777}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198763852}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198763951}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198764025}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198764088}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198764148}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198773950}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198774024}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198774078}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198774128}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198774177}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sort"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198774216}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198788508}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"u"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198788584}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198788636}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198805585}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198805654}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198805731}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198821789}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198821840}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198821879}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Confirm"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198821918}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" fav"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198837823}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"icon"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198854312}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" inline"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198854366}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198854432}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" URL"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198854474}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" references"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198870251}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198870301}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1955,"ts_us":1792978198887493}}

data: {"id":"315cd254a4bfa0232c1cf65ec92eeb34","object":"chat.completion.chunk","created":1792978196,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":571874,"completion_tokens":314,"total_tokens":572188,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":555392,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":77,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1955,"ts_us":1792978198921439}}

data: [DONE]

