data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978226593937}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227583920}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227685120}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227727395}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227727467}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227727518}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227727633}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227727683}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"af"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227750982}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" matching"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227751060}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227751114}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227751153}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227751198}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227761771}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227780655}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227780695}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227780753}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" containing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227780797}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227798987}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" string"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227822938}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227822979}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227823029}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" printed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227823094}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" system"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227823182}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" processes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227823227}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227823262}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227846982}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pattern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227847030}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227861165}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227861206}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227884488}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227884540}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227884585}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227884650}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" node"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227884746}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227884787}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227906297}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227906345}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227916643}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227916697}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227916732}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stopped"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227935279}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227935337}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227935381}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227946869}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227946931}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227946984}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227959798}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" needed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227959843}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227980226}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227980295}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227980336}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227980390}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227993780}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227993833}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978227993885}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228024495}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228024546}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228024594}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228024663}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228024702}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228025896}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228025943}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228026002}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228043433}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228059548}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228059610}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228059664}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"??"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228059717}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228078357}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" made"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228078419}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228090442}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228105360}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228105435}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228105490}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228105535}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228120038}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228120100}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228120150}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" workspace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228120190}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228120237}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228136537}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remained"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228136594}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228154079}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228154161}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228154266}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228154315}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228154381}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228154433}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228174642}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228174684}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228183862}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228183935}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228183984}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228202422}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228202523}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228202600}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228202671}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228218976}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228219052}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228219119}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228233131}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228233180}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228233220}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228233386}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228233464}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228253293}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228253334}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228266613}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228266664}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228289065}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228289132}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228289186}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228289226}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228289273}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228289312}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" made"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228300348}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subsequent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228300416}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228300468}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228316088}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228316168}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grammar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228335506}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228350065}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228361705}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228361751}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228361798}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228378414}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228378467}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" around"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228378509}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228393573}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228393636}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228393701}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"31"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228393784}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228409126}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228409185}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228409256}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228409336}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timestamp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228428383}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228428457}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228428503}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228457024}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228457117}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228457185}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228457270}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228463855}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228463934}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228464001}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228479963}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228480068}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228491170}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228509783}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228509863}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228509931}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228524584}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228524666}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228538214}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228538289}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228554111}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" were"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228554190}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228554249}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228569221}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228569298}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228569362}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228593727}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228593806}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Actually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228593874}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228593939}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228611611}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228625389}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" started"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228625476}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228655077}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" around"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228655209}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228673892}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228673954}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228674004}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228674051}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228674341}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228674397}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228674447}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228674494}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228695745}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228715635}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228715733}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228715790}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verify"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228715844}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sync"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228715918}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" between"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228716062}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228738486}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tmp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228738552}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228738612}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228755295}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228755357}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228755414}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228755481}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" workspace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228755530}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228755576}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228766508}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228766574}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228766622}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228766672}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" built"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228779122}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228798845}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copied"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228798941}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228812090}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228812138}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228828988}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228855191}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228855251}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228876005}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228876095}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228876156}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228876284}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228876336}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228891030}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228891117}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228891164}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228906857}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tmp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228906946}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228907004}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228907044}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228907089}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".py"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228907152}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" &&"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228926667}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228926716}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228926771}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228941782}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228941868}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228941911}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228962307}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228977367}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228977437}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228977489}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228977518}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228999180}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228999256}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978228999315}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229016732}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229026290}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229026352}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229026429}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229046595}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229046692}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Apply"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229046780}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229059988}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229060086}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fixes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229073438}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229073494}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" smoke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229073574}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229084886}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229084981}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229085051}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229099476}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229099538}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229099590}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229099642}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229116433}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tmp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229116484}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229116537}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229116578}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229116628}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".py"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229116665}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229131698}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229131736}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229131775}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/null"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229131809}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" &&"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229131845}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229131879}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229152923}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229152972}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229162711}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229162775}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229162856}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229162929}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229180946}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229200607}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229200665}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229200724}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Wait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229212492}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229212562}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229212616}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229212676}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229212738}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229241030}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" added"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229241080}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229241166}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229246377}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229246431}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ran"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229261278}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229275316}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229275362}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229275400}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229294773}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229294834}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229294913}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229309842}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229309954}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ring"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229323306}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"(p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229323401}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229341375}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229341485}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"...\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229341572}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229341654}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229355560}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229355622}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229371777}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229371858}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229371926}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229372004}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229392927}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229392975}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229393037}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229393101}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229393153}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229405181}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229405242}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229405291}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229429823}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229429932}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229430035}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229443086}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229443128}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229443165}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229453957}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229454026}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" started"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229470009}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229486655}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Apply"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229486723}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229499714}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229499788}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fixes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229499850}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229499896}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" smoke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229499949}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229499997}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229515283}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229515342}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" included"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229515384}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229532235}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229532319}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229532370}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" near"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229532438}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229556616}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229566555}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229566616}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" smoke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229566663}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229579747}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" passed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229579811}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229599926}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229599974}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229600014}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229600049}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229600082}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ran"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229614934}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229631745}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229631794}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229631861}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229654494}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229654554}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Actually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229654638}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229666708}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229666775}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229681917}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" occurred"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229681998}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229695096}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229710176}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229725261}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229725320}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229725356}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229745123}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229745187}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229745226}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229760853}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229760904}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" recount"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229760949}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229760989}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229780789}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229780886}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229780935}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229790439}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229790481}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229805410}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229805502}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" where"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229831429}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229856582}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" added"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229856643}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229856692}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229856810}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229856853}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229856886}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" printed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229874199}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229887266}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229887339}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ring"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229887402}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"(p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229901126}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229901191}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229901235}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229918618}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229918690}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229933741}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229933817}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229933876}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" print"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229950128}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229950217}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229965837}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229965915}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".split"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229984115}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"('<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229984206}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229984267}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"')"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978229984345}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230029396}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230029489}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230029562}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230029723}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230046175}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230046256}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230046328}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230063572}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230063654}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230063856}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230063944}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230064019}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230084906}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230084988}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230085070}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230097990}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Wait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230098063}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230098116}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230116528}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230116614}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230116656}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230116694}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230128875}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230145800}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230145880}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230145924}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230159843}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230159904}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Looking"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230159948}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" up"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230160019}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230174274}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"   "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230174332}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230174412}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230174467}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230200690}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230200761}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230200825}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230204860}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230204921}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230204958}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230224114}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230224173}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" titled"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230224219}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230238348}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Polish"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230238410}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230238467}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230260620}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230260689}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230260742}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230260812}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230260882}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230281385}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230289251}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230289310}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230302425}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230302489}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230302545}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"   "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230302604}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230302693}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230302727}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230317693}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" smoke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230317745}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230334864}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" showed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230334946}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230335013}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230352085}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230375920}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230375992}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"   "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230376046}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230376089}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230376135}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230376195}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" decided"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230393198}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230393259}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230401054}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230401107}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230401158}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230401210}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230401259}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230418425}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230418467}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230418539}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230434654}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230434717}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230434775}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230448499}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230448569}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230448633}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230466493}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230466556}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" printed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230466596}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230479211}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230479302}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230496506}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"   "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230496564}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230496621}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230496687}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230496738}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230496780}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230512223}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230529303}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230529371}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230546202}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230577820}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"   "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230577878}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230577918}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230577964}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230578010}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230578059}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230592863}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230611401}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" integrity"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230624072}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230643319}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230643434}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"acc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230655835}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"identally"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230697571}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" launched"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230697642}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230697683}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230776563}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230776665}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230776715}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230776753}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230776853}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Actually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230776937}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230776990}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230777250}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230777312}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" appeared"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230777496}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230793656}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" adding"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230793697}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230808373}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230808415}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230808470}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230808510}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230808561}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851292}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851341}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851405}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851533}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851588}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ring"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851640}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"(p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851696}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851877}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230851960}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230852023}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230929086}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230929225}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230929282}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230929407}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230929459}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230929647}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230929703}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" split"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230946120}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978230961262}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231003643}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231003708}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231003892}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" entire"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231003942}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231004076}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231004127}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231004200}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231017182}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" split"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231017241}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231017300}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231030052}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" printing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231045379}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231045441}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231067844}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"mm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231083817}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231083878}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231083931}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231102454}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" confusing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231118004}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231118132}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231135220}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231135279}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" copy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231135352}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231148936}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231164659}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231176984}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231217169}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231217241}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231239736}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" workspace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231239789}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231256514}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231256573}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231256635}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"01"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231256754}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231273650}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"29"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231273738}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231273796}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231273857}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231273922}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231312187}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231312266}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231312325}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231312387}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231312498}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_OdGQ0QjTK7fAznS5l5205988","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231343953}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231344041}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231344098}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231356577}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231356638}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231356722}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231356817}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"date"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231370351}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231370416}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"u"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231370481}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '+"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231370567}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231370634}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231370687}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231389439}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231389511}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231389593}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231389648}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" %"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231389727}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"H"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231389859}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231408321}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231408403}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231408465}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231408532}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231408616}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231408681}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231422934}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231423013}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231423068}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231423113}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231423202}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231449780}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231449854}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231449920}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231449984}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231450047}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231455112}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231455189}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231455244}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231455300}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231455354}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231455409}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231471647}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231471698}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231471784}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231471851}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231471907}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231471953}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231486775}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231486850}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231486926}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231486989}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231487044}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231487096}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231503570}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231503650}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231503710}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231503778}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231503844}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231503896}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231520020}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231520079}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231520169}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231520251}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231520329}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231536678}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231536777}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231536853}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231536944}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231537037}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231553598}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231553697}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231553785}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231553868}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231553947}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231554026}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231589725}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231589814}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231589894}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231590224}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231590303}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"_ex"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231590378}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"it"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231599469}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=$"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231599549}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231599620}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231599689}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231599759}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231599839}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231617970}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231618068}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231618154}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231618231}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231618308}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231618383}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231631828}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231631923}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231632004}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231632075}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231632162}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231632251}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231681809}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231681909}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231681990}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682070}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682146}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682223}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682301}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682370}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682472}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682558}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231682634}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231683229}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231683328}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231683406}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231683481}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231683555}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231683627}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231702780}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231702997}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231703684}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231703813}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231703919}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231704051}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231716061}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231716169}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231716263}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231716349}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231716489}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231716578}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231744766}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231744845}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231744914}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231744998}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231745067}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231745138}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231752240}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231752328}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231752402}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231752495}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231752569}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231752642}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231765046}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231765131}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231765204}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231765305}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231765377}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231765447}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231787178}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231787241}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231787303}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231787360}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" needle"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231787413}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231787468}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" [\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231796481}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231813567}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Noun"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231813637}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231825162}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231840649}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231870638}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231870707}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231870764}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231871910}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231871955}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"data"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231890888}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-unit"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231890961}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231903373}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231903445}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231919471}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231919559}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231919625}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231919669}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"plural"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231919743}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Word"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231938125}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231956180}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231974885}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231974961}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231975036}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231990650}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rel"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231990719}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231990776}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"icon"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978231990834}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232005851}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232005902}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232005942}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232005986}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" mobile"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232015810}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232015885}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232015942}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232032778}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232032849}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"690"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232032911}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232032981}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232033044}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bottom"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232033101}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" rim"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232049820}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232063116}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232083363}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rim"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232083433}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-card"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232105382}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232128219}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\"]"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232150952}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232151008}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232151068}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232151145}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"need"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232151206}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"le"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182121}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182196}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182248}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182451}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182523}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"need"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182596}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"le"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182658}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182715}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232182783}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232227570}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232227632}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232227677}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232227725}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232227822}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232227887}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232227967}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232228027}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232240569}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232240644}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232254336}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232254410}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232254469}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232254524}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Confirm"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232270806}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232270872}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" build"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232338348}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sync"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232338413}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232338472}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" latest"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232338538}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" changes"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232338599}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232338648}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1746,"ts_us":1792978232338697}}

data: {"id":"d920036383a63a7033551f122b8e6de4","object":"chat.completion.chunk","created":1792978226,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":592475,"completion_tokens":876,"total_tokens":593351,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":574464,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":605,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1746,"ts_us":1792978232362283}}

data: [DONE]

