data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973746879655}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"File"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973746930564}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973746930709}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dash tri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973746930867}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pped ls. Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747038492}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747038927}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" --."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747038980}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xg3irdbl4gvzv0cggli1pbsb","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747039135}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747046899}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747046984}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747047058}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747047679}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747048852}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747048920}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747049538}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747049608}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095126}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095187}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ont"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095247}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095325}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095385}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095450}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095491}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747095666}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747097934}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747097995}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747098398}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747098615}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747116559}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747116656}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747116726}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747116823}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747134767}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747134825}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747134878}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747134925}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747183764}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747183843}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747183895}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747183950}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747192985}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747193033}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747193100}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"List"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747193159}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" downloaded"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747221473}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747221524}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" files"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747221573}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747221672}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2260,"ts_us":1792973747271815}}

data: {"id":"e185353d78c3717d6b1a8ab08a9e4e2d","object":"chat.completion.chunk","created":1792973746,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":48855,"completion_tokens":88,"total_tokens":48943,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":48256,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":11,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2260,"ts_us":1792973747271894}}

data: [DONE]

