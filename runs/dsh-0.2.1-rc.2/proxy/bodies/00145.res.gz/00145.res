data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978042575866}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978042997024}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043156407}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043156508}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043156588}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043156638}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pressed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043160298}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" F"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043160379}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043175885}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043194071}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043194151}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043194202}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043208907}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043224325}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" early"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043224417}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043240756}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043240850}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" All"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043240930}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043255617}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043255720}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043255787}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043275213}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043275301}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043287877}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043287980}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043303939}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043304020}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Her"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043304100}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"itable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043318109}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" variance"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043337372}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043337459}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043354003}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"utation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043354131}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043354225}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043354312}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043354403}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043366596}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043366681}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043366765}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043366829}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043385715}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reporting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043400975}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043401084}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043419996}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043420061}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043433952}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043434000}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"240"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043434049}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043448372}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043448439}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043448520}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043448573}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043463895}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043483860}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043483964}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043484022}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043484086}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043484135}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549443}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549516}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549566}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549626}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549676}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549718}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549780}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549844}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549902}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043549964}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043550011}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043556725}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043556773}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043556835}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043574193}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Over"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043589047}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"flow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043589136}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043589200}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" computed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043607800}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043620908}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043620986}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043621090}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043621177}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043621250}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043637847}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043659388}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043659464}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043659531}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043659586}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expected"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043671722}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043671768}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043671825}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" horizontal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043686111}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043686206}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043708050}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043708099}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" consider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043708140}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" whether"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043718040}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043718101}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043718148}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043733256}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043733308}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043760661}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043760727}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043760781}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043760823}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043760913}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043768460}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043779697}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043779758}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" clip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043779810}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" handles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043796538}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" track"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043796589}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043817772}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ads"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043827875}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043827935}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043828004}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043844119}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043844165}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043844225}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043844280}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043844320}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043864743}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043864822}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043864888}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exactly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043864928}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043864984}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"900"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043877271}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043877357}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043894742}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043909208}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043909256}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043909329}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043909392}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"nos"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043909439}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043928256}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043928345}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043928424}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043928501}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043941330}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043941425}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043941474}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043954934}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scripting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043954989}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043970580}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043970653}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043970712}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043970746}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043988696}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043988748}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" parse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978043988799}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044002848}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044002903}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044002941}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Finally"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044003005}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044018485}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044018549}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044018605}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044036552}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044036623}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044036699}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"S"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044036768}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044049539}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044049612}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044070439}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044070515}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044082665}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044082737}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044082796}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044082858}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" achieved"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044082895}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" most"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044098115}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044119342}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044119423}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044119488}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044119549}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044131246}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044131339}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044131403}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044145387}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044160788}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044160854}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044160894}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044160974}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044176779}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" disabling"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044176859}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JavaScript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044192212}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044208912}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044208988}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044209041}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044225028}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044225098}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" will"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044242546}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044242601}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044242673}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" centered"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044256666}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" message"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044256740}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044275345}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044275421}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044287778}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"::"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044287889}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044304322}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" noise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044304396}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044322805}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044337951}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044338048}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044338088}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044352205}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044352255}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044369351}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044369465}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044369539}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044383618}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cript"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044383698}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044383778}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" z"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044383845}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"999"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044383906}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"9"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044401071}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044401129}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044419038}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"::"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044419110}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044419163}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" z"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044419217}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"999"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044432180}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044432243}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044432292}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044432343}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" above"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044447141}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044447192}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044466260}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044478704}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044478755}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sheet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044478818}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" frame"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044478884}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" z"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044496197}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"20"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044512456}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044512541}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044512599}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044527757}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044527847}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" opacity"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044544116}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044565663}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044565710}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044565796}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044575387}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044575451}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044590772}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044590830}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" message"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044590893}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044607941}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044608011}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044608069}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044608119}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044623184}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044623274}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044642476}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044642568}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044656898}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044656955}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044657045}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" above"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044670439}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044687630}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044687683}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044704152}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044704236}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044704283}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044704351}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" styles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044704422}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" embedded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044721620}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044721690}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044738118}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044738207}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044754998}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044755059}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044755114}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044755167}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044755231}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044776188}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044782778}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044798328}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044798395}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ype"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044817493}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044817566}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044817621}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044817699}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044817771}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044817840}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leftover"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044829159}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" place"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044854200}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"holders"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044863848}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044882609}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044882686}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044882737}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044882786}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044895103}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044895156}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044895235}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044895304}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044895366}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044909212}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044924082}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978044924140}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045010875}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045010949}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011022}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011075}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" internal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011161}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011235}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011297}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011366}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011437}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011495}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011564}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011623}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011767}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045011829}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045024359}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" opens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045024416}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045040988}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045041076}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045041121}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" underneath"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045054417}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045070567}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045070617}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045085831}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045085892}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045102292}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045102340}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045116514}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045116559}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045116619}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045116701}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045116767}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045132234}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045132291}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045132348}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" consider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045132413}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enhancing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045132482}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045148428}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045148470}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045148511}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045164509}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045164583}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045164629}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045179319}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rawn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045195194}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045195271}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inset"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045210980}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045227006}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045227055}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" palette"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045243279}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045258981}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045259055}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045259114}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045283122}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045283187}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045283254}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045283305}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045290752}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" signature"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045307252}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045323866}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045342976}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045359241}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045359322}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045378733}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045404429}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045404522}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045404597}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045404663}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045404731}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045421142}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045421503}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045421581}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045421652}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045440283}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045440402}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045440496}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045440588}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045440678}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045470002}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045470094}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" possible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045470193}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045470278}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045490859}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045490973}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045491062}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045491132}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045510480}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" World"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045517921}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Without"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045540281}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045548542}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045548633}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045563906}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045563986}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045577663}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045595156}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045595253}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045595335}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ization"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045612106}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045612194}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045661371}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" T"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045686498}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"AX"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045686574}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045686628}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045686708}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045686765}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yields"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045686826}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045687227}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045687291}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045687352}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045690410}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045690487}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045707817}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045724287}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045724346}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045724398}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" World"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045743005}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Without"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045743071}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045743125}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045743434}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045743495}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045743545}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045757623}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045757691}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045757744}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045769229}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045769339}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045795480}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045801680}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045801743}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045801796}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045829190}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" survivor"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045834306}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045851071}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045851196}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045867138}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045867192}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045881412}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045899719}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" X"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045899775}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colonies"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045915307}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045915405}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hold"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045928883}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045928965}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045929029}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045929091}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045929150}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045945227}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045945290}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045945351}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045945398}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045945456}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045962642}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045962722}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045976553}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045976622}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045992603}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" titles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978045992663}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046010048}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046010127}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046026148}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046026212}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046026260}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046041331}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046041393}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046041443}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046056629}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046056698}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046073983}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046074049}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046074104}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046074216}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046074287}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046074341}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capital"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046090209}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046090292}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046107236}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" middle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046107305}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046123596}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Since"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046123679}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" string"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046137100}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" begins"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046137180}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046157167}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046157236}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046157298}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046169750}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046169823}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046185664}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046185734}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046185789}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046185844}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046185895}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046185946}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046216715}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"capital"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046216784}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ized"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046216839}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046218049}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046218124}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046218183}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046234260}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046234327}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046234400}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046234464}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046234514}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046234568}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046252127}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046252192}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gram"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046252247}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"matically"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046252302}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" odd"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046267460}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046267527}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"common"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046267581}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046283711}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capitalized"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046283787}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046283847}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" proper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046296700}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" taxa"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046313121}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046328984}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046329067}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046363369}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046363451}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046363516}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046364272}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046364573}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046364685}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046364781}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046378753}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-case"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046378797}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046378834}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046393074}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046393164}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046468796}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046468872}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046468933}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046468984}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046469043}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046469107}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046469154}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046469206}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046474382}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046474455}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046491027}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046491103}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046491160}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046505370}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046505422}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046522180}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046522319}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capitalize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046522397}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046539563}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046539645}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046559140}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046559224}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046570140}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046570227}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046587063}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046587198}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046587269}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nouns"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046600485}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046600540}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046618268}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lowercase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046618324}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046618404}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046618461}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046638882}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046638936}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046638995}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" map"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046649432}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046666592}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046680386}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046680450}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046680527}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"const"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046697075}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046712481}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046712534}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046712584}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".map"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046727905}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"(..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046727958}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046728022}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046743182}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046743248}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046743303}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capitalize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046743377}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046761025}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046778972}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046779049}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046779103}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046792536}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046792594}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046792643}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ${"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046792738}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046808499}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"}\","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046808562}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046823043}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046823102}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046840066}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" correct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046840117}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046840166}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046840226}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046855482}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046871964}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046889931}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046917915}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046917966}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-sur"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046919288}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"viv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046937981}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046938030}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" branch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046938108}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046938186}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046951605}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046951697}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046951767}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046968801}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046968901}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046982404}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978046982506}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" survivors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050313}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".length"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050428}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050506}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050586}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050686}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050758}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Observations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050833}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" III"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050905}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047050981}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047051081}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" string"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047063092}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047079771}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047079854}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `${"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047079922}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047094407}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047094498}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"}`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047094583}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047094648}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" needs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047112269}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capitalization"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047112365}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047125405}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" There"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047143205}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047159587}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047159676}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047159745}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047174483}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047174552}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047174611}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047190752}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047190820}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047190869}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047205636}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047205706}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047205756}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047205805}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047221791}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047221856}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047221910}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047244100}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047244174}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047244234}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047244289}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047255384}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047255466}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047255548}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047268230}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047285134}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" adjust"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047285204}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047285263}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047285327}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" naturally"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047301193}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047301257}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047301327}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047301398}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047316215}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047316299}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047316356}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047316410}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047332781}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047332862}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047349839}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047349918}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047414876}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047414949}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047415001}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" holds"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047415081}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047415142}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"...\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047415208}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047415286}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047415391}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047415434}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047457159}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047457223}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047457261}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047459568}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" survivors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047459620}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047484251}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rike"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047494067}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047494120}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remaining"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047494156}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047509306}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047525088}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" e"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047525155}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".g"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047539178}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047539228}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047539274}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047539314}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047560356}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047571646}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047571718}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047571773}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047571826}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047571880}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047571933}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ri"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047589854}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047589917}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047589977}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047590042}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"35"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047590097}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047606192}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047606271}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047606326}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047606388}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047619953}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047620034}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047635722}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" abstract"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047635789}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047659473}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047659537}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047667408}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047667468}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" survivor"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047685036}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047701158}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047715711}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047731388}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047731453}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047731694}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047731743}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047731799}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047747875}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arest"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047747936}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shift"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047747986}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047763395}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047763478}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capitalized"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047779368}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" common"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047794582}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047811207}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047829552}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047865551}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047865612}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047865650}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047865697}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047865748}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047865790}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" proper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047865842}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047875455}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047891197}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047891282}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047907044}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047907090}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Observations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047907126}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047924441}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047945289}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047945353}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047964791}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" census"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047964866}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" peaked"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047972790}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047987237}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978047987317}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048004605}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048004680}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048004749}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" II"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048004839}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048018705}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048018774}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048034278}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048034345}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rose"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048052587}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048052655}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048065945}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048066023}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048066077}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" III"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048066126}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048066178}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048082756}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ri"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048082838}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048100084}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" left"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048100143}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"...\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048100192}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capital"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048115755}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" proper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048115814}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048131812}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048131878}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048131998}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stats"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048154535}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048154610}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048163972}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048164024}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048164079}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" change"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048164127}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048181886}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048181955}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-case"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048203107}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048212860}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048212924}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048212960}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048227447}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048227500}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048227599}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048242743}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048259406}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048259490}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048273305}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048295593}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" branch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048309374}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048309430}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" survivors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048309489}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".length"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048325080}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"==="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048345068}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048345162}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048345223}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048345276}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048354049}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".length"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048354112}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048354176}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048354214}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048371571}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048371646}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048385422}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048385489}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048385535}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048404942}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048422977}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048423067}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048423126}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048423176}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" holds"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468070}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468114}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468169}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468220}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468392}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468469}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468506}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048468552}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ${"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048483830}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048483888}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"}`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048498858}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048498911}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048518259}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048518321}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048532087}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048532150}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048532187}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048532260}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048556873}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048556932}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048565946}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048565992}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048566080}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048566154}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048579591}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048579650}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048579703}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048579747}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048597468}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subject"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048612960}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048613010}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048626472}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048626537}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048626578}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048626648}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048656565}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verb"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048656617}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048658410}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048658468}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048658503}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048658561}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048675088}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048675147}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048675195}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048691226}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048691277}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048711450}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048711506}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048711552}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" handle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048722063}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048722123}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048738731}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048738844}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".length"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048753567}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"==="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048753634}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048753684}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" &&"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048769860}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048769914}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"["},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048788551}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048788632}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"]=="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048788705}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048788759}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"fl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048788838}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ora"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048806193}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048806284}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ->"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048819200}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048819277}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048819339}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048819411}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048819529}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048819593}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048834283}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048850243}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" others"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048850321}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048866857}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048866940}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048867008}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048882362}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048882479}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048882568}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048882643}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048905819}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048905903}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048914683}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048930823}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048930910}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048947536}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048947620}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048947687}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048964392}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048964475}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048964519}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" despite"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048979926}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048980011}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048995828}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978048995905}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049015951}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049025848}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049025926}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049025998}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049042228}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049042307}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049042361}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049042410}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049058785}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" collective"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049058837}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049073525}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049092854}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049092963}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049156588}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049156645}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049156691}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049156734}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049156821}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049156904}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049156964}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049157015}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049157066}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049157122}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049157179}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049157215}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049157264}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049157417}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049170540}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049170619}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049170698}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049170743}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049185633}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049185706}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049185749}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Implement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049185786}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049201956}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"const"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049238062}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verb"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049238142}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049238194}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049238234}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ext"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049252391}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"inct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049252480}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".length"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049252565}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ==="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049252643}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049252719}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049252771}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" &&"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049266189}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049266251}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"["},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049266299}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049266341}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"]"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049266399}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ==="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049266443}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" '"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049281391}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"fl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049281440}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ora"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049281528}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"')"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049281570}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049281638}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" '"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049281691}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049305932}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049305997}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" :"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049306051}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" '"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049306116}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049306168}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"';"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049306225}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`.\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049314437}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049314514}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049314570}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049334444}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049334526}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049349801}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-ext"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049349856}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"inct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049361334}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049361399}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049361450}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049379997}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ri"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049380056}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049380106}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049396138}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049396227}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049396281}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049411193}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ri"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049411247}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049411317}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049411384}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049411423}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049411519}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049429978}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049430063}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049430119}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049430161}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049430210}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" III"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049445435}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049458701}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049474185}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049474252}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049489528}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" emptied"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049505487}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"...\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049505541}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049505578}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049521807}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049521873}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049521912}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049539616}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049539681}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049566479}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Shri"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049570358}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"kes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049586560}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" left"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049586662}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049586744}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049622715}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" absence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049623622}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049633590}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049633647}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" begins"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049649916}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049649997}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049666634}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049666685}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049682890}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049682952}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049683052}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049683170}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049699386}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049699435}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" survivor"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049699511}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049714245}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049714294}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049730314}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049730392}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049730429}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049746986}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049747041}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049747128}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049762848}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049762894}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049779025}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" survivor"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049779086}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049794432}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049794505}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rike"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864541}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864610}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864660}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864735}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864792}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864857}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remain"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864893}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864938}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049864978}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049865023}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049865063}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049865126}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049865166}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049865265}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049865313}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049865350}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049874643}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049874691}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049874744}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049892476}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049907954}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049908029}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049923487}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arest"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049942021}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" her"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049942095}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"itable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049957441}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shift"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049957522}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049957581}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049957624}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049973062}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049992906}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" singular"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978049992984}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" common"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050006015}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050021447}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050035284}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050035345}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050035406}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050035460}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050053146}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050067603}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050083212}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050102983}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"part"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050103068}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050114424}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050159601}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050159674}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050159726}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050159758}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050159809}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050159864}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050162830}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lowercase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050162879}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050162922}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"verb"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050194999}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050195044}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_dFb6hFx6F9eHhXe9j6tC6940","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050211678}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050227780}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050227860}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050227925}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050227997}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050228060}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050262813}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050262886}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050262935}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050262990}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050263247}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050263325}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050263417}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050263501}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050263582}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050263664}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050263717}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050278735}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050278781}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050278846}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/app"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050278891}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050278951}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050278996}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050297818}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050297869}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050297916}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050298003}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050298045}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050298094}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050310675}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050310761}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050310813}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050310880}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050310950}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050311024}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" lost"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050330193}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050330282}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" extinct"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050330344}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050330394}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050330471}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050342405}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" T"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050342460}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"AX"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050342500}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050342541}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050359398}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050359454}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050359500}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"plural"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050359568}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Lower"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050359626}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050374671}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050374739}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050374796}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050374861}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ');\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050393780}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050393858}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050393930}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" remaining"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050393972}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050394048}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" survivors"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050394115}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050407197}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050407255}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050407298}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050407357}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050407412}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050407472}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050424143}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050424221}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050424290}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050424383}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050424487}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050424561}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"oss"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050441981}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" holds"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050442041}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050442119}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050442192}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fmt"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050442257}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Num"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050442304}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050459030}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050459095}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050472064}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050472146}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050472211}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050472273}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050472355}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" colonies"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050472430}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050488157}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050488215}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" `${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050488282}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"TA"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050488353}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"XA"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556118}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556176}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556248}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556317}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"plural"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556388}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Lower"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556481}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556543}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556600}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556641}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fmt"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556689}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Num"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556739}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556787}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556934}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050556985}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557026}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557083}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557124}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}`"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557188}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557243}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557283}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557328}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ');\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557369}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557413}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050557474}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050567121}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"The"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050567177}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050567233}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"lost"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050567289}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050567331}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" are"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050591914}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" gone"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050592000}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050592052}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050592115}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"remaining"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050592189}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050592255}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"`;\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050603015}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\"\\\"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050603162}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"new"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050603246}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050603293}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050603359}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050603412}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050617321}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" lost"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050617380}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050617450}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" extinct"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050617549}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050617641}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050617707}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050633044}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" T"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050633115}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"AX"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050633175}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050633231}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050633308}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050633364}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050650268}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"plural"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050650342}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Lower"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050650422}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050650499}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050650542}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050650591}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050665023}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ');\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050665153}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050665230}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050665292}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" lost"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050665373}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Verb"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050682272}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050682324}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" extinct"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050682403}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050682476}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050682537}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050682608}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050695557}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050695621}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" extinct"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050695678}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050695776}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050695868}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050695947}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050712704}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050712771}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050712818}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050712875}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050712929}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050713000}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050728260}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"is"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050728318}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050728371}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050728451}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050728508}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"are"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050728569}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050756400}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050756483}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050756542}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" remaining"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050756605}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050756669}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" survivors"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050756722}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050760229}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050760277}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050760340}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050760390}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050760432}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050761236}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050777513}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050777607}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050777668}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050777725}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050777774}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050777848}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"oss"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050792029}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" holds"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050792116}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050792182}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050792251}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fmt"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050792308}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Num"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050792366}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050807824}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050807909}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050807980}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050808044}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050808144}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050808224}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050835556}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" colonies"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050835622}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050835663}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050835716}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" `${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050835760}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"TA"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050835811}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"XA"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050840630}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050840702}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050840751}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050840836}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"plural"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050840941}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Lower"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050841071}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050859850}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050859901}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050860011}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fmt"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050860076}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Num"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050860126}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050860169}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050873071}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050873155}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050873223}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050873294}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050873349}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}`"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050873399}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050897720}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050897848}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050897944}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ');\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050897994}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050898044}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050898127}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050905639}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"The"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050905720}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050905777}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"lost"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050905859}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050905944}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050906021}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"lost"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050922113}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Verb"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050922196}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050922263}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" gone"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050922326}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050922400}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050922473}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"remaining"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050938995}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050939099}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"`;\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050939158}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\"\\\"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050939226}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"assert"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050939290}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" old"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050939353}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050955997}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050956078}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050956138}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050956256}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050956351}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050956418}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(old"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050980254}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050980315}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"new"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050980361}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050980413}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050980474}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050980525}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050984742}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050984825}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050984891}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050984955}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050985018}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978050985081}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126068}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126177}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126265}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126349}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126442}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126538}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126612}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126683}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/build"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126757}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".py"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126831}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126903}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051126976}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051127935}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128031}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128121}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128214}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128305}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128400}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128483}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128570}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128656}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128744}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128829}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051128921}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129270}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129347}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129418}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129490}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129562}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129630}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129703}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129777}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129848}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129917}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051129990}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051130061}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051130819}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051130892}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051130965}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051131070}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051131176}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051131286}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051131360}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051131437}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051135221}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051135338}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051135433}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051135511}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051135585}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051135658}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051145854}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051146380}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051146483}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051146571}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051146651}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051146729}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051162367}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051162485}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051162581}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051162670}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051162786}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051162868}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051177968}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051178066}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051178144}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051178217}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051193455}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051222799}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051222906}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051222997}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051223088}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051223194}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051228066}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Polish"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051228203}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" extinction"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051241796}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sentence"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051261541}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grammar"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051273781}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051273895}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1679,"ts_us":1792978051291522}}

data: {"id":"fc6cd7f651576ea66fc8fa2b703d767b","object":"chat.completion.chunk","created":1792978042,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":532878,"completion_tokens":1505,"total_tokens":534383,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":532352,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1118,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1679,"ts_us":1792978051397678}}

data: [DONE]

