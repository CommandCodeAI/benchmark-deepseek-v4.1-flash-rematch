data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007274001}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007633300}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007731333}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" latest"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007747109}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007747198}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007747274}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007747347}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Wait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007747413}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007762062}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007762149}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007777983}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007778068}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" workspace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007793732}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007793826}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007809816}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" --"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007809899}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007833063}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007833152}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007833229}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_XMuZqtLOsCAG49mkdYAY4124","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007874743}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007874829}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007874892}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007889233}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007889313}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007889372}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007889443}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007912161}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007912237}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007912294}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007912348}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007912409}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\"--"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007912465}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007922027}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007922096}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007922144}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007922245}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007943964}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007944040}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007944093}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007944166}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007944223}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007944273}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007955389}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007955443}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007955494}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007955567}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007955631}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007955675}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007969418}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007969501}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007969549}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007969616}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007969712}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007986373}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007986432}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007986477}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007986531}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007986578}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978007986639}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008001660}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008001737}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008001805}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008001870}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008001923}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008002007}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008018180}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008018224}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008018269}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008018307}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008018350}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008018391}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008034147}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008034196}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008034269}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008034339}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008034397}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008034441}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008052144}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008052210}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008052307}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008052397}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008052455}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008052509}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008067447}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008067520}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008067580}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008067625}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008067677}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008067728}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"D"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008084181}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008084281}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008084364}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008099016}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008099063}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008099148}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008099220}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008099292}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008099356}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008115069}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008115148}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008115447}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008115516}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008115563}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008115627}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008130857}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008130943}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008131008}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008131076}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008131138}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008131172}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008147378}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008147433}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008147510}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008147593}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008147659}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008147715}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008164234}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008164290}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008164372}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008164468}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008164548}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008164584}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008183968}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008184025}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008184071}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008184116}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008184225}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008184312}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008197633}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008197692}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008197741}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008197790}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008197845}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008197955}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008212466}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008212545}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008212605}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008212666}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008212731}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008244370}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008244462}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008244545}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008244605}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008244678}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008264980}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Verify"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008265059}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008265107}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008265163}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" values"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008277341}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008277410}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" latest"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008277492}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" build"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008296978}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008297043}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1751,"ts_us":1792978008308494}}

data: {"id":"6dc606657e25f4893baa086b786bac93","object":"chat.completion.chunk","created":1792978006,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":528830,"completion_tokens":188,"total_tokens":529018,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":528384,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":18,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1751,"ts_us":1792978008331177}}

data: [DONE]

