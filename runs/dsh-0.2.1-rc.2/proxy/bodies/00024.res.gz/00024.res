data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974182887187}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974182954302}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974182954350}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ize engine config and ensure default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974182954439}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183016731}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183016814}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183016872}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183018396}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183100998}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183101055}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shape"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183101104}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard and title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183101247}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183174777}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final engine currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183174882}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soft density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183174922}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183174979}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should choose default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183303515}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed, maybe \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183304597}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"WESTM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183304657}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ERE-07"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183304700}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". Check full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183358694}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trajectories each "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183358796}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 and events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183359061}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183359115}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183458093}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183458193}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183458378}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183458879}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" type names"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183542716}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183542774}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adjust initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183542805}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183543326}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183637177}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183637246}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183637285}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0; default screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183637329}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183718044}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2400. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183718106}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183718154}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183718253}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183799784}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of disk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183799893}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183799966}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 108"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183800127}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183874843}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183874930}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10 sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183875014}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rikes. Nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183875362}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBut moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183954690}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count grows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183954737}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 379"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183954771}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974183954803}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen20 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184064768}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184064830}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5s), shri"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184064871}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kes 23. More"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184064906}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" busy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184174213}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184174293}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 148"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184174366}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184174408}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20. Looks good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184293778}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nBy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184293967}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184294007}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184294523}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184343451}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"72, plants ~?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184343493}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 105"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184343760}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184343803}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; moth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184384094}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 335"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184384294}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; shrike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184384346}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"49. Great.\nThis default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184384567}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184449854}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rich"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184449906}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184449952}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184450535}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184578657}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1006, moth161"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184578827}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", shrike33"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184578959}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". All"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184579021}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184653876}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Largest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184653975}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184654111}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc.\nShrike"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184654206}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap in display"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184686932}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184686969}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is no cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184687003}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184687248}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Okay.\n\nAt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184764151}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184764218}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184764274}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", charts population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184764307}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamic."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184825391}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184825441}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"it drift for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184825484}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moth etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184825753}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184917147}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184917216}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nShould we set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184917262}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184917309}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974184999936}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185000181}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run speed 8 ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185000242}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185002650}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" completes "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185081373}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30s. Nice.\n\nNeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185081456}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185081541}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" API `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185081609}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185164872}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less` and remove"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185164922}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unused class"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185165149}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also make `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185165197}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"snapshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185237779}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185237833}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" structured."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185237916}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Possibly export"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185238027}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185315468}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ranges"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185315517}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185315717}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patch fixes and set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185315756}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" defaults food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185410120}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185410414}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", intervals as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185410464}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185410896}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"72/132"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185468364}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/192. Ensure plantCount"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185468840}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185469014}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0. Also maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185469057}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adjust initial plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185549906}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185549947}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 260"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185550008}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185550449}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2400 enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185623830}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185623985}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185624063}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185624909}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" MAX"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185690778}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185690969}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OTHS="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185691018}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"650, MAX_SH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185691335}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"RIKES=64, initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185772190}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185772230}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2400, food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185772265}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185773057}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 36, soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185859190}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185859258}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- Check initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185859308}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185859551}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185938203}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185938392}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185938437}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" defaults generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974185938775}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240, food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186038714}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"26?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186038904}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186038952}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186039300}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186151763}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_b3aa9fyb2k75sj42qvkhzx5h","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186151829}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186152067}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186152113}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186152486}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186152531}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186152562}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186152615}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186155071}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186155138}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186155230}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186155274}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186157664}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"MAX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186157803}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186157888}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186158105}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186173655}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186173731}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186173798}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186173850}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186175294}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186175369}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186175432}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186175493}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186188538}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186188599}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186188646}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186190065}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186240079}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186240144}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186240202}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186240317}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186272152}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186272242}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186272316}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186272391}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186283772}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186283905}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186283975}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186284061}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186297992}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186298066}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186298141}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186298208}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186465736}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186465796}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186465855}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186477215}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186477291}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186477356}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186477415}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186477481}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186477523}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186477560}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186508164}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186508225}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186508265}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653427}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653505}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653578}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653646}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653710}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653760}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653802}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186653901}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685025}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685089}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" defaults"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685151}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685207}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685264}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_6lnc0irx0bhva57gnss4fnmt","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685321}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685411}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685487}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685555}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685616}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685683}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685743}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685781}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186685954}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686011}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686050}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686114}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686185}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686254}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686353}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686427}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686492}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686536}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686870}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186686950}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687013}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687079}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687144}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687182}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687230}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687537}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687605}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687662}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687717}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186687752}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688243}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688320}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688376}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688417}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688465}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688614}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688687}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688741}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688864}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"EST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688927}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186688969}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ERE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186689007}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186689579}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"07"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186689658}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186689720}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186689766}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186690183}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186690462}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186690528}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186690786}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186705875}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186706090}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186706156}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186706199}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186770620}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186770704}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186770765}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186770813}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186798451}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186798536}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186798628}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186799335}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"inished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186832494}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186832576}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186832647}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186833410}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186852826}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186852901}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186853032}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186853381}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186869962}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186870016}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186870059}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186870146}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186870193}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186870590}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186870656}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186870698}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186892191}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186892250}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"stats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186892310}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186892610}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186945476}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186945592}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186945889}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186946021}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186985973}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":",null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186986043}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186986109}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186986191}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186986355}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186986439}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186987125}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186987199}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186998958}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186999037}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186999089}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186999281}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186999333}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186999395}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974186999561}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187000008}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187045929}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187045991}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187046117}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187046186}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187059136}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187059188}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187059308}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187059354}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187077855}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187077913}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187077962}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187078358}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187099585}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" details"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187099644}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187099695}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" stats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187099749}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187192247}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3564,"ts_us":1792974187192349}}

data: {"id":"c11bf10cf82fee0dcc878b9099e03060","object":"chat.completion.chunk","created":1792974182,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":107871,"completion_tokens":631,"total_tokens":108502,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":105344,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":382,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3564,"ts_us":1792974187192471}}

data: [DONE]

