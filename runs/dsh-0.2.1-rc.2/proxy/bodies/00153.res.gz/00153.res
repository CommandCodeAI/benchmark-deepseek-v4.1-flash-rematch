data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978185280559}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978185996241}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186161912}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186177786}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186177848}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186193616}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186193701}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186193755}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" section"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186209583}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186225698}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186225767}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186225809}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186241482}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" boxes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186256808}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186275822}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" defined"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186275883}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186288056}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186288106}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186304717}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186304767}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186304817}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186319506}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186319572}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186335757}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186335803}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186353043}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186353143}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186353209}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186353254}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186367438}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186385863}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186385921}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186404660}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rounds"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186404757}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186416390}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186416450}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inst"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186434653}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186434723}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186434809}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186448211}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186448285}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"671"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186448347}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186448394}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186468138}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186468197}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186468241}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186479563}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186479644}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186479705}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" flex"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186497702}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186513554}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186513606}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" determined"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186526036}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186542914}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" other"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186542971}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" elements"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186543019}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186557798}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186557855}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186557904}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186573841}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"14"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186573901}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186573948}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186591134}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186591216}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" value"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186591329}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186604807}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186620837}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186620890}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186620966}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186621043}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186637769}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186637822}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186637861}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186653617}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186653700}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186669476}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186669575}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186669629}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186669662}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186685182}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186701936}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" than"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186716456}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186716508}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"14"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186716562}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186716606}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186716665}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186716708}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186732943}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186772267}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186772314}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"900"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186780013}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186780081}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Nice"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186780134}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186780171}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" improved"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186780214}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186796894}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ibility"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186796957}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186797032}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186797113}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186812842}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186812913}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186812966}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186852267}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186852340}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186852432}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186852477}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186852535}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186871636}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-size"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186871686}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186871728}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"9"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186871767}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186878726}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186878769}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186878809}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rides"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186878844}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186878881}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186891185}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186891258}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186891305}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186891385}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186908887}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186921928}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186938469}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"9"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186954318}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186969976}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186970039}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186970077}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186985891}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186985953}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978186985989}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187017604}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187017646}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187017681}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187017761}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187017837}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187017891}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187033003}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187033056}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187033106}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187033151}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187033208}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187049353}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" section"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187049413}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187049477}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187064865}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187080602}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187080657}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187080716}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187080756}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187096316}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187113151}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187113197}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187113285}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187113357}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187129950}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" improvement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187144999}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187145044}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187145116}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187145174}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187145221}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187162152}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"common"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187177196}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187177247}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187177293}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" letter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187177339}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-sp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187192382}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"acing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187192442}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187192485}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"17"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187192551}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"em"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187207790}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187207857}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" role"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187207901}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187207971}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187226941}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187226998}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187239467}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wide"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187239509}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187254886}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187254936}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187272851}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187272897}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187272981}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187273062}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187286694}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187286750}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"9"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187302323}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187302392}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187320729}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187320808}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187320887}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187320924}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187335884}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187335931}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187336022}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187336127}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187336185}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378306}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378367}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378418}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378483}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" micro"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378542}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378590}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378637}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187378686}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187385155}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187385216}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187385262}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reconciliation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187401653}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187417815}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187417896}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/sp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187437517}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187455113}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187476051}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187476119}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187491442}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187491486}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187507601}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187507674}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187507730}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ste"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187525242}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187540022}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187540070}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187540130}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187540218}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" value"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187555113}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187555161}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187555225}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187571633}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187571705}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187606091}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187606154}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" compact"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187606194}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187619982}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187620063}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187635191}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187635260}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187679050}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"60"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187679111}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"–"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187679159}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"720"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187679227}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187698547}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187698619}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187698676}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187698729}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187720608}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187738591}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187738666}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187738736}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187738814}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187751431}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187751519}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187762414}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187762503}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187762569}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187762646}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" compact"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187780703}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187780804}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187780878}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Mutation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187780946}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187801706}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187801795}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187812999}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187813074}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187834506}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187834584}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187851604}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187851681}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187851745}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187851806}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187873481}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187873559}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" effect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187873785}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187874112}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187874183}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" endpoints"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187874245}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187919781}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187919866}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Food"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187919934}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187920557}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187920646}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187920731}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187920811}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187936215}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187936296}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187936387}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187936468}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187936546}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187952017}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187952146}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187952228}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" endpoints"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187952301}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187968567}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187968651}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187968714}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187984839}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187984906}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978187984957}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188000122}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188000192}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188000244}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188046330}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188046402}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188046455}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188046506}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188048040}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188048100}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Inter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188048152}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"vals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188048201}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188063791}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188079601}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188094717}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188094779}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188094815}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" info"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188110392}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188110448}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188110485}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188134522}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" value"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188134604}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188134663}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188134709}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188145915}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188145990}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188146032}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188167971}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188176425}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" endpoints"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188176470}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188190277}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188190339}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188190391}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188206017}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188206064}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188223541}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188223616}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188223706}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188237712}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188237754}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188237817}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188272710}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" variables"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188272774}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188284813}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188284853}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" integrated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188305764}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188305805}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" surface"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188305859}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188305901}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188305961}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188315609}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188315651}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188315715}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188331613}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188331662}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188331715}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gener"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188331755}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188348383}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188364168}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controller"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188364235}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188379117}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188379168}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188396187}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ste"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188396227}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188396265}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188396297}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188396338}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" native"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188410853}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" number"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188410897}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188410941}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188410993}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188427120}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188427176}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188443157}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188443206}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188443243}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188478081}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188478154}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188478256}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"60"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188490051}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188490116}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"720"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188490171}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188506937}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188542245}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188542320}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188542458}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188542505}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188553491}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" non"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188569100}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-comp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188585107}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"act"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188614945}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188615007}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188615063}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188618052}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188632410}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188648144}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"900"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188648201}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188648253}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188648285}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188648337}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188664694}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188664742}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188690839}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188690895}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188698360}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188711907}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188711968}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188712006}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188727637}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188727698}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188727748}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188727793}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188727839}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188744910}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188744972}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188745010}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188759340}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188759407}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188786349}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188791401}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188791468}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ste"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188791518}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188807423}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188807478}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expected"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188807534}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188822548}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188822613}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188822667}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" number"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188822728}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188858393}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spinner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188858470}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" arrows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188858525}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188870133}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188886281}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188902396}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/min"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188918074}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"us"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188918117}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188918171}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188934471}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188934530}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188934575}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188934640}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188934692}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188949797}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188949874}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188965547}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188965595}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188965639}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978188984046}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189007056}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hover"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189013580}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/f"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189013665}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ocus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189028930}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sign"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189028983}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ifiers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189029049}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189044698}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189077444}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189077494}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189077536}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189079396}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189097462}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189097517}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189097573}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189097637}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189110276}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189110328}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189124203}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" res"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189141520}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"izes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189141588}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189160484}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189171749}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189171794}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189171839}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189189982}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189190047}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189203325}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189221505}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189235005}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189235053}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189235121}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" think"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189235165}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189251193}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189251238}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ready"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189267211}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189267252}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189267304}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189282461}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189282526}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189282567}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189282614}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" comprehensive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189282675}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189300561}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189300638}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189300695}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189315673}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189315722}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189331381}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189331429}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189345462}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189345510}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189361772}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189383733}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189383804}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189383858}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189394055}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189394128}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189394194}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189394243}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189394313}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189409261}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" needed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189424883}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189424925}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189424964}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189424997}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189425030}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189445643}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189457766}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189471932}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189471999}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189472052}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ico"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189472088}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189472127}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189472183}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" served"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189488493}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189504532}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" HTTP"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189504642}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189504719}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189522354}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189522422}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189522470}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mode"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189537412}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666217}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666264}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666331}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" served"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666400}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666451}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666502}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666556}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666601}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666749}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666792}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666849}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666953}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189666990}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189667025}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189667057}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" violating"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189667177}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189667215}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189679948}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189679993}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189680033}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189680077}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189680112}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189680152}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" itself"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189694588}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189694627}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189694661}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189694695}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189711127}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189711177}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189711213}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189711259}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browsers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189728941}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189742470}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189758289}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189758360}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189758420}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189758474}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189774257}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189774302}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189789593}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189789641}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189805925}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189805974}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189806009}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189806047}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189806081}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189821225}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189821267}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189821320}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189821384}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" avoid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189821431}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189821473}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189836942}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"404"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189837001}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189837062}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189837123}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189837163}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189837198}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nice"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189852747}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" touch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189852792}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189852870}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" prevents"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886171}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886211}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886250}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886283}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886319}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886354}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886411}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189886474}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189900139}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189900181}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189900232}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" href"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189900278}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189900358}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189900426}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189916466}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"image"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189916526}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189916584}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"vg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189916624}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189916675}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ml"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189916700}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":",..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189935000}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\">"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189935055}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189935109}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189935159}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189949276}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189949321}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189949375}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189966475}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189966523}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" evalu"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189966573}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ator"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189979431}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189979469}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" log"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978189995829}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190011542}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190011583}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190011644}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190027492}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190027634}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Adding"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190043075}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190043124}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190058774}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190058826}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190058882}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190076099}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190076151}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190090600}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190090673}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190090705}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190090757}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190105629}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190105671}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190121863}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190121904}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190121960}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190137702}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190137742}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190137793}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190153338}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190153411}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190169583}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190169632}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190186562}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190186611}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190211648}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190211704}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ink"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190216628}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190216671}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190216705}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190216746}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190233425}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" allowed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190248049}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190248133}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190248204}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requirement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190248264}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190264489}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190264552}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190264595}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" libraries"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190264700}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190280256}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190280300}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190280352}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190280413}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190298219}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190298262}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190298323}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190312698}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190312748}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190312819}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190312869}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190328027}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190328097}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190328155}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190328246}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190328281}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190344353}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190344409}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" polished"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190344448}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190360177}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190360218}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190360259}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190360293}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" create"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190360332}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190374747}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tiny"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190374808}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190390454}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190390513}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190390570}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190390610}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190406463}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" green"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190406527}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" circle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190406587}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190422448}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190422495}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190438791}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" petals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190438843}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cream"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190438890}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190463047}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190463091}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190476831}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190476892}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190476963}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190490643}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190502705}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190502755}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190502796}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190502839}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190502884}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190518527}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190534964}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tag"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190549161}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190549204}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190565622}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mistaken"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190565663}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190580890}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190596525}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190596605}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190596662}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190596703}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190633914}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190633972}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190634022}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190634091}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190634188}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190634235}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190634295}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190634319}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190644078}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" makes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190644122}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719033}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719111}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" look"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719171}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" polished"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719236}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719287}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719330}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719363}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719396}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190719436}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" url"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190723146}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190738399}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"encoded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190755011}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190755083}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simple"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190755131}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190771981}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"```\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190788694}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"<link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190788743}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190788785}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190788840}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190788900}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190788948}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" href"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190788989}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190803116}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190803155}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190803192}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"image"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190803228}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190803260}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"vg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190803299}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190818035}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ml"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190818076}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":",%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190818152}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190818219}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190818266}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"svg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190818310}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" xmlns"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190834403}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190834449}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190834503}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190851094}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190851141}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Box"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190851177}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190851214}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190851253}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190851286}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190866836}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190866901}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"64"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190866954}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190867005}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"64"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190867051}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190867115}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190882212}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190882260}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190882301}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190882366}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190882427}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190882490}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"circle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190898006}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cx"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190898054}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190898093}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"32"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190898149}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190914918}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190914978}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190915014}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"32"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190915051}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190915083}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" r"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190915133}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190938159}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"30"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190938217}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190938271}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fill"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190938327}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190938377}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190938428}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"230"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190946438}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"613"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190946481}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190962847}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"f"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190985579}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190985623}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190985671}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190985712}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190985757}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190985799}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190992125}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190992164}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190992201}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190992235}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190992271}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978190992304}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191008002}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stroke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191008044}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191008105}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191008169}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"23"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191008215}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"e"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191008257}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"9"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191027334}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"e"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191027372}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191041686}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191041750}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191041799}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191041842}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fill"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191041877}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"='"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191054749}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"none"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191054804}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191054860}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191054900}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191054938}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191054969}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191070563}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191070603}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191070639}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191070673}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"vg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191070710}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191070750}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191087344}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191087393}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\">\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191087460}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"```\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191087523}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191087572}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191087642}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191102161}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191130153}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191130220}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191130268}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191133939}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191184873}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191184929}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191184977}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191185001}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191198236}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191198278}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191198336}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" provided"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191213469}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191245697}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191245785}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191245851}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191245908}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191281084}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191281148}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191281216}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191281278}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191281333}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" theme"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191293240}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191308631}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191308713}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191308768}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191324823}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191324887}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191324945}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191325012}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191325064}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191340641}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191340715}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191340783}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191340817}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191356575}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191356646}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191356693}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191356761}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_IAl7k6uAHpys09GIWlra5017","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191408501}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191408601}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191408684}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191408755}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191419084}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191419358}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191419448}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191419552}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191435507}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191435610}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191435680}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191435759}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191435849}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191435892}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191450778}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191450850}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191450923}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191450992}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191451045}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191469300}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191469379}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191469443}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191469495}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191469552}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191469713}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191482158}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191482230}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191482293}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191482350}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191482452}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191482528}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191497937}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191498013}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191498091}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"meta"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191498159}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" name"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191498233}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191498290}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"theme"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191515961}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191516036}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191516115}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" content"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191516183}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\"#"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191516264}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191516309}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191529842}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191529955}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191530029}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191530068}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191530126}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\">"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191530176}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191545736}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191545783}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"meta"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191545869}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" name"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191545946}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191546006}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"theme"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191546058}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191562793}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191562853}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" content"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191562931}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\"#"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191563021}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191563088}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191563165}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191578081}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191578169}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191578242}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191578309}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\">"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191578373}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191578436}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191593173}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"<link"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191593253}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" rel"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191593325}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191593396}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"icon"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191593455}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191593520}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" href"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191612455}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191612529}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"data"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191612586}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191612647}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"image"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191612725}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191612781}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"vg"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191626119}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"+x"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191626202}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ml"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191626263}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":",%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191626339}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191626381}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191626437}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"svg"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191641594}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" xmlns"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191641669}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191641737}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191641806}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"http"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191641892}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191641973}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"www"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191660525}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".w"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191660592}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191660665}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".org"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191660721}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191660790}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"200"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191660878}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191672289}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191672381}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"vg"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191672479}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191672555}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" view"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191672629}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Box"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191672691}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191688193}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191688281}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191688362}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191688439}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191688496}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191688547}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191704730}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191704832}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191704897}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191704959}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191705017}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191705077}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191721862}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191721932}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191721984}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191722040}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"circle"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191722103}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cx"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191722177}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761046}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761094}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761170}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761248}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cy"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761304}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761370}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761418}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761478}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761537}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761612}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761673}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191761721}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191768300}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191768369}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" fill"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191768416}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191768476}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191768542}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191768585}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"230"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191785276}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"613"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191785325}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191785414}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191785509}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191806040}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191806214}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191806293}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191806354}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191806389}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191806441}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191814995}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"circle"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191815043}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cx"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191815094}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191815166}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191815206}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191815248}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191835020}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cy"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191835092}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191835147}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191835215}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191835307}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191835395}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191855122}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191855199}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191855242}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191855310}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191855365}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" fill"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191855406}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191863714}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191863778}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"none"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191863822}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191863864}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" stroke"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191863960}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191864062}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191878044}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191878133}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"23"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191878187}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191878242}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191878284}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191894345}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"165"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191894431}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191915392}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" stroke"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191915456}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191915518}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191915579}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191915634}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191915675}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191930976}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191931050}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191931115}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191931160}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191931220}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191942277}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191942350}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191942403}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191942465}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191942520}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191942583}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191961915}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191961975}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191962020}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191962088}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191974404}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"26"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191974486}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191988649}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191988711}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978191988759}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"31"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192004878}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192004924}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192004999}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192005063}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192020628}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192020680}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192020720}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192020785}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192037818}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192037889}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192055166}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192055213}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192071431}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192071505}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192071558}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192071642}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192088208}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192106571}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192106623}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192106668}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192118465}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192118535}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192118576}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192118651}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192118704}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192118773}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192134575}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192134623}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192134670}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"31"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192134721}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192155352}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192155459}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192155535}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192155623}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192155710}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192155799}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192170658}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192170865}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192170946}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192171022}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192171107}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192171181}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192193770}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192193907}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192193980}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192194048}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192194122}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192194190}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192202583}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192202682}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192202759}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192202840}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192202943}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192203037}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192215554}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"32"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192215665}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192215745}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"39"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192234042}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192234142}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192234230}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192234320}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192249104}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192249191}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192264324}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192264413}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192264494}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192264604}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192278221}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192278305}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325128}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325204}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325263}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325319}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325374}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325433}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325491}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192325553}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192326311}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192326387}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192326481}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192326549}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192326609}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192326667}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Z"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192343906}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192343969}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" fill"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192372738}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192372807}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192372865}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"none"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192372921}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192374784}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" stroke"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192374855}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192374911}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192374968}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192375023}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"23"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192375078}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192389141}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192389224}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192419621}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192419700}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192419761}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192419818}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192421224}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" stroke"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192421305}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192421378}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192421438}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192421503}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192421567}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192437011}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192437088}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192437132}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" stroke"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192437226}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-line"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192437301}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cap"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192437350}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192452160}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192452208}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192452288}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192452368}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192452431}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192452479}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192469186}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192469245}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192469294}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192469343}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192469397}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"vg"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192469438}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192487731}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192487799}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192487844}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\">"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192487914}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192487989}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192488044}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192501430}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192501499}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192501556}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192501631}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192501681}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192501736}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192518691}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192518775}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192518844}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192518927}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192518993}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192519062}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192534856}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192534933}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192534992}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/build"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192535046}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".py"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192535126}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192535193}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192644884}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192644971}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645020}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645085}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645156}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645215}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645318}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645359}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645400}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645440}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645487}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645554}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645661}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645730}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645792}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645858}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645912}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192645951}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646051}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646105}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646179}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646306}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646372}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646448}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646502}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646543}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646599}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646809}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646873}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646916}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646957}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192646995}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192647036}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192657094}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192657163}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192657223}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192657271}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192657321}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192673824}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192689981}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192690052}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192690108}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192690195}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192690267}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192690306}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192798632}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192798708}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192798770}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192798834}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192798897}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192798975}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192799389}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192799460}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192799542}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192799595}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192799654}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192799717}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192799946}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800022}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800099}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800170}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800230}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800288}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800516}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800598}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800651}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800724}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800774}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192800834}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801003}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801062}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801125}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801187}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801231}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801311}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801402}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801490}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801566}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801633}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801679}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801860}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192801938}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192802002}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192802070}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192802141}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192802194}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192811792}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192811986}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192812075}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192812143}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192812201}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192812250}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192830249}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192830320}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192830381}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192830449}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192830506}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192830565}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192842120}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192842205}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192842311}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192842397}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192842454}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192842505}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192910557}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192910654}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192910718}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192910784}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192910864}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192910926}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192910967}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911035}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911141}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911210}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911269}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911330}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911524}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911601}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911670}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911737}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911788}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911845}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bytes"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911894}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911950}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192911997}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192912061}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192912108}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192915967}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"external"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192916043}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" link"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192916110}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" tags"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192930557}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192947625}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192947691}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192962981}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192992008}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" x"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192992116}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192992188}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192992253}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".split"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192992346}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192995899}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"link"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192995973}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192996040}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192996166}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978192996210}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"http"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193011250}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193026869}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193026945}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" x"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193027005}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"]["}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193027061}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193027120}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193041904}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"])\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193041980}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193042057}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193057895}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193057981}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" random"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193076626}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193095822}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193095909}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193109345}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193109421}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193109484}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".random"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193109541}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193109611}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193109673}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fetch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193125912}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193125983}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193126042}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193126103}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193126186}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"fetch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193126249}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193141825}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193141904}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193141966}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193142025}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193157471}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193157552}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193182348}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193182414}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193182473}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193182529}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Add"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193190578}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" inline"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193190654}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" fav"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193190725}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"icon"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193190791}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193190849}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193190907}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" audit"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193212185}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193212284}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1667,"ts_us":1792978193220615}}

data: {"id":"0b77088f616c4e4e2bf1add9e933987c","object":"chat.completion.chunk","created":1792978184,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":553975,"completion_tokens":1470,"total_tokens":555445,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":553728,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":891,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1667,"ts_us":1792978193241282}}

data: [DONE]

