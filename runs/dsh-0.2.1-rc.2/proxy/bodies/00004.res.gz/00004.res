data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394262949}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394310123}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright installed,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394310303}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394310470}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser executable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394368951}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" elsewhere. Need test via n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394369152}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px playwright maybe uses browser not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394370141}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" installed? Check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394370202}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ycfxf81kqke5wpw59k4h7yt6","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394394830}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394395025}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394395147}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394395476}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394426552}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394426681}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394426778}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394426834}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394436341}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394436385}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394436510}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394436914}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394451413}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394451685}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394451810}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394451867}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394452529}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394452701}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394452766}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394452808}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394483722}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394483790}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394483830}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394483870}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394495512}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394495809}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394495869}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394495981}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394497183}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394497252}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394497321}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394497397}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394692220}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".exec"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394692316}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394692381}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394692434}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"())"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394692477}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394692568}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394693627}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394693681}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394693728}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394693774}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394693812}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394693855}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394889495}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394889572}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394889634}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394889704}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394889765}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394889831}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394889894}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394890762}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394890840}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394890905}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394890967}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973394891028}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395086910}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087004}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087071}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087130}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087235}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087399}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087517}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087624}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087723}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087783}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087847}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395087899}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088121}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088245}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088339}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088415}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088490}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088582}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088657}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088730}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088811}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088881}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395088954}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089006}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089177}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089218}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089258}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089298}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089339}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089378}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089425}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089500}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089567}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089626}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089697}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395089758}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090080}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090171}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090247}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090314}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090380}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090690}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090761}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090824}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090883}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395090930}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091015}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091067}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091196}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091251}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" availability"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091323}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091403}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091493}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_tttzcdar1n1emlbtol93bhox","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091551}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091607}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091663}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091712}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395091763}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395092146}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395092221}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"fc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395092293}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395092359}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395092426}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" family"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395092464}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395092506}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" sort"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093093}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093156}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"u"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093212}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093268}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093322}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093363}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093394}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093905}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395093978}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395094049}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395094117}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395094231}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395094300}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395094839}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"List"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395094899}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" available"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395094960}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" font"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395095044}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" families"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395095107}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395095153}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1049,"ts_us":1792973395095513}}

data: {"id":"5c3cbb0d5914943e1254b33eecb13887","object":"chat.completion.chunk","created":1792973394,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":9048,"completion_tokens":224,"total_tokens":9272,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":6912,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":23,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1049,"ts_us":1792973395095627}}

data: [DONE]

