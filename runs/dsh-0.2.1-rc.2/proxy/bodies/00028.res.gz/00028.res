data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974242903144}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974242936818}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974242936940}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Did replacement fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974242937375}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let's check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243017172}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_a5rm25l3szcz9xywfgp7taf6","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243017266}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243018082}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243018159}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243018225}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243018330}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243018396}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243018464}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243031338}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243031411}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243031470}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243031529}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243055395}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243056179}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243056260}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243056328}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243056393}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243056460}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243056570}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243056720}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243072421}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243072532}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243072620}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243072756}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129043}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129125}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129207}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129267}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129692}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129772}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129867}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243129927}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243130132}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243130205}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243130262}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243130417}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243160404}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243160498}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243160558}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243160661}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ulation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243171227}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243171295}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243171335}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243171383}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243172028}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243172088}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243172149}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243172234}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243208550}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243208714}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243208831}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243209006}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243209100}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243209175}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243209308}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243209364}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ulation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243240757}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243240875}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243240938}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243241040}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243260780}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243261023}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243261103}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243261182}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243278093}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243278155}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243278216}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243278289}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243314174}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243314249}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243314319}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243315752}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243330411}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243330477}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243330534}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" food"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243330592}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243371406}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243371477}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243371545}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243371673}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2329,"ts_us":1792974243449307}}

data: {"id":"c0e7251dffde10109e7f8c74a9ba99ac","object":"chat.completion.chunk","created":1792974242,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":114445,"completion_tokens":126,"total_tokens":114571,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":113152,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":11,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2329,"ts_us":1792974243449414}}

data: [DONE]

