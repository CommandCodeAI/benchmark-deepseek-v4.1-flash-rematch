data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842372209}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842416607}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842416669}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842416793}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out failed at 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842514251}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s timeout? It says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842514327}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842514641}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30000ms exceeded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842514720}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", despite specifying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842628051}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40000. Wait line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842628144}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10 is `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842628616}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"p.waitForFunction(()=>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842628708}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"window.__GL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842690570}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ASS_GARDEN.readout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842690660}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Open,{timeout:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842690732}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40000})`. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842690799}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842762070}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" out at 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842762165}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s? Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842762238}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Playwright's default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842762308}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842847536}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeout over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842847612}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rides? It says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842847667}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Timeout 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842847754}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00ms; odd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842936574}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842936685}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" why didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842936914}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977842936959}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run finish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843038462}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843038522}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843038577}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843038612}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843138977}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" elapsed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843139035}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843139079}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843139120}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843188478}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843188528}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's analyze"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843189549}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843189596}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843258629}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843258694}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was suspended"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843258961}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843259368}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843341448}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shell calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843341521}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" were using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843341579}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CPU?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843341655}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843419698}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" relevant. Could be because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843419778}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843420539}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843420608}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed? Headless, no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843515006}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Or because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843515059}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the simulation loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843515276}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843516548}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" advancing at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843600365}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expected "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843600427}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 gen/sec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843600680}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843601037}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843676922}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843677495}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Wait our job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843688171}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843688263}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" started with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843766082}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843766143}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"node auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843766200}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-default.js > ... &"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843766834}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` inside a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843853816}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bash tool call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843853899}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843854000}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returned after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843854060}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843944150}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843944197}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843944257}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ran"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977843944334}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" other commands"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844037332}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844037382}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ran. The background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844037449}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844037519}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process might have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844089008}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" been suspended or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844089070}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throttled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844089112}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844089190}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844158757}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844158978}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had elapsed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844159397}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 21s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844159505}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844243603}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844243695}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844243763}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soon"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844243827}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finished with timeout at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844340090}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844340169}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30s. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844340238}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844340295}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"readout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844462697}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Open` not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844462752}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" true by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844462806}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844462850}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844495216}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" itself at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844495273}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844495374}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s requires"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844495453}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s plus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844592395}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844592533}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".22s seal and "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844592754}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.26"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844592833}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844651074}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844651129}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" total ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844651162}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"31.5s. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844651355}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" waitFor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844741662}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Function timeout was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844741726}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844741774}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 40000 but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844741846}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" error"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844800807}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says 30000."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844800898}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844801057}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Playwright caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844801109}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844873021}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844873101}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start took"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844873153}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844873854}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" few seconds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844942770}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844942837}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844942893}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977844942966}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- More likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845038325}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845038432}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845038522}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rAF loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845038610}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845108213}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower than real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845108271}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time in head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845108501}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less when CPU"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845108955}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845238554}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845238611}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focused or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845240303}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845240345}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845301860}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" concurrently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845301911}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845301952}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intensive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845302004}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests, causing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845338649}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845338698}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845339053}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" advance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845339101}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845424230}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than 8/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845424288}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845424458}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845424507}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845489842}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845489912}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might be ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845489988}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845490038}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845636828}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s ideal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845636907}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845636969}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845637021}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845665601}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s, plus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845666076}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seal delay 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845666139}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2 => needs >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845666227}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"31.2s. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845752001}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeout at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845752076}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845752118}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" premature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845752187}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845800596}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The error showing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845800665}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30000ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845800755}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suggests the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845800799}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `{"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845892309}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"timeout:40000}`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845892385}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did not apply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845892441}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wait line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845892498}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10 may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845974467}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be not the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845974898}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845975242}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" readout but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977845975288}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846061866}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846061917}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initialization"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846062336}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846063119}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"{timeout:5000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846144403}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}`? Let's count lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846144477}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846144580}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1 const"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846144665}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ...\n2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846238764}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (async()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846238832}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=>{\n3 const t0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846238890}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...\n4 const b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846239698}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...\n5 const p...\n6 const"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846338709}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errs...\n7 page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846338822}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".on...\n8 await p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846339131}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".goto\n9 await p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846339217}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".waitForFunction(()=>window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846397436}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846397512}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"sim, {timeout:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846397561}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846397729}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"});\n10 const started=await p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846474848}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".evaluate(..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846474936}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":");\n11 await p.waitFor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846475005}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Function(()=>..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846475066}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"readoutOpen, {time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846574784}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out:40000});\n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846574867}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...\nThe error"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846575024}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says line 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846575067}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":20 might correspond"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846642672}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846642777}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Stack"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846642824}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846644132}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846740246}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says Time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846740305}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out 30000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846740342}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms exceeded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846740617}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at line "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846837465}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 maybe the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846837517}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" waitForFunction read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846838528}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out. Could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846838574}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846890179}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" killed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846890249}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846890312}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846890406}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright default page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846987460}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeout is "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846987528}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30s, and our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846987583}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `timeout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977846987639}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847057861}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40000` perhaps ignored"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847057902}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847058007}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" used the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847058043}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wrong signature?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847121472}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `page.waitForFunction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847121546}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847121631}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Function, arg, options)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847121680}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`. We called `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847226319}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847226423}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".waitForFunction(fn,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847226573}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" { timeout: "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847227038}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40000 })` — the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847316493}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second argument"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847316583}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is treated as **arg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847316680}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847316771}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to the function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847397416}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not options! Right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847397486}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! The signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847397850}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847397920}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pageFunction, arg?, options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847487334}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?). To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847487385}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pass options without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847487428}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" arg, use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847487493}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847563424}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"null"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847563865}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847563909}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" {timeout:40000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847563978}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}`. In previous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847671143}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests we used the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847671198}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same pattern with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847672065}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847672118}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847724332}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00 and it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847724668}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" worked? Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847724743}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847724991}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" detect options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847866180}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847866263}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847866339}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847866410}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s check; earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847894753}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847894973}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".waitForFunction(()=>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847895057}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847895490}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".__GL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847961910}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ASS_GARDEN.readout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847961992}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Open,{timeout:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847962369}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"15000})` succeeded within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977847962441}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848043319}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848043409}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Playwright overload"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848043598}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" supports"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848043747}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" options as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848210460}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second if it looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848210534}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like options? Apparently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848212168}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" here"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848212243}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it used"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848311517}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default 30s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848311564}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The docs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848311780}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848311860}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `page.waitFor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848337242}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Function(pageFunction[,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848337521}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" arg,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848337582}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" options])`; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848337630}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" arg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848365437}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848365488}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"{timeout}` it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848365659}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848366066}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" arg, and options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848460740}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" omitted -> default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848460795}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s. So wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848460843}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848460880}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848503044}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848503137}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848503213}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848503257}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/sec needs ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848615056}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"31.2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848615103}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s including wall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848615951}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848616001}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848675059}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" out at exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848675108}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30 after some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848675792}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848675847}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848776407}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848776564}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It started around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848776617}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848776743}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848840180}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848840245}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s wasn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848840298}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t enough because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848840331}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848917449}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848917508}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plus the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848917563}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finish delay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848917706}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848999335}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"22s) >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848999383}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848999590}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The simulation should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977848999666}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reach 240 in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849087445}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849087498}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; finish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849087547}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" triggers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849087587}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849251409}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849251464}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" t≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849251522}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30s; read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849251579}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out opens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849304453}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 31"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849304503}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".22s. So"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849304783}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849304851}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30s timeout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849318233}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is insufficient"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849318309}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good. Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849318351}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a bug in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849318403}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849537569}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", just test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849537630}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeout. Need rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849537669}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"un with longer or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849537711}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849614558}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849614617}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and wait 35"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849614659}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849614708}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849688206}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run test did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849688253}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not prove"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849688289}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849688348}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849827562}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849827659}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 finished. We can rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849827745}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"un with a 40s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849837790}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explicit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849890057}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeout using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849892042}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null arg or just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849892122}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait 34"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849892195}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. Do later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849965019}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849965107}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849965200}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977849965273}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works.\n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850039400}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also the event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850039462}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850039507}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transitions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850039546}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850141966}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- The default run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850142060}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" duration itself"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850142122}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is 30s +1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850142173}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850239952}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850240007}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- If automated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850240108}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850240223}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" waits only 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850342277}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s, dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850342326}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850342387}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" miss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850342447}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850390016}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850390128}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850390171}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850390211}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850505632}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at speed8 is slightly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850505720}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" long. Could set N="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850505800}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"180 at speed8="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850505897}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"22.5s,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850548072}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850548126}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850548166}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7. Or speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850548207}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850625384}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" N=240="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850625442}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24s,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850625577}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard at25."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850625645}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2. Which is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850725742}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better? The requirement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850725795}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850726070}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850726116}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; any"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850807099}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". A shorter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850807168}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default helps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850807213}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reveal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850807517}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850889160}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850889228}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" living"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850889306}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850889355}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850970474}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" observed longer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850970533}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850970654}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s is reasonable."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977850970702}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851038829}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely interact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851039136}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851039207}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task requested"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851039283}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851121464}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851121536}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851121628}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" N generations on its own\";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851122022}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851225539}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851225590}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851225650}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harness waits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851225747}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851273966}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" perhaps maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851274033}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851274082}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine.\n- We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851274143}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can set default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851369260}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed 10;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851369311}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851369422}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851369473}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s +1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851468572}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2, better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851468618}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Speed read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851468657}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out 10.0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851469106}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851538240}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851538286}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851538333}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851538381}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2s. The ecology"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851689408}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851689466}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851689588}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s still visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851690892}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" smooth with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851849336}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interpolation. The user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851849396}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851849851}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851849908}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851875567}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=200,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851875608}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851875848}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"→"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851875897}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"25s; catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851916745}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes 72"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851916793}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/132/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851916829}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"192 (frost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851916876}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851949371}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851949413}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851949563}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s) plus drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977851949613}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852039851}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852039900}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" three events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852040323}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The prompt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852040370}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852098839}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852099013}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" system; enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852099057}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852099291}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240 gives default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852172423}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852172463}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events including all three"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852172812}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" types; better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852172855}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" showcase."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852271676}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Keep "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852271737}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240.\n- Set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852271798}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default speed 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852272030}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852345085}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finish in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852345167}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 25."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852345233}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2s, still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852345302}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852461027}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852461090}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852461171}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s, event times"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852461249}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852512934}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7.2, plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852512978}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 13.2,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852513020}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852513193}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"14.4 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852667831}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"close banners"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852668192}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852668283}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rite), frost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852668352}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 19."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852773206}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852773277}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought21.6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852773333}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Two drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852773384}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852801240}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2s apart at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852801312}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed10; the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852801362}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second banner might overlap/replace. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852801664}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default 8,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852898613}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852898760}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852898825}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s,144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852899142}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852948081}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18s, plague16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852948146}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5, frost24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852948456}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", drought27"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977852948542}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853014456}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10, events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853014679}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closer. Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853014918}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a big deal."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853015174}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853117945}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853118355}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853118423}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853118486}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853197744}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853197821}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853197866}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" completes."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853197911}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Rerun"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853297167}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with a "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853297239}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60s timeout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853297312}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853297456}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853348046}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853348116}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853348357}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853348437}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".waitForFunction with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853425983}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853426035}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853426075}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853426567}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853517192}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853517269}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page timeout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853517309}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853517355}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60s and wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853601056}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853601117}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while continuing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853601288}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853601534}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_kb6o35on868z216zrbkb4zzi","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853637132}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853637199}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853637253}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853637316}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853657562}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853657631}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853657675}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853657744}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853677088}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853677173}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853677243}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853677314}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853699231}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853699321}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853699507}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853699585}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853722828}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853722882}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853722989}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853723337}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853723720}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853723842}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853724077}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853724201}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853738999}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853739050}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853739112}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853739174}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853752315}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853752398}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853752468}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853752593}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853752867}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853753220}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853753266}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853753480}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853774045}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853774104}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853774144}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853774422}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853794947}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853795004}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853795131}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853795181}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853798779}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853798856}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853799172}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853799662}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853818290}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853818354}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853818420}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853819354}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853851577}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853851878}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853851919}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853852116}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853852163}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853852227}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"unch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853852438}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853852492}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853873106}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853873184}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853873244}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853874646}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853898515}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"args"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853898615}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853898695}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853898833}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"--"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853899038}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853899085}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853899325}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853899420}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853921097}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853921449}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853921554}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853921700}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853938162}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853938231}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853938274}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853938324}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853938442}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853938528}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853940640}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"viewport"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853940731}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853977022}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853977087}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853977154}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977853977216}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854008674}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854008742}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854008801}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854008860}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854008971}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854009021}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854009403}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854009898}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854048399}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854048455}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854048521}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854048575}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854056957}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854057008}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854057751}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854057836}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854057893}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854057963}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854058072}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854058224}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854059106}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854059163}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854059301}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854059358}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854111378}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854111511}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854111570}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854111618}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854111795}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854111883}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854111972}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854112031}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854115507}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stack"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854115574}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854115635}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854115847}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854126766}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854126844}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854126921}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854126989}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854127120}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854127207}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854127285}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854127351}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854144362}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854144411}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854144472}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854144537}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854172467}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854172538}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854172578}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854172630}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854173054}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854173114}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854173169}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854173198}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"())"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854188559}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854188619}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854188677}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854188739}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854213073}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854213158}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854213243}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854213319}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854239476}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854239533}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854239616}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854239695}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854239853}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854239930}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854239997}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854240066}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854246342}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854246421}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854246485}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854246536}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854270520}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854270575}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"250"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854270622}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854270692}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854301196}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" samples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854301253}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854301292}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854301339}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854306679}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854306725}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854306785}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854306833}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854317857}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854317907}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854318082}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854318136}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854318278}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854318346}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854318604}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854318688}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854345977}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854346035}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854346082}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854346182}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354404}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"400"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354462}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354538}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354627}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" samples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354704}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354778}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354866}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854354978}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854387065}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854387137}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854387468}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854387549}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854417663}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854417719}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854417773}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854417824}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854546107}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854546157}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854546436}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854546500}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"performance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854576936}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854577041}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854577595}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854577736}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854578000}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854586855}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854586997}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854587083}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854593743}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854593834}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854593909}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854593981}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854597746}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854597988}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854598088}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854598142}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854598369}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854598452}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854598568}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854598802}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854612490}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854612585}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854612673}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854612816}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854625163}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854625277}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854625358}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854625479}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854638637}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854638739}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854638828}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854638915}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854638999}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854639267}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854639366}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854639443}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854709210}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854709265}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854709328}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854709826}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854709875}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854710001}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854710066}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854710107}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" break"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854710900}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854710974}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854711076}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854711125}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854713576}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854713681}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854713753}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854713844}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854717568}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854717620}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854717712}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854717872}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854717998}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854718044}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854718098}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854718463}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854718524}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854718567}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854718651}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854718753}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854726093}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854726144}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854726456}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854726508}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854726706}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854726752}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854726817}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854727185}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854727484}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854727534}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854727570}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854738286}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854740341}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854740402}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854740449}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854740501}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854754790}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854754843}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"200"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854754901}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854754990}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854755546}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854755618}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854755997}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854756483}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854770078}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854770192}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854770269}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854770542}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854792758}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854792838}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854792899}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854793157}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854818511}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854818637}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854818734}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854818810}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854821276}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854821340}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854821455}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854821522}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854840397}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854840443}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854840518}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854840583}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854861068}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854861144}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854861195}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854861262}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854862094}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854862171}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854862242}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854862344}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854875110}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854875192}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" finished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854875266}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854875362}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854907317}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854907410}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854907491}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854907572}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854907932}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854908014}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854908080}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854908195}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854920683}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854920751}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854920798}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854920878}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854940969}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854941039}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854941112}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854941180}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854941250}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854941382}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854941465}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854942052}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854960852}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854960940}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" title"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854961003}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977854962189}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071362}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071429}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071497}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071591}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071684}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Title"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071773}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071851}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855071913}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855124774}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855124893}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855124986}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855125071}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855147871}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855147937}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855148083}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855148187}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855148721}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855148789}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855148853}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855149654}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855157916}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" header"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855158013}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855158161}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855158240}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855163967}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855164037}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"header"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855164102}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855164427}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855164504}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855164587}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855165565}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855165652}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855165820}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855165895}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855165998}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855166118}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855174565}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855174637}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855174700}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855174758}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855174815}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855174883}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855174931}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855175011}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855193234}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855193321}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855193379}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855193455}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855202242}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855202327}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855202394}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855202504}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855209427}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855209479}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855209535}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855209727}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855210657}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855210710}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855210780}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855210846}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855212547}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855212829}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855212893}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855213100}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855219957}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855220066}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855220153}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855220243}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855220295}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855220346}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855220603}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855220680}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855238121}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855238197}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855238278}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855238342}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855245867}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855245944}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855246014}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"population"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855246078}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855246610}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855246682}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855246731}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855246835}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ocument"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855269810}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855269893}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855269967}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"population"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855270044}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855288892}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855288972}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855289033}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855289186}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" focus"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855313345}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855313408}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855313488}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855313560}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Element"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855347237}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855347332}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855347402}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855348000}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855348239}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855348309}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855348355}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855348471}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855390750}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855390808}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"el"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855390885}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apsed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855391067}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855401410}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855401491}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855401560}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855402002}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855402223}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855402275}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855402354}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855402655}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855418467}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855418547}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855418602}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855418732}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462027}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462115}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462179}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462231}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462612}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462666}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462736}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855462847}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855464738}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855464824}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855464930}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855465004}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468382}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468434}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468484}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468544}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468655}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468722}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468768}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855468813}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855470584}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855470635}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855470685}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855470794}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476246}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476294}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476356}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476437}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476489}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476533}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476627}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855476671}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855537681}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855537791}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855537899}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855537983}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538033}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538220}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538302}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538367}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538431}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538474}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538534}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855538575}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855564938}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" started"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855565068}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855565159}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855565213}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855565935}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855566007}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855566451}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855566620}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855591139}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855591185}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"er"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855591273}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"un"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855591855}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855639976}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855640040}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855640115}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855640223}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" proper"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855640319}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855640367}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855640423}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855640474}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855658778}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855658847}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855658903}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_back"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855658962}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ground"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855672852}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855672943}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855673015}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855673157}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11510,"ts_us":1792977855793634}}

data: {"id":"b34da5cf0a4516d7d7c0bcdf59bda551","object":"chat.completion.chunk","created":1792977842,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":507512,"completion_tokens":2091,"total_tokens":509603,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":507136,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1501,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":11510,"ts_us":1792977855793727}}

data: [DONE]

