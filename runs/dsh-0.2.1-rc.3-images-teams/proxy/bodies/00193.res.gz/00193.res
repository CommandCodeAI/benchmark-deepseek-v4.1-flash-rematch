data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941336817}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Excellent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941412752}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" early results"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941412842}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941412884}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" investigate each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941494800}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failure to determine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941494855}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941494889}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug or module"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941494936}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug:\n\n1. M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941560989}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-CTRL-IN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941561050}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V: \"cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941561095}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes\" missing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941561675}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — controls.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941690292}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key detection:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941690360}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941690415}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyOf maps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941690466}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941747844}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941747918}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" row text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941748092}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Found"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941748151}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keys"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941810823}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941810870}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trails but not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941810912}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophes. Perhaps atelier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941810945}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941869979}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather toggle differently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941870025}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (e.g.,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941870059}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"WEATHER\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941870139}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / \"Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941934970}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941935038}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941935102}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" contains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941935164}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941995862}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astroph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941995986}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" and gets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941996101}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mapped to interval because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123941996166}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval regex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942066250}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test order"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942066383}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942066452}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check before catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942066624}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942196957}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942197012}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text for weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942197105}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle contains \"interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942197221}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"? Actually keys"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942255434}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942255476}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942255516}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation,regrowth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942255553}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942360311}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",speed,interval,tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942360356}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ils. So two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942360398}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942360439}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mapped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942429792}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 'interval'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942429847}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942429908}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" list v"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942429997}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"v would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942522993}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show interval-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942523043}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 maybe. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942523137}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me inspect marks list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942523207}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to see."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942584446}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Probably toggle labeled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942584510}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"WEATHER\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942584705}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942584763}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942639163}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Weather ·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942639225}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942639269}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942639303}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" — no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942702227}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942702306}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyOf"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942702475}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": /interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942702536}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"|weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942756588}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"|rhythm|"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942756647}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"event/ → interval."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942756686}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942756763}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle may have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942810955}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria-label \"Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942811043}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes armed\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942811099}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942811226}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row text containing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942872202}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Weather rhythm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942872293}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942872446}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942872495}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text includes \"weather\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942961411}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942961478}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maps to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942961539}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval before catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123942961637}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check. Fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943036150}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyOf order"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943036237}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": check catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943036321}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943036383}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/trails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943093375}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" BEFORE interval;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943093467}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943093597}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943095288}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943154144}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generic \"weather\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943154212}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Update probe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943154310}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyOf:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943154410}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943210079}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943210152}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation, reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943210214}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth, generations, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943210278}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943274975}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"catastroph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943275029}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"|"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943275069}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"armed|sic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943275160}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943377962}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"itas|weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943378024}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943378213}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943378291}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\\/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943436559}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"off)?/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943436635}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; trails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943436693}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943436735}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval; then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943522619}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943522685}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943522806}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then interval last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943522919}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943586709}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /interval|rh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943586789}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ythm|gap/ maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943586876}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Better use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943586918}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943646608}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-label primary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943646693}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943646816}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943646931}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943713113}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"order: trails,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943713160}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943713268}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123943713421}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", mutation, regrowth,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944028476}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations, speed, interval last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944028521}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But \"cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944028595}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe interval\" row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944028667}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contains catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944118977}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"roph → would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944119020}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mis-map"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944119056}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to catastrophes!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944119095}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944291752}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" distinguish: if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944291857}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944291905}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contains \"interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944292872}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944341569}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s interval control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944341636}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" even if \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944341686}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"catastrophe interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944344616}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944412505}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944412550}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n   - trails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944412677}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944412718}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944473880}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"il|ghost/\n  "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944473938}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" - interval if /interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944474021}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"|rhythm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944474110}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/\n   - catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944564024}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if /catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944564079}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"roph|armed|weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944564127}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/\n   - seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944564164}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944630838}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", regrowth, generations,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944630892}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed.\n   Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944630977}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944631049}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944724034}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle could be labeled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944724102}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"WE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944724166}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATHER:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944724217}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ARMED\" without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944787448}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" word"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944787500}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastroph;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944787607}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944787709}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944864047}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944864191}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Catastrophes\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944864263}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944864389}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944925361}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me inspect actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944925415}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marks."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944925474}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also need distinguish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944925522}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944990445}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944990491}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": prefer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944990598}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123944990649}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" type (role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945061318}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=switch/checkbox"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945061385}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") for to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945061477}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggles. Improve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945061632}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyOf with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945152665}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" element tag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945152811}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945152934}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"role:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945153064}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945205094}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=switch/checkbox"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945205141}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945205198}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"button with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945205247}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria-check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945268752}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945268801}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prefer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945268837}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945268920}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/trails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945323566}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945323638}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I can pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945323783}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945323911}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` into"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945380084}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyOf. Let's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945380178}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945380244}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first.\n\n2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945380301}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" M-CT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945432359}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"RL-TAB: catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945432438}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes unreachable due to mapping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945432493}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only.\n\n3."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945432632}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" M-CTRL-ARROW"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945520260}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": Arrow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945520321}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Right didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945520383}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t change for all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945520494}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" continuous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945628547}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945628604}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be my key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945628722}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dispatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945628801}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue: for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945690753}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" custom role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945690810}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=slider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945690866}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" div"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945690898}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s, arrow key handled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945766656}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945766702}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945766743}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945766795}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945850611}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"down listener — CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945850660}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P Input.dispatchKeyEvent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945850735}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rawKeyDown+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945850809}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"keyUp should work. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945907613}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945907664}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945907779}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `press"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123945907824}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` handlers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946002842}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on native"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946002893}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range input:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946002964}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ArrowRight on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946003062}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946085096}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946085176}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requires key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946085232}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"down"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946085301}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with proper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946141602}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946141685}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946141802}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" work. H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946141889}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm why no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946198476}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change? Let me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946198607}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946198695}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946198772}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": maybe read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946258077}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946258154}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change but `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946258232}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"valueVV` compares"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946258319}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946328181}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" including rowText"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946328251}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946328305}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946328377}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ. Maybe focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946391677}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946391737}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946391795}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946391893}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946450229}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"' elements"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946450290}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946450337}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946450400}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual input for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946532387}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sliders?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946532471}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946532529}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g.,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946532581}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row custom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946645380}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946645431}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946645562}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a div"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946645609}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946707401}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=slider and tab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946707476}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"index="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946707532}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0; markControls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946707577}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946779219}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946779324}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Focus via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946779394}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946779476}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Selector('[data-v"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946874303}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"v=m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946874409}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation]') works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946874457}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPoss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946874568}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ibility: my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946932623}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946932675}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".key` sends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946932709}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" raw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946932750}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KeyDown then key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946995471}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Up with `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946995532}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946995597}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123946995691}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 'ArrowRight'`;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947064183}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" native input"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947064227}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range responds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947064263}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947064308}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keydown. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947203760}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls may listen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947203804}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 'keydown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947203840}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"' and call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947203891}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prevent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947281497}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Default..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947281631}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should work.\n\nMaybe the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947281735}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue: after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947281811}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947335614}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Controls`, the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947335665}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first Arrow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947335703}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Right is consumed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947335782}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947388562}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947388612}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947388648}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947388683}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947468512}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses pointer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947468556}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drag only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947468605}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947468647}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyboard? Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947561049}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947561122}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" manually via debug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947561177}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947561231}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947618071}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation, read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947618139}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" value,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947618178}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dispatch, read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947618268}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947702682}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ariaNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947702749}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947702796}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me inspect controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947702858}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947778212}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keydown handling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947778296}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n4. M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947778349}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-CTRL-TOGGLE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947778421}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947833373}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": ariaChecked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947833439}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947833547}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"null — likely toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947833590}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is `<button role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947924506}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=\"switch\" aria-checked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947924568}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947924709}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947924769}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\">`; before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947975483}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947975570}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"after same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947975644}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123947975803}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Space key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948032051}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"down triggers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948032164}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948032381}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyup?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948032466}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" My key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948082833}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948082908}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ') sends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948083060}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" raw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948083139}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KeyDown for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948147554}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" non-text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948147613}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948147722}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use KEY"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948147883}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_DEFS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948242658}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"['"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948242710}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" '] with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948242748}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948242785}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ', and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948329098}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948329153}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"key()`: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948329228}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"if (type === 'char"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948329288}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"' || (d.text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948418782}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" && !type))` →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948418833}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dispatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948418947}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyDown with text '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948418994}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ' then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948583163}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyUp. Should activate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948583227}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" button. Maybe controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948583256}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948583324}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" listens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948640891}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to click;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948640949}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948641063}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Down with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948641106}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text does press"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948709618}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948709664}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" For buttons"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948709764}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", Space activates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948709853}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on keyup; we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948790536}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" send keyUp with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948790594}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key ' '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948790640}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948790751}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need windows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948868364}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VirtualKeyCode 32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948868414}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓. H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948868536}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm. Could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948868582}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948960386}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Checked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948960458}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948960516}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123948960651}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949015997}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"true' and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949016065}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after 'true'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949016116}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because toggle update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949016172}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949155368}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" async? Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949155426}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the switch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949155473}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949155514}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" button with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949215573}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria-check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949215669}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949215866}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a child"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949215928}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949269091}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" valueVV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949269146}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reads aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949269193}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-checked on the marked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949269246}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" element (button"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949327802}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). If markup:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949327854}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `<button class"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949327951}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=\"ro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949328001}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cker\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949385299}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949385342}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949385426}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949385494}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"><span role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949439035}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949439089}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"switch\" aria-checked>`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949439220}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949439266}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Controls picks role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949503884}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=switch element"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949503941}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949504012}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949504071}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm.\n\n5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949557453}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949557515}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-CTRL-FOLD: click"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949557846}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on #folio"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949557899}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-toggle didn't collapse."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949605282}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Buttons id"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949605367}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from shell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949605426}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949605498}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949665841}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949665901}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS/log"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949665944}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ic should toggle `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949666031}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949739734}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-collapsed`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949739823}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on #"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949739886}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"folio. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949739946}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949797357}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949797425}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"click()` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949797456}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blocked because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949797502}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949887428}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pointerdown?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949887521}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949887591}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" persisted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123949887669}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950000013}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"collapsed\" already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950000189}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950000509}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 383"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950000562}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >140"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950044790}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means not collapsed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950044853}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could be at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950044909}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950044962}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950136973}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" attr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950137047}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950137169}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by JS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950137237}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click listener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950219373}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; shell has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950219434}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `#folio"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950219545}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-toggle` button; design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950219643}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950276161}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950276232}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950277768}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"#"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950277826}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"folio.is-fold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950467288}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed`? Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950467355}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect controls.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950467412}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/design.css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950467518}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for fold implementation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950524200}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950524274}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fold implemented"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950524420}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950524521}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (Lead)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950575430}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not controls!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950575495}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950575554}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says designer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950575622}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" owns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950641569}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950641711}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fold behavior"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950641812}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950641868}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be planned"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950692657}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in boot. Shell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950692740}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950692804}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exists; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950692870}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier might implement in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950750685}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls.js as part"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950750752}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of mount? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950750807}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me grep design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950750858}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".css/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950799674}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"controls.js for 'collapse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950799740}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"|"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950799852}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fold|is-coll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950799909}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apsed'.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950862083}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950862247}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950862446}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grep controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950862518}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js for key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950917384}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"down handlers, toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950917480}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" markup"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950917702}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", fold."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950917775}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then debug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950990171}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with a script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950990236}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950990317}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ssugnz5sre8qu3e6g5tqzsky","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950990501}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950990854}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950990931}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991152}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991216}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991451}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991509}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991647}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991712}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991764}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991833}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991915}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950991965}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950992125}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950992238}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950992371}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123950992426}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951010589}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951010659}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951010722}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951010823}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951025898}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951026074}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951026225}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951026391}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951054543}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951054697}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951054773}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951054919}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951054992}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951055074}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951055145}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951055232}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951080615}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951080877}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951080918}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951081051}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951086282}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951086365}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951086532}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951086600}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951095315}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951095406}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951095495}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951095551}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951096119}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951096200}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951096322}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951096369}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951111156}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951111215}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951111315}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951111420}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951126733}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951126807}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951126929}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"down"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951127020}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951163278}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Arrow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951163490}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Right"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951163552}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951163654}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arrow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951197317}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"right"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951197388}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951197453}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Arrow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951197520}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Left"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951218700}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951218895}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951218949}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951218991}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951219090}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951219220}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951219352}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951219470}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951259573}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951259659}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951259726}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951259867}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951270589}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951270801}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951270865}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OLD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951270904}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951271046}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951271115}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951271219}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951271282}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951325502}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951325588}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951325691}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951325765}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"collapse"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951334214}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951334444}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"folio"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951334526}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-toggle"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951334594}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951342617}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951342720}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-exp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951342994}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"anded"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951343095}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951355192}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951355290}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951355356}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951355430}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951363625}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951363749}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951363866}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951363977}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951364233}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951364463}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951364663}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951364845}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951382564}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951382661}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951382816}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951382987}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951399290}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"TO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951399379}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GG"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951399601}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"LE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951399663}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951400309}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951400376}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951400537}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951400684}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951417673}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951417749}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"role"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951417817}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951417982}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"switch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951447536}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951447650}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951447765}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951447895}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951457960}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951458048}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951458110}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951458191}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cker"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951473461}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951473634}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951473845}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951473910}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951488301}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951488384}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951488588}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951488767}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951516419}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951516517}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951516603}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951516684}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951516856}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951516936}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951517168}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951517248}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951544808}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951544875}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951544962}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951545083}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" keyboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951555162}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951555277}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951555352}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951555606}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oggle"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951600900}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" implementation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951600993}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951601057}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3455,"ts_us":1793123951601200}}

data: {"id":"875c6448ba01f7534d1af32f20a9629e","object":"chat.completion.chunk","created":1793123941,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":198493,"completion_tokens":1485,"total_tokens":199978,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":197632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1289,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3455,"ts_us":1793123951647325}}

data: [DONE]

