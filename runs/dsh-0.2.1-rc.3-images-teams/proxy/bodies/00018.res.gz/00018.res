data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712322627}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"I'll start by reading the","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712454141}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" design brief and understanding","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712454225}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" the project","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712454294}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" structure.","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510100}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_w7q6obqbrsp2abdor5myktox","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510154}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510206}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510275}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510320}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510384}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510663}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510732}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510787}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510840}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510875}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712510921}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712517735}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712517785}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712517837}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712517942}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712518001}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712518043}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712518135}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712518233}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712541528}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"List"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712541585}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" working"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712541681}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" directory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712541912}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712565474}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712565526}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712565695}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_ulxqg869f79b7wzgg8n9amyn","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712565757}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712580153}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712580227}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712580282}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712580358}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712595933}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712596023}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712596072}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712596240}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712608904}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712608979}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712609054}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712609104}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712609896}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712609952}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712610119}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712610167}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712640766}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712640829}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712640907}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712640985}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712641167}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712641238}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712641282}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712641446}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712655303}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712655385}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712655446}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712655509}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672389}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672457}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672550}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672618}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672732}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672801}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672873}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712672917}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712688299}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712688358}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712688428}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712688501}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712703625}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712703707}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712703757}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712703824}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712704132}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712704193}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712704297}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712704352}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712724069}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712724322}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712724389}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"IGN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712724446}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712736097}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712736151}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"EF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712736197}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712736242}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712790524}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":865,"ts_us":1793122712790614}}

data: {"id":"205a2165077901d195e9d6fda05d8ca8","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":7908,"completion_tokens":150,"total_tokens":8058,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":6144,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":865,"ts_us":1793122712790733}}

data: [DONE]

