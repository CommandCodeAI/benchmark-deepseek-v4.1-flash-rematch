data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127143937544}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_b6d19ym9dhbq8dxpkryireb2","type":"function","function":{"name":"team_task_update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127143998702}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127143998762}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127143998814}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"action"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144015373}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144015425}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144015534}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144015585}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"complete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144028612}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144028679}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144028735}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144028815}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"expected"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144048398}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144048470}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144048535}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144050018}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144088699}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144088750}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144088861}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144088907}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144137911}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144137974}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144138021}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144138171}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144138219}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144138340}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144138417}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144138609}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144191612}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12052,"ts_us":1793127144191690}}

data: {"id":"d5026872a476492a3a5b6c9ea8c1ba35","object":"chat.completion.chunk","created":1793127143,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":374321,"completion_tokens":76,"total_tokens":374397,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":373632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":12052,"ts_us":1793127144191852}}

data: [DONE]

