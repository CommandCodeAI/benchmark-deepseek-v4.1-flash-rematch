data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169012166}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169096229}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grep returned"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169096300}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exit code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169096434}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1 because the report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169166537}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line maybe different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169166600}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" format. Not important"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169166646}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow wait for Lead."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169166735}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use wait_agent "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169303313}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"180s, check files."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169303387}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8vgcxb1te59zrhipzzpg8ree","type":"function","function":{"name":"wait_agent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169303635}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169303747}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169303829}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169303879}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169303958}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169304044}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169304097}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169304157}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169304216}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"000"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169304270}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26673,"ts_us":1793127169344966}}

data: {"id":"7c9a7c6230ce3703e968246bebc05881","object":"chat.completion.chunk","created":1793127168,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":359652,"completion_tokens":76,"total_tokens":359728,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":358784,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":34,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":26673,"ts_us":1793127169345093}}

data: [DONE]

