data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261524877}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261625916}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot reveals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261625990}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261626085}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"serious visual bug**:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261681126}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The catastrophe banner text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261681172}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is nearly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261681254}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" illeg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261681331}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261791829}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261791945}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" washed out"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261792074}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/trans"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261792226}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"parent: \"Inc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261854483}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"endium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261854569}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" W"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261854684}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ILDFIRE\" barely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261854766}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261903984}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261904093}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261904175}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261904341}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" barely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261953388}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261953569}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261953724}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125261953872}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is a near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262028666}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-transparent white wash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262028783}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262028963}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page edges"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262029117}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have an em"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262106641}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ber wash (wild"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262106713}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fire)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262106754}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that makes the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262106809}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262171074}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" look muddy;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262171162}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262171304}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the banner specifically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262171365}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262252189}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262252271}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s mid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262252401}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-animation (f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262252451}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ade in). The screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262355616}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was taken right when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262355775}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262355976}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" became visible ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262356020}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"poll detects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262409572}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262409659}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262409735}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fade-in),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262409821}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so it's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262490624}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mid-transition."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262490674}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not necessarily a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262490795}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" defect. However banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262490828}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262539150}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262539249}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".4s auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262539359}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dismiss; our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262539438}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" poll sleeps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262592788}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 160ms;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262592893}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262592961}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262593024}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" takes ~200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262643707}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-400ms; we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262643887}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262644059}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture mid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262644131}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-fade. The Leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262696265}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262696310}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262696359}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262696451}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" once opacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262778255}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" settles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262778378}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Improve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262778536}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262778655}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262847796}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262847846}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" detected, wait ~250"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262848009}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms then screenshot; ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262848052}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262917105}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" opacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262917277}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262917350}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262917397}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me plan"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262984575}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262984635}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262984718}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apture event screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125262984768}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots in final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263108679}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run with a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263108876}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263108997}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" delay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263109150}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263165292}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" detection (but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263165384}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263165628}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263165716}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263224072}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" true when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263224135}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" class added"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263224265}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fade maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263224388}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263281041}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms). Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263281095}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the wash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263281202}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263281265}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263337251}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263337353}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263337432}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ERES ·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263337527}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5 SEASONS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263408764}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" REMAIN\" — interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263408818}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": wildfire condition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263408912}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263409037}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263460891}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INERES · 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263460954}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" SEASONS REMAIN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263461053}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263461134}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263517746}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says wildfire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263517806}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" duration 1; boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263517849}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263517987}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" map"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263577733}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"ash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263577807}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" condition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263577943}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263577996}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263694458}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"es for 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263694523}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seasons. Fine.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263694621}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner: latin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263694747}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Inc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263754360}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"endium\" + name"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263754406}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"WILDF"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263754525}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IRE\" + GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263754597}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263803772}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263803863}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263804091}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"I\". The note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263804185}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263854244}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" italic almost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263854385}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" invisible due to fade"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263854597}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nOther observations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263854652}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263927476}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263927558}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ledger at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263927698}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom shows entries: \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263927769}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"GEN 08"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263987470}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263987534}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ilent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263987580}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ia...\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125263987652}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264071003}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"GEN 16 Inc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264071061}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"endium...\" ✓ counter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264071161}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 03.\n- Rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264071252}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264120693}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a wax"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264120815}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seal at gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264120957}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 (gray"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264121060}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" circle?)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264203096}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and cursor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264203175}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 16; seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264203271}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264203331}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264260600}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but looks gray"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264260671}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/greenish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264260822}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264260887}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — wax"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264357145}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seals should be mad"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264357230}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"der red"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264357340}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264357406}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot at rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264412554}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264412600}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 there's a **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264412689}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"greenish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264412807}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gray circle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264473002}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** — maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264473053}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the seal is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264473100}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `S"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264473148}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"icc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264533522}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"itas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264533612}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` och"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264533772}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"re? Hmm at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264533840}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 event was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264633836}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pestilent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264633883}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ia (olive wash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264633928}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") → seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264634003}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tinted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264685936}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" olive? Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264686034}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says wax seals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264686257}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wax"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264686339}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-colored"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264734876}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264734988}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" emb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264735171}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ossed initial. Might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264735276}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264806547}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264806778}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check later crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264806851}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264806995}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wash:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264893498}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264893617}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edges tint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264893721}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed olive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264893876}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gray"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264948882}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264948973}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intentional.\n- Census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264949110}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125264949232}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 915"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265035945}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265036026}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / 092 herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265036082}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265036205}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora / 050"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265090022}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carniv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265090080}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265090210}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trend care"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265090273}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ts.\n- Rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265141899}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" progress"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265142071}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265142104}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after cursor?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265142164}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265243145}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows progress line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265243206}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" behind.\n- **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265243291}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Vit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265243416}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265297890}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265297951}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" position"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265298110}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**: top-left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265298164}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265358015}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265358071}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Field notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265358130}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265358231}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265504922}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" got"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265505049}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cut? \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265505133}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Fire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265505215}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crosses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265576265}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265576311}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Ash feeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265576349}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" whatever follows.\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265576389}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then counter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265625370}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 03; fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265625484}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265625564}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265625715}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280 screenshot to assess"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265694588}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265694687}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265694781}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" layout."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265694867}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_k7abgx2taep3kuhcyrenz1tg","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265694932}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695076}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695137}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695257}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695395}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695507}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695574}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695672}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695759}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265695924}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265698045}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265698163}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265698322}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265698538}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265698600}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265698790}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265698862}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265699071}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265699124}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265699219}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265705447}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265705514}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265705577}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265705671}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265706201}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265706330}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265706440}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265706562}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265728314}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265728420}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265728611}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265728662}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265739353}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265739456}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265739552}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265739747}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265740097}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265740193}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265740306}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265740482}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265755715}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265755901}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265756005}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265756221}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265770420}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265770519}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265770603}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265770832}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265781848}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265781939}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265782212}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265782432}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265782750}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265782842}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265783118}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265783212}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265810045}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265810286}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265810563}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265810639}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265891769}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4990,"ts_us":1793125265891879}}

data: {"id":"3b9ca818c90abdcadc5a88b9b7ea3246","object":"chat.completion.chunk","created":1793125261,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":298859,"completion_tokens":670,"total_tokens":299529,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":298752,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":580,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4990,"ts_us":1793125265892145}}

data: [DONE]

