data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198178959}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198221598}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 20 the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198221735}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner still shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198221879}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Inc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198296374}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"endium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198296548}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198296766}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198296855}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16, hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198369214}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" false and is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198369276}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-visible true, though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198369637}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198369710}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198434867}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198435086}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed 8 = ~2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198435153}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s; banner should hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198436181}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after 3.6s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198498144}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198498327}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we waited 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198498381}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6s from load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198498520}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198578297}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 20 reached"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198578367}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198578452}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198578497}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6s real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198657332}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", gen16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198657469}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198657634}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2s)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198657697}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198761542}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner still within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198761644}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.6s;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198761845}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine. Wash class"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198761920}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is active at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198809230}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198809338}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" though event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198809397}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fired gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198809694}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16 ~2s ago"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198849129}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198849252}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198849357}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198849562}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198930963}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.95s after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198931007}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fire; at speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198931192}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198931348}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16 occurs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198982881}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~2s after load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198982936}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198983108}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125198983157}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.6s → "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199043200}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.6s later,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199043241}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so active. Good. Conditions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199043492}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199043534}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CINERES"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199148432}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (ash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199148485}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199148533}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") 1 season remain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199149509}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199192485}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Inc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199192610}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"endium;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199192661}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n\nB"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199193021}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"anner says GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199240348}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199240444}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16 while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199240494}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current gen 20; that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199240909}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s okay because it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199301926}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199302046}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ers. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199302075}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed 8,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199302892}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199372500}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199372546}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every ~1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199372707}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s, so banner will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199372811}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constantly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199428909}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show latest;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199429010}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay.\n\nS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199429284}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"creenshot lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199429332}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-event-02."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199500948}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_l8lyd74zkkjoxxwa33ov4ufc","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199501034}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199501772}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199501822}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199501870}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199501904}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199501947}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199501987}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199511412}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199511496}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199511539}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199512032}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199557844}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199557892}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199558027}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199558098}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199558230}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199558300}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199558386}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199558449}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199563193}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199563298}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199563376}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199563737}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199563810}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199563897}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199564161}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199564232}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199579234}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199579374}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199579421}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199579586}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199657776}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199657931}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199657974}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199658149}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199658217}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199658917}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659009}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659079}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659143}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659180}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659231}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659276}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659316}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659947}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199659992}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199660086}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199660173}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199660253}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199660328}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199660393}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199660455}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199660995}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199661039}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199661085}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199663821}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199663874}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199664011}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199664045}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36711,"ts_us":1793125199738924}}

data: {"id":"d229628308da7a6b7c905d8d47623417","object":"chat.completion.chunk","created":1793125198,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":295087,"completion_tokens":306,"total_tokens":295393,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":291712,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":218,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":36711,"ts_us":1793125199739051}}

data: [DONE]

