data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990708074}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990801040}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test 1280x800"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990801111}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and modes. Let me batch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990801223}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshots:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990862473}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990862557}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800 normal, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990862608}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440×900 extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990862859}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990944245}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", empty,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990944291}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" onegen, flat,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990944341}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gaps. Use CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123990944388}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P sequentially. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991117401}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991117447}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991118621}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs; each ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991118652}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991182872}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. Let me do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991183016}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them in one bash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991183088}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991183119}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write files"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991231923}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991231968}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rbimb4l2afuetw8h9oci3iht","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232037}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232109}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232202}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232257}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232305}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232353}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232413}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232466}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232558}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232667}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232739}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232806}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991232892}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233021}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" BASE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233104}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233172}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233239}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233301}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233341}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233400}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233458}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233507}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233575}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233640}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233683}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233736}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233880}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233936}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991233979}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991234029}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991234073}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991234117}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991234163}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991234205}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991242060}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991242117}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991242164}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991242218}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991243057}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991243182}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991243253}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991243309}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991263824}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991263958}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991264010}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991264051}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991277869}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991277919}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991277975}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991278024}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991278997}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991279046}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991279100}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991279139}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991293491}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991293549}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991293667}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991293739}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991308027}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991308076}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991308142}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991308206}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991324221}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991324286}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991324361}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991324393}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991342327}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991342389}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991342680}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991342831}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991358010}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991358065}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991358107}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991358150}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991372158}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991372210}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991372269}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991372322}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991389765}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991389825}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BASE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991389867}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991389961}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991404451}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991404527}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991404587}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991404638}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991404889}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991405133}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991405181}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991405243}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991456212}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991456270}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991456340}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991456391}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462278}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462357}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462423}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462512}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462642}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462728}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462799}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462880}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991462993}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991463058}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991463117}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991463168}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991472986}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991473033}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991473081}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991473120}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991482571}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991482648}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991482745}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991482800}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991483372}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991483447}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"130"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991483514}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991483544}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991509347}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991509421}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991509494}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991509562}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514310}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514375}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514429}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514501}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514658}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514705}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514744}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991514787}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991535520}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991535572}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991535627}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991535675}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549047}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549101}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549176}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549228}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549349}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BASE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549420}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549486}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991549527}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991569459}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991569503}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991569602}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991569689}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991588667}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991588737}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991588791}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991588852}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991589164}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991589301}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991589389}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991589465}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991607137}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991607207}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991607255}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inct"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991607309}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991617064}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991617120}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991617167}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991617225}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991635369}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991635425}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991635504}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inct"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991635565}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991636619}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991636684}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991636848}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991637129}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"130"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991648347}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991648391}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991648444}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991648490}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991665827}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991665890}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991665975}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991666066}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991667765}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991667825}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991667885}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991667951}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991683893}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991683947}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991684026}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991684117}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991706856}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991706909}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991706966}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991707022}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991708207}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991708254}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991708318}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BASE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991708403}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991724519}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991724580}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991724722}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991724776}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991741327}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991741400}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991741460}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991741516}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ense"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991741815}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991741907}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991741977}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991742030}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991758885}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991758955}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991759008}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991759070}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ense"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991777679}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991777744}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991777790}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991777831}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991778455}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"130"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991778511}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991778549}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991778603}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991797182}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991797253}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991797313}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991797363}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991815707}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991815753}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991815807}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991815867}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991834245}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991834403}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991834450}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991834510}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991849235}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991849316}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991849412}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991849463}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991896793}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991896885}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991896966}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991897034}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991897105}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991897154}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" extinct"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991897216}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991897275}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dense"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991907570}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" modes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991907662}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991907719}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19890,"ts_us":1793123991907775}}

data: {"id":"f1f5bac32ca0078f0518a23471d3278b","object":"chat.completion.chunk","created":1793123990,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":189897,"completion_tokens":350,"total_tokens":190247,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":187264,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":69,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":19890,"ts_us":1793123991973605}}

data: [DONE]

