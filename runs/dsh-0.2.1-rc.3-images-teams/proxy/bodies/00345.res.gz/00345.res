data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232748691}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232826016}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232826107}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232826173}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-page run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232897399}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232897462}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed from page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232897514}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (1901"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232897651}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") — fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232971659}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow check if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232971739}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead reass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232971798}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"embled with banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125232971854}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233034956}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix and "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233035010}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280 fix. Check file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233035047}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mtimes/hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233035095}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233091378}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_sihbxjkuys5lg4qphgc7e4k1","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233091462}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233091527}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233091622}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233091829}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233091900}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233091956}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092005}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092045}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092093}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092279}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092349}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092404}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092513}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092585}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092649}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092722}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092818}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233092860}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233094328}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233096310}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233096358}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233096434}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233096516}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233096897}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233096958}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233097004}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233097067}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233124281}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233124341}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233124377}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233124450}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233145884}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233145941}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233146108}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233146216}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233146620}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233146697}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233146766}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233146826}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233154504}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233154583}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233154655}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233154798}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233169084}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233169155}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233169216}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233169278}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233186604}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233186651}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233186746}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233186842}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233202527}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233202589}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233202645}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233202688}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233217916}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233217978}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233218036}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233218108}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233218530}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233218880}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233218928}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233218968}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233240370}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233240417}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233240459}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233240501}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259090}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259221}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259294}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259387}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259451}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259491}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259557}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233259615}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233277105}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233277154}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233277199}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233277392}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233295878}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233295922}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233295974}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233296022}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233297393}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233297440}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233297492}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233297547}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pol"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233315713}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233315784}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233315835}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233315901}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233327852}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233327924}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233327994}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233328054}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233375923}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233375992}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233376051}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233376093}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233376596}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233376647}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233376707}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233376756}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233384337}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233384412}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233384478}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233384526}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"embly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233434408}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233434491}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" banner"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233434567}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233434631}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233508284}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233508338}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15150,"ts_us":1793125233508381}}

data: {"id":"ec4b3f3500719e1d581dfaa526c3e4b5","object":"chat.completion.chunk","created":1793125232,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":296863,"completion_tokens":192,"total_tokens":297055,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":294784,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":43,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":15150,"ts_us":1793125233515424}}

data: [DONE]

