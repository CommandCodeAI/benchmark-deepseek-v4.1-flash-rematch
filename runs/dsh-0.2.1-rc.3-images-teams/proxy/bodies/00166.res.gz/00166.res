data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123781917818}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0637hoacjcwdvstbt1wglz5e","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782014093}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782014174}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782014211}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782014630}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782014685}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782014730}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782014775}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782039078}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782039129}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782039168}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782039196}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782061314}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782061363}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782061431}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782061504}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782070679}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782070744}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782070834}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782070874}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782073829}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782073891}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782073940}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782073996}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782074110}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782074168}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782074210}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782074259}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782080320}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782080372}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782080417}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782080457}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088219}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088278}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088326}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088380}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088641}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088698}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088754}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782088794}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782105851}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782105939}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782106015}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782106086}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122045}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122096}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122146}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122212}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122730}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122797}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122859}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782122913}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782134608}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782134674}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782134852}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782134909}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782151275}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782151344}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782151418}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782151471}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11935,"ts_us":1793123782219985}}

data: {"id":"7eedc1c68bac1bc9c061af4d58d67b53","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":176199,"completion_tokens":88,"total_tokens":176287,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":173568,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":11935,"ts_us":1793123782220078}}

data: [DONE]

