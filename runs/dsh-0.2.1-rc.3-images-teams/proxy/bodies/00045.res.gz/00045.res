data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961665815}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961753898}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `cd verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961753953}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` applied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961753992}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to python"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961826493}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heredoc but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961826573}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961826623}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" commands ran inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961826683}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verify dir with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961882373}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paths verify/lib"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961882440}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/... So"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961882486}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122961882522}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t exist. Let me run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099143}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from root."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099234}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_v8y0p7z1i0xgdsnqozcj8n3e","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099324}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099405}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099485}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099565}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099640}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099714}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099803}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099901}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962099983}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962100059}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101104}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101187}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101264}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101339}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101416}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101485}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101588}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101665}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101742}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101818}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101894}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962101967}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103040}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103129}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103202}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103277}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103353}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103434}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103509}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103578}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103667}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103754}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103832}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962103909}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962104949}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105029}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105105}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105179}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105241}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105327}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105409}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105485}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105558}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105634}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105725}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962105778}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962109825}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962109951}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962110027}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962110104}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962123691}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962123798}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962123881}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962123961}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962143585}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962143692}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962143782}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"works"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962143863}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962145071}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962145196}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962145283}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962145396}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962162762}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962162869}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962162964}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962163071}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962179569}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962179669}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962179762}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962179856}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962180341}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962180434}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962180508}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962180589}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962188688}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962188812}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962188910}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962189018}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962211693}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962211768}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962211843}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962211901}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962230289}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" OK"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962230377}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962230443}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962230507}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962249167}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962249257}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962249325}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962249408}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962267804}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Syntax"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962267900}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962267971}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962268041}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" files"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962310615}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962310711}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" workspace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962310770}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" root"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962310824}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962385220}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1412,"ts_us":1793122962385311}}

data: {"id":"2948de9ba1477ea50f9cd36f138f3fd4","object":"chat.completion.chunk","created":1793122961,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":41704,"completion_tokens":171,"total_tokens":41875,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":41088,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":36,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1412,"ts_us":1793122962385456}}

data: [DONE]

