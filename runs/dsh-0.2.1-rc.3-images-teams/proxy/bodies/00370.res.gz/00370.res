data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469320780}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469426017}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check if Lead reass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469426063}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"embled yet. Also update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469426159}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report.mjs to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469490619}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add new screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469490666}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" names and areas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469492441}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469492481}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561174}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561235}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_2hvc1j2lk7x4w998qlomqno5","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561282}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561382}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561446}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561507}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561584}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561717}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561765}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469561815}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562032}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562124}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562188}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562364}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562426}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562482}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562564}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562621}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562675}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562733}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562776}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562823}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562870}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469562916}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469574744}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469574792}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469574851}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469574900}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469688586}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469688639}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469688690}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689033}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689078}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689117}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689157}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689318}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689396}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689437}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689505}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689576}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689641}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689704}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689761}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689834}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469689972}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690023}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690063}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690110}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690151}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690189}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690232}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690278}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690323}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690382}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690430}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469690466}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469705875}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469705923}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469705968}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469706018}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726020}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726075}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726121}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726244}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726294}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726352}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726409}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469726450}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469749589}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469749652}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469749701}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469749747}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469751959}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469752019}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469752066}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469752228}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469752557}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469752605}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469752651}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469752692}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469764097}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469764256}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469764303}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469764356}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469782003}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469782054}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469782099}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469782160}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469808458}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469808514}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469808561}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469809366}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469816606}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469816668}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469816813}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469816903}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469818583}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469818698}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469818795}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469818856}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sort"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469838379}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469838432}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" un"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469838502}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iq"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469838559}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874500}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874550}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874593}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874633}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874673}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874712}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874761}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469874816}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469918541}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469918606}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469918674}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469918743}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469982505}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469982572}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20933,"ts_us":1793125469982641}}

data: {"id":"6c7945edb0098b073777b527d3f963f4","object":"chat.completion.chunk","created":1793125469,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":309218,"completion_tokens":179,"total_tokens":309397,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":304640,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":27,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":20933,"ts_us":1793125469991233}}

data: [DONE]

