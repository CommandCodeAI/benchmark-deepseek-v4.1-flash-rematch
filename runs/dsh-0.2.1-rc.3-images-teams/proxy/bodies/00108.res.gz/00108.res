data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493302592}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493373577}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493373627}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (64KB),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493373667}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493430199}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (66"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493430258}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KB), dashboard.css (19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493430299}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KB) landed. controls.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493430348}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still placeholder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493484632}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493484675}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/render still place"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493484713}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"holders. Engine was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493484747}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updated (41"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493556256}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493556362}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KB"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493556421}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from 41"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493556475}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".0KB) at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493613087}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 22:50 — while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493613136}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493613173}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493613214}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests were running from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493670462}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493670518}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493670557}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at start; that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493670593}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s fine (sn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493749955}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apshot of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493750001}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" source at run start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493750035}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). I should rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493750100}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"un engine suite later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493874166}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493874237}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes settle.\n\nLet me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493874298}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493874335}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine job output."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493930798}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_95vh7ntw5avsz9i9fqz52tqh","type":"function","function":{"name":"job_output"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493930864}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493930919}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493930975}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"job"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931027}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931136}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931234}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931307}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931370}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931415}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931626}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"829"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931673}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"54"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931713}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931751}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"712"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931831}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931916}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493931982}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932030}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932071}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932138}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932211}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932280}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932393}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932466}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932533}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932591}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932639}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123493932680}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123494008725}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123494008813}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2605,"ts_us":1793123494008854}}

data: {"id":"710650413da8364e4f4f2184e4cfd5f0","object":"chat.completion.chunk","created":1793123493,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":128322,"completion_tokens":166,"total_tokens":128488,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":127360,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":98,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2605,"ts_us":1793123494012923}}

data: [DONE]

