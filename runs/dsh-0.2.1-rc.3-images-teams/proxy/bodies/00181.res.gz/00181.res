data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880221971}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880264920}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assemble preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880265212}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and screenshot. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880265254}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design.css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880333629}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880333722}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" placeholder, controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880334012}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" placeholder, dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880334146}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" placeholder. Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880410270}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can check engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880410322}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880410801}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nder/b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880410844}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oot functional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880482857}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and JS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880483160}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errors. Let's assemble"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880483475}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880483689}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome screenshot with a test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880609673}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HTML"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880609875}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880610023}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" search job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880610325}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe finished;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880645103}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check job output later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880645421}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nFirst run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880645587}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assemble"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880645669}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880732442}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880732539}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880732863}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880732919}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880770069}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"&speed=8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880770123}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` and screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880770312}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need ensure Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880770651}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880821112}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unique user-data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880821261}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dir, maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880821482}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" existing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880821574}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" processes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880900793}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880900961}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use timeout. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880901356}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880901474}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console errors via CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880975410}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P. Let's first do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880975532}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a simple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880975728}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123880975797}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dump-dom.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881037161}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881037432}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" placeholder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881037643}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881037881}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `.sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881113179}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881113368}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881113580}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page will look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881113629}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" basic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881180063}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881180106}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loading."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881180254}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881180293}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881240019}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881240072}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881240225}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P script. Let's write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881240345}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a reusable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881310222}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CDP test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881310265}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881310492}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881310529}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" myself"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881379373}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881379425}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier maybe. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881379678}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verifier building"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881379794}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Quick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881442748}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": use Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881442846}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `--headless=new --"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881443011}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"dump-dom` to see if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881443300}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record unh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881508368}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"idden after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881508507}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881508646}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881508697}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881576452}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's assemble and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881576554}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" take screenshot at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881576863}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" virtual-time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881576904}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-budget 500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881642690}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 with ?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881642815}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gens=10&speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881642976}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=8. This page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881643249}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881720687}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" placeholder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881720749}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881720805}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canvas should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881720850}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881799895}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881800068}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `--virtual-time-b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881800229}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"udget=6000`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881800459}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881870442}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881870555}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881870750}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881870945}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" virtual time works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881919755}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881919851}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no external"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881920146}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font requests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881920316}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881996699}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nRun."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881996799}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rvab4orqhqnylnix04cfos1a","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881997051}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881997515}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881998172}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881998271}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881998616}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123881998827}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882019823}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882019896}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882020039}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882020194}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882038851}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882038964}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882039058}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882039336}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882077121}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882077215}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882077308}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882077398}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882080843}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882080968}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882081129}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882081175}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882087940}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882088063}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882088232}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882088303}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882088459}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882088652}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882088721}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882088919}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882106427}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882106494}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882106586}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882106672}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882121479}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882121570}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882121690}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882121768}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882142076}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882142124}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882142277}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882142370}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882153983}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882154041}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882154176}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882154283}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882171064}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882171181}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882171224}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882171275}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882171552}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882171663}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882171862}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assemble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882172033}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882190753}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882190839}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882190970}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882191103}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882206725}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882206777}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882206886}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882206984}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882223159}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882223208}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882223344}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"quiet"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882223396}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882223747}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882223890}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882224013}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882224154}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882243184}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882243233}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882243357}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882243411}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882262169}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882262217}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882262317}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882262409}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882276244}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882276300}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882276369}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882276471}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882276793}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882276914}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882276958}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882277143}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882295969}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882296066}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882296195}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882296274}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882309195}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882309290}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882309373}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882309419}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882310053}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882310093}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882310241}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"disable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882310294}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882330672}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pu"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882330720}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882330773}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882330822}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882347498}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882347668}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882347715}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882347762}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882378572}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-data"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882378750}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882378816}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882378935}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882379052}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882379144}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882379389}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882379480}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882380252}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882380408}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882380462}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882380555}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882409919}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882409969}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bars"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882410054}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882410157}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882419094}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882419129}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882419206}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882419339}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882421321}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882421409}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882421509}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882421598}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"virtual"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882432580}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882432739}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882432882}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"udget"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882432926}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882448754}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882448851}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882449016}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882449073}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882464833}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882464880}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882464933}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882464981}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882482698}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882482793}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882482915}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"01"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882483023}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882483681}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882483747}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882483850}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882483986}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882511780}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882511866}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882511962}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882512016}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882512418}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882512565}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882512667}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882512741}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882528556}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882528661}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882528753}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882528844}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882542539}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882542752}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882542817}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882542899}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882572470}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882572534}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882572655}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882572731}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882573137}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882573194}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882573308}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882573402}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882597712}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882597761}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882597857}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882597957}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882612593}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882612646}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882612690}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882612737}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882614190}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882614265}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882614477}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882614536}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882625711}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882625781}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882625930}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882626017}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882696838}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882696899}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882696995}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882697026}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882697894}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882697938}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882697984}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882698029}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882707142}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882707199}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882707364}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882707442}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882708610}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882708702}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882708764}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882708862}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882719929}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882719976}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882720088}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882720147}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882722676}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882722739}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882722809}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882722877}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882742126}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882742177}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882742390}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882742473}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882766096}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882766305}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882766566}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882766638}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882767061}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882767555}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882767624}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882767676}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882799248}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882799315}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882799372}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882799489}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882819821}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882819864}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882819904}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882819950}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882831664}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882831745}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882831815}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123882831977}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883083088}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"emble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883083144}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" integration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883083262}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883083422}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883105759}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" screenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883105882}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883106166}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4107,"ts_us":1793123883106249}}

data: {"id":"72688866a78dc6a57c83ddbfc10aebcc","object":"chat.completion.chunk","created":1793123880,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":213089,"completion_tokens":535,"total_tokens":213624,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":203136,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":254,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4107,"ts_us":1793123883190790}}

data: [DONE]

