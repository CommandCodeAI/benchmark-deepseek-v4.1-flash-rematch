data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652698956}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_u7j698zjcy59xbdc2l1gep6u","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652748438}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652748494}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652748528}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652761032}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652761090}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652761138}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652761181}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652793430}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652793487}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652793554}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652793670}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652794009}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652794093}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652794195}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652794251}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652810370}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652810436}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652810482}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652810547}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830079}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830174}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830329}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830537}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830619}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830698}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830791}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652830866}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926461}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926537}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926585}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926631}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926678}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926729}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926774}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652926896}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652927007}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652927150}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652927249}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652927407}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652927555}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652927635}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652927732}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652940917}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652941701}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652941878}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652941945}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652942059}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652942128}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652942254}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652942367}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652942479}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652963564}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652963645}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652963765}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652963884}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652963996}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652964121}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652964291}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652964372}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652983057}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652983108}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652983176}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126652983314}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653002755}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653002806}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653002860}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653002938}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653029263}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653029332}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653029399}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653029466}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042025}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042111}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042156}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042229}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042443}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042769}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042842}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653042892}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653063731}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653063815}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653063882}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653063953}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653098542}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653098590}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653098673}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653098811}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653099190}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653099257}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653099368}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653099440}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653116135}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653116203}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653116253}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653116316}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653132619}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653132710}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653132781}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653132819}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653133497}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653133717}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653133804}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653133872}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653149269}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653149350}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653149400}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653149471}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653164217}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653164266}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653164309}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653164390}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653184498}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653184587}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653184649}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653184784}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653210029}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653210098}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653210156}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653210214}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653216333}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653216451}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653216527}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653216576}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653235342}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653235408}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653235450}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6638,"ts_us":1793126653235504}}

data: {"id":"e69902899fa3bdcb8ad9b38346b22ab0","object":"chat.completion.chunk","created":1793126652,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":341245,"completion_tokens":162,"total_tokens":341407,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":339968,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6638,"ts_us":1793126653297479}}

data: [DONE]

