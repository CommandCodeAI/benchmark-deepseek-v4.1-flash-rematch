data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092013463}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_svxvq4nt8cpa9u293e347gkb","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092073756}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092073813}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092075508}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092087650}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092087765}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092087930}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092087982}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092105422}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092105490}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092105550}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092107796}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"70"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092128457}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092128560}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"145"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092128616}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092128708}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092152897}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092152951}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092153099}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092153179}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092153369}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092153426}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092153469}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092153544}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-----"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092176082}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"H"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092176165}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IST"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092176232}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ORY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092176278}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-----"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092206907}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092206993}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092207075}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092207151}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092210566}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092210641}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"830"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092210702}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092210751}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092226246}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092226317}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092226380}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092226428}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092243909}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092243988}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092244038}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092244096}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092245455}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092245514}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-----"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092245585}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"STAT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092245697}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092254672}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-----"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092254753}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092254817}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092254875}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092281219}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092281293}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092281349}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"108"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092281454}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314132}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314523}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"115"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314621}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314699}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314816}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314886}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314948}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092314994}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092351345}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092351433}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092351502}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092351563}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092366886}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092366975}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092367022}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092367063}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092402780}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092402840}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092402881}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092402922}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092452338}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ene"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092452427}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" meta"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092452487}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092453989}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092469390}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" recording"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092469454}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092469495}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" stats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092469550}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" API"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092521345}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092521403}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1541,"ts_us":1793123092521472}}

data: {"id":"08f3b0dbc17754492d288b0a1df666b1","object":"chat.completion.chunk","created":1793123091,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":63171,"completion_tokens":121,"total_tokens":63292,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":61952,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1541,"ts_us":1793123092526501}}

data: [DONE]

