data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618165455}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618244882}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't mutate DEFAULTS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618244919}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So why "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618245974}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1859 vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618315370}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618315421}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?\n\nHyp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618315462}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"othesis: `shots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618315563}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618389665}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-integration.html` was assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618389714}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 23"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618389854}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":05 when engine source"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618389900}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618450616}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1859;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618450737}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618450787}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edited engine.js to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618451609}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901 at some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618507291}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" point AFTER"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618507359}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23:05 but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618507394}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618507605}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"time stays 23:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618573683}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"03? No, m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618573721}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"time would update."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618573798}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618573879}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"time engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618632927}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js 23:03"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618632980}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618633038}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 23"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618633076}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":04:58. My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618731816}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618731934}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23:05:20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618732037}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618732206}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618801565}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23:07 the includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618801611}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618801708}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check said page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618801797}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618853871}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" src →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618853953}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so both"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618854090}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618854131}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618942419}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618942475}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618942608}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23:07. But which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618942647}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618995411}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618995465}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" printed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618995519}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859 in parity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124618995580}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 run."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619050500}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Current src"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619050543}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619050653}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619050690}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619107935}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": the node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619108021}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process loaded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619108172}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" src →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619108333}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" printed DEFAULTS 1901."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619228333}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So page ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619228388}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1859) != src ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619228493}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901) at same moment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619228634}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → includes()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619271991}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619272066}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should have failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619272111}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". My includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619272194}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check ran BEFORE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619328897}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parity2?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619328975}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619329020}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ran at maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619329223}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23:07:00"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619388055}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619388181}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might have edited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619388221}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619388407}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" between checks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619444715}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (23:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619444841}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"07:00"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619444917}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619445027}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23:07:30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619535358}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619535480}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"time now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619535518}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let me check current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619535591}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mtime/content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619585714}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619585858}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also check preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619585902}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inline seed value"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619586494}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619676225}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grepping the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619676266}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619676480}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file for \"seed:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619676554}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619737785}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619737836}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" near D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619737895}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.\n\nActually simpler"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619738384}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": grep shots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619801015}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/verify-integ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619801087}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ration.html for the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619801149}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DEFAULTS block."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619801222}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619871979}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compare with src"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619872080}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me check now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619872182}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619872752}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8kdx32buvg5lmg5qcijr761u","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619894971}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619895089}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619895138}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619895292}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619903293}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619903434}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619903506}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619903613}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619903831}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619903881}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619903985}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619904047}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619910525}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619910572}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619910633}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619910757}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976129}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976263}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976333}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976463}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976510}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976691}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976777}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124619976856}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620035667}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620035757}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620035801}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620037276}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620037430}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620037519}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620037699}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620037853}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620037969}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620038041}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620038101}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620038158}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620038299}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620038409}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620038495}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620038735}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620051843}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620051901}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620051942}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620052079}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620052552}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620052756}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620052831}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620052899}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620074994}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620075076}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620075233}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620075305}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620085751}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620085829}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620085882}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"78"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620085968}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620086455}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620086571}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620086651}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620086696}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620101307}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620101372}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620101458}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620101600}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620118024}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620118148}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620118404}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620118476}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620136974}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620137047}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620137092}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620137183}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"18"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620157192}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620157253}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620157327}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620157493}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620175716}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620175881}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620176021}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620176071}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620193623}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620193691}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620193822}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620193890}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620193980}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620194175}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"19"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620194232}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620194332}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620207047}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620207094}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620207137}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620207187}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620239851}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620239898}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620240064}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620240147}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620245516}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620245574}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620246118}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620246160}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620279876}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620280056}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620280168}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620280364}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620285466}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620285535}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-integ"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620285606}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620285669}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620286034}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620286077}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620286135}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620286245}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620331883}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620331959}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620332103}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620332244}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620338084}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620338206}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620338905}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620338983}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620358037}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620358097}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620358235}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620358325}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360082}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360134}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360464}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360538}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360607}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360678}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360739}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620360802}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620363145}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620363219}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620363283}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620363389}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620379896}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620379971}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620380142}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620380222}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620391738}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620391799}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620391852}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620391964}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620428506}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620428557}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620428597}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620429267}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Compare"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620446559}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620446757}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" source"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620446842}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620446962}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620461010}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620461086}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620461195}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620461259}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620557846}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4673,"ts_us":1793124620557925}}

data: {"id":"e20f32e6dde8fe49268399a5d7a436c6","object":"chat.completion.chunk","created":1793124617,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":255493,"completion_tokens":489,"total_tokens":255982,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":254080,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":296,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4673,"ts_us":1793124620558032}}

data: [DONE]

