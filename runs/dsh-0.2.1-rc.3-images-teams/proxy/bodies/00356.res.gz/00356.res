data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125317946537}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125317946621}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125317946656}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125317964247}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" folded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125317964476}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125317964513}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125317964786}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still be running. Note tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318033772}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" results show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318033984}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318034165}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"08-event.png exists,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318034358}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier-09"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318067874}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not yet. Let me read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318068376}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the images "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318068449}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"06, 07,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318069029}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 08 now and check job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318139752}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" status. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318140033}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318140113}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318140319}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eval might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318197465}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have triggered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318197712}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318198213}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record? `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318198258}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318262412}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318262684}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions.stepGen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318262807}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"()` with default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318263044}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318331901}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318332037}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318332109}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me first read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318332545}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 06 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318592442}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 08."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318592540}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_p06sc4wufvqhqg3d8l8y9od3","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318592629}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318592817}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318592976}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318593060}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318593143}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318593329}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318594313}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318594416}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318594509}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318594778}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318594867}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318594948}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318595030}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318595110}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318596272}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318596356}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318596424}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318596737}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318596824}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318596903}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318597180}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318597260}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598120}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598211}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598287}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598484}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598584}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598665}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598780}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318598850}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614049}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614136}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614200}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614251}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614323}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614377}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614424}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614523}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614572}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614636}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614680}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614722}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614796}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614871}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318614935}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318615039}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318615101}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318616088}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318616139}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318616257}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318616322}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318616397}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318616911}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318616972}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318621301}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318621743}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"06"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318621789}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318621881}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318627582}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318628056}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318628138}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318628622}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8717,"ts_us":1793125318671932}}

data: {"id":"a665af0b89fa739e4545d8ffa697fa9d","object":"chat.completion.chunk","created":1793125317,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":322590,"completion_tokens":177,"total_tokens":322767,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":321920,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":86,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":8717,"ts_us":1793125318672170}}

data: [DONE]

