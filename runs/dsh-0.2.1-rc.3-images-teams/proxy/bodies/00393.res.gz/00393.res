data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694620302}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694693744}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check if Lead reass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694693817}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"embled. Also D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694693871}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"14 specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694746952}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694747004}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" whether"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694747041}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it passed in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694747080}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview2 (g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694828699}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rep)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694828821}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" And P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694828889}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694828950}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" completion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694957003}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694957047}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at full preview2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694957182}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" log for those"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125694957237}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019284}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019334}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_490doyv4p44qceyg2xo3abvn","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019398}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019461}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019557}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019663}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019697}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019856}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019907}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695019949}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020085}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020159}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020253}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020328}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020402}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020475}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020530}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020592}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020628}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695020672}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695030187}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695030240}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695030281}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695030385}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695082982}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695083052}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695083253}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695083309}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695083502}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695083563}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695083795}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695083860}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695084051}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695084122}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695084187}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695084240}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695087097}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695087171}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695087283}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695087338}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695105535}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695105637}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695105776}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695105884}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695106612}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695106740}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695106810}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695106910}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695110582}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695110652}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695110702}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695110780}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695116868}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695116941}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695117004}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695117066}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695117768}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695117838}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"14"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695117883}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695118007}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695134084}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695134149}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695134280}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"H"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695134330}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695146465}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695146518}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695146565}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695146646}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695170675}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695170737}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695170789}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695170831}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695209744}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695209804}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695209855}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695209894}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695246976}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695247039}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695247088}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695247127}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695302714}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695302880}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695302941}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695302994}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"19"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695375895}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695375956}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695376001}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695376040}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695382707}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695382766}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695382833}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695382959}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695384482}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695384532}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695384599}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695384707}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695396128}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695396262}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" deliver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695396330}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695396428}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695399075}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695399190}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695399287}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695399366}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695406550}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695406613}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695406673}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695406770}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695406867}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695407036}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695407123}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695407289}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695433238}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695433298}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695433376}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695433440}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695435658}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695435709}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695435754}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695435794}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695447684}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695447751}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695447795}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695447867}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695447982}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695448056}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695448125}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695448187}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695493499}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695493615}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695493675}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695493803}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695497138}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695497204}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695497258}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" specific"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695497341}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695528988}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695529053}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695529172}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695529327}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695601088}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695601146}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5597,"ts_us":1793125695601226}}

data: {"id":"4bfc25d8e672b3955c9f23ab479dc240","object":"chat.completion.chunk","created":1793125694,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":315971,"completion_tokens":218,"total_tokens":316189,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":313856,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":42,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":5597,"ts_us":1793125695628992}}

data: [DONE]

