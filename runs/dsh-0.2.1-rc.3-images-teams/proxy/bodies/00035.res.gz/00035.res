data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736706073}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736786467}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me claim task-3 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736786511}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set up my todo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736786548}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" list. Then start writing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736861900}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harnesses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736861979}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nFirst claim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736862063}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task-3 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736862129}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"revision 1)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736964618}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8z5as5xsfrdmzzz77mz2f9yc","type":"function","function":{"name":"team_task_update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736964709}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736964910}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965011}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965077}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965155}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965249}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965379}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965513}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965558}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965744}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965808}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965887}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736965993}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736966055}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"expected"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736966101}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736966148}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736966189}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736966232}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736966279}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736989585}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736989667}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736989792}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"action"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122736989856}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737005475}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737005522}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737005612}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"claim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737005663}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737057062}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737057119}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_fa2owzjkuxi8eoid0z9v5gbb","type":"function","function":{"name":"todo_write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737057282}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737057340}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737072370}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737072436}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"odos"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737072505}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737072552}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737098728}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737098882}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737098948}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737098988}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737127842}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737127929}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737128002}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" up"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737128067}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737147760}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737147925}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" harness"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737147985}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737148022}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737184683}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737184741}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737184784}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737184842}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737196795}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737196845}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" CD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737196954}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737196996}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" driver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737216661}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737216711}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" screenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737216762}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tool"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737216811}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233161}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233270}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233322}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233353}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233814}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233857}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"_pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233947}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"gress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737233993}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737250479}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737250529}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737250605}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737250691}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737290390}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737290511}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" contract"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737290571}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737290634}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737305036}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"determ"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737305085}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737305240}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737305291}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737318476}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737318526}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737318587}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" catast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737318654}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737359995}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737360063}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" params"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737360215}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737360293}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737387116}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737387184}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737387286}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737387374}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".random"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737395869}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737395996}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737396143}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737396263}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737457554}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":")\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737457654}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737457778}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737457870}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737459685}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737459804}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pending"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737459929}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737459990}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737460042}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737460164}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737460262}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737460373}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737461051}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" single"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737461174}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737461326}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737461443}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"off"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737483878}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"line"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737484060}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" checks"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737484141}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737484296}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" assembled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737505943}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737506044}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737506163}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737506248}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737507243}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737507358}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737507460}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737507629}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737541145}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737541205}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737541333}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pending"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737541386}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737582418}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737582510}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737582590}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737582671}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737604355}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737604450}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737604531}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737604591}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737610107}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"JS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737610175}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737610292}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737610445}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"network"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737613848}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737613915}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737614078}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-com"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737614132}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pletion"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737637560}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737637779}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737637845}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737637911}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" via"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737670222}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" CD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737670281}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737670344}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737670419}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737682704}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737682757}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737682797}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737682858}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pending"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737683776}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737683822}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737683872}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737683927}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737701045}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737701102}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737701168}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737701247}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"11"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737734462}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737734512}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737734629}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"board"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737734740}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737752724}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ark"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737752785}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"line"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737752839}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737752986}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737772360}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737772411}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737772466}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737772560}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737789050}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737789150}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737789205}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pending"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737789244}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737803730}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737803875}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737803953}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737804019}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737805846}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737805907}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737805969}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737806077}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" visuals"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737852702}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737852753}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ledger"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737852811}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737852857}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" seals"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737868401}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737868464}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" dashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737868521}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737868554}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" pixel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737900703}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737900770}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737900814}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737900905}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737916216}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737916268}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737916335}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pending"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737916378}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737917221}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737917330}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737917387}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737917507}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737952361}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737952419}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"creens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737952553}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737952640}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737981311}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737981360}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737981508}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737981605}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737988076}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737988137}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737988238}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122737988345}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738070931}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071114}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071256}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071406}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071499}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071585}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071672}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071791}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738071953}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738072037}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738072104}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" visual"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738072241}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" inspection"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738072837}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738072941}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738073081}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738073203}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738089507}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738089557}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pending"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738089657}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738089769}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" {\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738105118}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738105174}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738105344}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738105421}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738106206}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738106258}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738106377}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"RE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738106436}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"PORT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738136342}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738136432}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" PASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738136517}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738136589}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738169170}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" matrix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738169282}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738169426}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738169600}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" Lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738189868}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738189952}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" iterate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738190062}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738190124}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" fixes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738209456}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738209526}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738209581}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738209663}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738232821}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738232899}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pending"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738232948}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738233008}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738304622}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1339,"ts_us":1793122738304700}}

data: {"id":"7a274d98f33a97f97cf1c5fca8ef2df6","object":"chat.completion.chunk","created":1793122736,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":23897,"completion_tokens":366,"total_tokens":24263,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":21760,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":30,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1339,"ts_us":1793122738304860}}

data: [DONE]

