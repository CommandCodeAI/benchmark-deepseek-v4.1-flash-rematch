data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125070933882}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Confirmed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071026433}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real issue: **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071026481}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Enter does"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071027948}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" NOT activate the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071118877}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rocker toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071118924}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** — only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071119886}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071119936}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" produces"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071205883}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a click."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071205937}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why? A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071207352}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" native `<button>`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071207434}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should click"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071296449}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on Enter key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071296517}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"down. But there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071296572}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a global"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071296628}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keydown handler"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071358880}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071359003}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071359058}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071359167}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"init"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071414213}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Global`, line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071414271}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1114"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071414423}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071414465}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot global"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071464957}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shortcuts intercept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071464999}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ing Enter?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071465085}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071465134}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" log"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071534977}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows keydown:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071535036}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Enter,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071535125}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyup:Enter but no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071535156}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071641628}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Native button"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071641712}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Enter→"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071641865}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"click requires trust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071641966}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071753366}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CDP raw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071753422}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KeyDown should produce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071754680}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it... H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071756758}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071826793}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Space it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071826901}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" produced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071826937}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click (on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071826981}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyup). Enter usually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071882892}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" activates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071882937}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on keydown. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071883066}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071883132}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `role"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071933031}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=switch`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071933073}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes behavior"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071933124}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No.\n\nPoss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071933167}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ibly boot's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071981706}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" global key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071981756}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"down handler calls `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071981857}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"e.preventDefault()` on Enter?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125071981907}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072024144}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" global keys"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072024229}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072024270}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" init"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072024310}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Global (line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072079112}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~1114):"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072079155}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072079243}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(document,'keydown', function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072079350}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(e){ ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072136198}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072136242}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" typing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072136280}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" return"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072136382}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072188880}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".key==='?'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072188923}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...` maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072189078}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intercepts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072189121}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Enter?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072243940}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me grep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072244021}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072244075}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072244114}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072304669}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Enter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072304704}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'.\n\nAlso could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072304745}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be the button"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072304784}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072359929}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072360031}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" form? no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072360137}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTest with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072360245}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a plain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072468413}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072468462}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072468501}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072468548}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page to make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072543578}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sure CDP Enter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072543620}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" triggers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072543671}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072543719}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072598246}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"test only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072598308}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072598461}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me test plain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072598560}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" button with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072651959}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Enter via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652004}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CDP."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652043}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1pw54o0e3t46ff227tzdp4ct","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652200}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652256}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652353}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652418}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652489}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652574}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652640}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652804}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072652882}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072716613}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072716666}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072716728}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072716846}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072717271}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072717371}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072717481}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072717533}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727084}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727130}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727182}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727283}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727655}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727748}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727833}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072727876}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072731287}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072731374}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072731503}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072731537}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736007}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736089}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736132}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736291}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736396}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736499}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736562}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072736650}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072741655}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072741703}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072741835}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072741902}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072754976}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072755085}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072755126}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072755167}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072765556}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072765603}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072765658}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072765760}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072789300}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072789362}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072789512}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072789560}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072816099}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072816143}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072816188}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072816295}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072837413}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072837465}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072837617}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072837671}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072838067}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072838122}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072838165}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072838255}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072846084}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072846157}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072846270}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072846334}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072864823}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072864915}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072865099}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072865206}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072865744}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072865968}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072866057}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072866157}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072881383}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072881478}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072881551}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072881620}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072903961}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072904053}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072904133}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072904204}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" launch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072917231}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072917320}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072917407}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072917486}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072917661}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072917838}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072917926}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072918024}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072976736}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072976793}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072976837}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125072976939}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073014986}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073015060}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073015219}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073015300}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073015705}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073015803}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073015907}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073015953}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073018732}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073018840}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073018906}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073018994}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073034570}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073034623}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073034675}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073034755}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073035080}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073035181}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073035349}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073035406}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073038021}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073038180}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073038236}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073038341}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073041106}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073041386}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073041464}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073041550}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073042290}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073042436}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073042537}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073042696}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073042782}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073042845}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073042954}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073043022}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073074458}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073074527}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073074644}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073074731}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073074878}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073074934}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073075012}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073075089}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073077022}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073077093}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073077210}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073077320}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073109623}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" launch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073109703}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073109871}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073110048}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073110221}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073110304}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073110415}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073110479}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073115591}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073115834}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073115932}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"400"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073116051}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073134275}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073134417}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073134488}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073134586}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073144916}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073144981}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073145115}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073145223}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073145359}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073145451}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073145615}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073145665}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avigate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073170749}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073170811}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"data"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073170898}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073170984}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073175360}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073175410}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073175462}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"button"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073175536}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073196271}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073196314}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073196357}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073196401}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"</"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073216285}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"button"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073216364}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"><"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073216456}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073216531}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073226700}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073226746}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"click"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073226880}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073226958}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073258435}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073258604}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073258676}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073258754}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073269742}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073269919}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073269987}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073270053}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073282536}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073282646}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073282712}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073282756}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073335182}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".addEventListener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073335246}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073335348}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073335393}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"down"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073335859}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073335913}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073335964}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073336057}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073358388}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073358440}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073358551}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073358612}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073377820}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073377872}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073377915}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073378006}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"concat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073378493}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073378590}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073378690}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073378742}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"</"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073398032}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073398091}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073398138}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073398185}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073416657}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073416704}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073416828}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"200"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073416878}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073418850}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073418930}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073418985}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073419156}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073432368}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073432965}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073433063}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".getElementById"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073433106}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073478457}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073478506}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073478552}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"focus"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073478649}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073480162}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073480288}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073480335}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073480379}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073484367}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073484416}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073484556}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073484615}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073485186}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073485287}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073485339}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073485378}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073493632}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073493688}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073493733}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073493827}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533186}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533232}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533298}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clicks"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533353}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533408}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533447}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533520}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073533587}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073552538}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073552612}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073552670}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073552792}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073569628}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073569700}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073569770}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073569867}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073583291}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073583371}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073583444}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073583589}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073584288}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073584397}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073584439}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073584528}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073602638}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073602771}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073602817}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073602905}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073618420}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073618472}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073618516}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073618612}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073618903}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073619131}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073619267}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073619370}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073634331}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073634415}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073634478}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073634523}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Space"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073707780}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073707827}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clicks"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073707866}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073707956}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073709980}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073710061}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073710187}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073710254}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073711306}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073711389}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073711507}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073711553}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073711791}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073711919}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073711962}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073712059}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073712498}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073712641}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073712689}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073712724}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073720234}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073720282}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073720334}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073720412}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073738538}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073738595}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073738753}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073738806}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073738919}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073738988}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073739044}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073739094}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073747736}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073747805}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073747869}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073747918}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073766462}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073766510}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073766650}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073766710}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073767521}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073767608}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073767653}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073767768}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073798752}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073798812}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073798948}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073799039}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073815685}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073815737}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073815771}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073815844}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073830435}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073830545}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073830651}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" whether"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073830689}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073880341}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" activates"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073880423}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" native"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073880483}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" button"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073880539}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" via"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073983210}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073983259}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073983345}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073983500}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4123,"ts_us":1793125073998269}}

data: {"id":"9521aafbd2c074559b454fe7f5822f53","object":"chat.completion.chunk","created":1793125070,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":286874,"completion_tokens":637,"total_tokens":287511,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":285440,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":240,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4123,"ts_us":1793125073998410}}

data: [DONE]

