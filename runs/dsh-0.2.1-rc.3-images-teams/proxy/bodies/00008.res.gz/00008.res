data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122362975628}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363015898}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rome headless needs unique user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363015999}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-data-dir maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363016862}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due to sand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363082906}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"box. Try `--user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363083007}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-data-dir=/tmp/ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363083196}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rome-profile-le"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363083410}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ad --no-sandbox"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363178686}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363178866}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_re6hyzsgrmjpobhkl0g6i6db","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363179141}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363179381}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363179427}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363179470}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363180528}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363180583}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363180649}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363180721}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363180776}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363180814}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363189365}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363189591}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363189827}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363189894}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363190394}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363200052}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363200097}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363200139}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363210296}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363210342}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363210453}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363210556}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363225481}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363225535}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363225593}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363225637}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363225799}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"disable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363225872}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363225988}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pu"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363226042}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363241271}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363241347}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363241466}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363241528}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363251892}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363252118}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363252171}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-data"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363252724}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363253035}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363253287}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363253344}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363253498}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363285205}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363285302}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363285482}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363285545}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-prof"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363307370}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363307426}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363307521}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363307988}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363317688}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bars"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363317950}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363317999}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363318213}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363319933}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363320115}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363320164}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363320289}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363356937}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357018}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357099}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357150}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357298}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357346}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357536}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357582}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357617}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357822}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357871}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363357925}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363373239}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363373301}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363373407}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363373522}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363385942}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363386010}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363386127}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363386213}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363386306}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363386567}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363386658}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363386775}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363397180}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363397284}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363397444}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363397495}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363416887}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363417048}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363417200}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363417249}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363436610}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363436714}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363436846}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363436900}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363453630}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363453675}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363453917}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363453997}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363490982}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363491127}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363491193}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363491307}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ret"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363496539}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363496586}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363496671}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363496791}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363516574}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363516619}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" profile"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363516661}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363516705}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363647744}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1230,"ts_us":1793122363647795}}

data: {"id":"ceb6ecd292e1f091480e8a629450eb5a","object":"chat.completion.chunk","created":1793122362,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":20184,"completion_tokens":183,"total_tokens":20367,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":19456,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":36,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1230,"ts_us":1793122363647987}}

data: [DONE]

