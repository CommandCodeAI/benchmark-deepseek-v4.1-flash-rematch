data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720279796}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720279872}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" let me check shared tasks and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720279899}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" claim task-1. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720475045}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me also check teammates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720475120}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me look at the task board."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720475175}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_mnuegbi5oohtaauxjjni4ark","type":"function","function":{"name":"team_task_list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720475261}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720478507}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_23uaqul8ju4632ai35p6g3zp","type":"function","function":{"name":"list_agents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720478587}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2236,"ts_us":1793122720478650}}

data: {"id":"16325d49283b6d5400e473a8d06af369","object":"chat.completion.chunk","created":1793122719,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":22355,"completion_tokens":62,"total_tokens":22417,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":14720,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":26,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2236,"ts_us":1793122720478815}}

data: [DONE]

