data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178380963}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178460377}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0×800 real page:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178460420}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no scroll ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178460468}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"scrollH=800)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178521382}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Layout fits."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178521432}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Header meta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178521471}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now compact with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178521508}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks ✓. Summary fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178672685}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Trait labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178672734}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178672769}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bit more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178673232}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" legible.\n\nIssues I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178727900}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" notice at 1280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178727959}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1. The header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178728001}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meta is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178728687}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compact ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178835864}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n2. Census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178835942}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels: event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178836004}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels \"PEST"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178836065}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ILENTIA G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178888169}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"08\" etc. now start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178888245}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178888306}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178888385}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"166"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178942337}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178942391}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178942442}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They start at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125178942483}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179010516}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of plot ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179010581}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179010640}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"154?)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179010681}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179081067}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extend down;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179081135}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" legend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179081196}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179081253}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179141092}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"147"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179141140}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Looks okay. But note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179141198}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label \"P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179141245}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ESTILENTIA · G08\" top is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179200841}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at ~170 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179200887}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179200922}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~153. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179200958}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n3. **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179253695}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The right end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179253746}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels** at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179253782}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 534"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179253835}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179296963}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/41 now right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179297042}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-aligned; nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179297079}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179297115}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlap the \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179345660}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 WE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179345734}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATHERS\"??"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179345785}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No.\n4. Traits:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179345812}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179400115}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels now more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179400192}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" legible (e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179400249}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179400299}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179459288}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".75, 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179459360}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"35). Expression notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179459423}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still light"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179459487}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179561494}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n5. **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179561565}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179561624}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179561662}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179623519}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0: the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179623582}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179623640}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179623716}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"08/G16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179693268}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/G24/G32 start near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179693339}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top edge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179693390}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; the label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179693482}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179752397}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vertical reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179752469}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom-to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179752503}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-top; fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179752550}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".**\n6. The canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179854578}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179854638}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a bit short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179854706}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179854787}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 (c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179903083}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ensus ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179903130}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"186 plot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179903165}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") but fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179903199}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n7. Summary: \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179955624}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"L"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179955688}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARGEST SING"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179955732}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"LE-GENERATION FALL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125179955778}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" shows three"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180046311}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glyphs with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180046363}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180046403}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; readable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180046454}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n8. The record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180104119}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" footer:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180104185}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180104243}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180104283}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARIUM · O"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180153821}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"BSERVATION NO. "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180153882}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0047\" and text;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180153931}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n9. Bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180153977}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" notes strip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180303361}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": weather roster"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180303414}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180303453}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180303497}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px mono"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180351695}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; readable.\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180351742}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180351777}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180351829}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180401133}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180401180}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page. Also verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180401216}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180401264}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180452536}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errors on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180452587}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real page. Also test replay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180452620}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180452662}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180522470}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180522536}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180522604}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resize.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180522645}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180585322}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180585375}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180585418}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180585459}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180650755}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180650822}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180650879}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180650937}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense URL ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180700102}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gens=120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180700167}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"&interval=3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180700234}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180700288}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto-end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180794239}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180794300}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": speed 8 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180794356}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180794399}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180861601}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*30 ticks = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180861654}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3600 ticks / 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180861697}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180861756}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ps = 15s;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180943709}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too long;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180943774}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use conclude via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180943824}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eval after 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125180943882}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0ms ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181017105}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"conclude runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181017206}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181017274}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"120 gens quickly)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181017326}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then wait "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181097409}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3.4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181097457}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181097493}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verify default page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181097527}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (seed default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181156392}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181156440}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead says default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181156488}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1901; URL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181156537}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" params seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181237720}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181237774}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n\nH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181237830}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"over test with real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181237898}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page: after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181314849}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181314908}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" open"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181314961}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", dispatch pointermove"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181315018}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over census center"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181402015}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181402069}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181402131}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n```\n(()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181402211}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=>{const c=document"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181452473}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".getElementById('chart-pop');const"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181452522}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" r=c.getBoundingClient"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181452588}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Rect();c.dispatchEvent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181452645}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(new PointerEvent('pointermove"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181511680}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"',{bubbles:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181511732}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"true,clientX:r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181511766}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".left+r.width*0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181511812}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"55,clientY:r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181595635}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".top+r.height*0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181595681}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5}));return 'hover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181595732}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'})()\n```\nThen wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181595793}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181740708}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181740761}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181740802}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my CDP after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181740854}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wait default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181796000}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400; set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181796062}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181796107}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"500.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181796155}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me run:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181871562}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hover,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181871641}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181871698}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181871753}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181932848}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_o663u8iwysqwa3yuloa9307i","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181932939}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933007}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933055}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933102}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933164}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933228}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933286}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933341}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933404}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933613}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933694}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933762}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933821}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933911}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" BASE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181933987}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934064}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934126}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934202}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934269}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934323}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934368}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934462}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181934514}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181935594}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181935648}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181935690}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181935741}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181962919}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181962966}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181963022}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181963072}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181964324}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181964384}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181964425}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181964469}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181980568}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181980624}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181980668}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181980717}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181981431}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181981477}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181981518}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181981557}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181990174}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181990228}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181990283}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125181990336}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182010767}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182010819}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182010877}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182010937}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182011184}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182011231}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182011300}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182011383}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182038295}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182038368}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182038421}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182038489}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182041956}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182042030}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182042090}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182042148}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057474}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057556}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057623}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057688}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057743}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057803}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057879}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182057924}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182080895}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182080988}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182081065}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182081127}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182094039}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182094120}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182094168}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182094215}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182125946}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BASE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182126032}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182126104}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182126146}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182126345}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182126434}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182126493}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182126554}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182140877}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182140943}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182141007}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182141065}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182157457}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182157508}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182157590}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182157801}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182157872}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182157915}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182157954}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182158014}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182171585}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182171724}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182171843}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"over"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182171960}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182189988}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182190096}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182190182}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182190268}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182190353}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182190433}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182190513}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182190595}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182276362}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182276542}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182276634}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182276693}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182297570}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182297668}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182297747}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182297826}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298060}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298157}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"clude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298244}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298328}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" setTimeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298589}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298670}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298744}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182298844}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182305730}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182305876}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182306030}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182306109}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".getElementById"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182307850}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182307905}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182307976}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-pop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182308045}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315291}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315369}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315446}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315507}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315706}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315794}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ounding"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315859}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Client"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182315930}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182321744}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182321802}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182321842}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182321917}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ispatch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182334956}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182335029}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182335113}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Pointer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182335180}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182335991}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182336305}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pointer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182336374}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"move"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182336469}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182351071}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182351122}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182351190}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ubb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182351266}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"les"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374091}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374166}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374212}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374262}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"client"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374766}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"X"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374845}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374907}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182374958}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".left"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182388343}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182388390}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182388448}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182388518}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182403461}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182403519}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"55"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182403572}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182403641}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"client"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182403889}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182404256}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182404332}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182404402}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".top"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182422122}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182422183}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182422567}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182422642}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182441380}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182441445}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182441500}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182441541}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182493885}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182493963}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"220"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494029}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494095}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494146}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494341}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494398}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"clude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494461}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494546}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"over"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494626}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494698}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494805}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494867}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494917}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182494977}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"340"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182495025}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182495075}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182495119}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182495184}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182495257}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182508344}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182508398}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182508442}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182508519}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182529145}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182529204}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182529261}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182529312}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182548207}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182548268}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182548329}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182548378}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182568214}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182568283}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182568341}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182568398}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182588667}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BASE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182588768}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182588849}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182588904}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182692341}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182692421}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182692491}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182692546}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182703101}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182703198}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182703281}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182703381}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182714428}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182714503}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182715323}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182715416}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182715485}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182715548}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182715613}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182715692}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182719441}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182719502}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182719546}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182719587}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182723629}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182723705}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182723744}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ense"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182723797}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182725959}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182726005}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182726073}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182726159}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182726853}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182726940}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182727048}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182727125}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182727230}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182727298}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182727392}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182727486}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182735282}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182735364}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182735445}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182735510}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182769736}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182769791}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"clude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182769836}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182769893}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182771746}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182771844}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cluding"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182771925}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182772008}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182772518}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182772593}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182772656}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182772715}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"360"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182776451}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182776499}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182776548}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182776593}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182803699}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182803793}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182803880}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182803940}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182835984}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182836062}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182836127}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182836174}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182836692}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182836753}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182836800}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182836850}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182855277}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182855329}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hover"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182855381}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182855435}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182887696}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182887747}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dense"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182887787}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182887830}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182908051}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182908120}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182908180}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182908238}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49231,"ts_us":1793125182972694}}

data: {"id":"6b68f8e97eb972ba6cd6428e17429864","object":"chat.completion.chunk","created":1793125178,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":234271,"completion_tokens":937,"total_tokens":235208,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":233216,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":594,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":49231,"ts_us":1793125182972817}}

data: [DONE]

