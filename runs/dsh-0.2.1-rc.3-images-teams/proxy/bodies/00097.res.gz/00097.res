data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421624623}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_veqo8auw5n3wil5bag00ru2h","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421673794}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421673872}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421673942}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421706620}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421706700}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421706763}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421706810}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421711671}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421711747}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421711787}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421711838}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421747778}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421747829}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421747898}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421747981}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421748555}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421748628}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421748696}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421748760}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421767638}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421767690}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421767733}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421767775}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421767822}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421767869}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421767949}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421768007}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421781890}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421781940}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421781995}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421782047}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421809906}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421810005}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421810077}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421810148}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421810343}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421810411}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421810486}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421810563}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421828627}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421828674}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421828717}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421828770}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421842813}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421842863}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421842952}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421843053}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421856287}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421856347}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421856404}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421856436}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421857195}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421857372}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421857444}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421857507}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421876609}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421876673}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421876734}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421876777}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421929138}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421929230}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421929276}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421929319}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421930059}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421930120}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421930155}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421930195}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421931049}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421931140}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421931219}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421931282}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421944932}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421945012}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421945085}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421945128}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421962531}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421962616}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421962700}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" corrected"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123421964119}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123422047545}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123422047596}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3027,"ts_us":1793123422047643}}

data: {"id":"192473e63205d4d6fbcdcd02c245bca1","object":"chat.completion.chunk","created":1793123421,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":127177,"completion_tokens":117,"total_tokens":127294,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":119424,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3027,"ts_us":1793123422051740}}

data: [DONE]

