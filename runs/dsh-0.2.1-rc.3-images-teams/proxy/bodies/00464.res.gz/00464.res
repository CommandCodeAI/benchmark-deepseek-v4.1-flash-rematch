data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741636017}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741680890}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741680939}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `id=\"vit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741681339}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rine-caption\"` to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741740879}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" figcaption and update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741741101}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" figure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741741525}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria-labelledby."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741741547}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741824069}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741824092}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_q1x7gci75pp3g7h7sen9as97","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741824268}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741824600}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741824643}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741825076}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741825101}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741825120}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741923341}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741923604}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741923687}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741923836}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741934009}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741934096}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741934412}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741934625}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741957926}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741958014}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741958176}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741958269}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741967243}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741967291}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741967406}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741967434}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741982464}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741982544}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741982569}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741982593}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741999757}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126741999894}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742000069}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742000093}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742000686}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742000767}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742000952}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742000977}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742016022}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742016142}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742016378}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742016404}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742032282}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742032410}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742032458}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742032607}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742086855}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742086887}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742086922}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742086957}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742109690}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742109961}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742109981}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742110000}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742110268}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742110373}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742110975}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742110999}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742116661}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742116708}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742116825}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742116867}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117197}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117417}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117440}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117872}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117895}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117916}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117936}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742117954}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742184847}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742184875}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742184911}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742184990}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185021}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185599}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185630}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185655}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185679}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185707}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185725}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"figure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185743}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" class"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185893}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185917}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742185938}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742186347}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742186642}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742186663}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-lab"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742186826}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742186867}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"by"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742186990}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742187014}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742187034}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742187053}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742187380}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742187404}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ca"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742187425}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pless"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742187592}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198143}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198177}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198220}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"figure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198243}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" class"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198739}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198768}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198853}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742198878}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742216406}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742216430}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-lab"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742216667}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742216688}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"by"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742232875}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742232904}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742232925}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742233098}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742233609}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742233666}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742233994}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742234015}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742244346}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742244396}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742244476}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742244638}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742264531}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"caption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742264554}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" class"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742264624}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742264644}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742265305}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742265337}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742265423}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"caption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742265452}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742278778}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742278802}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742278821}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742278847}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"caption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742291967}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" class"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742291994}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742292219}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742292254}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742292727}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742293118}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"caption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742293144}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742293168}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742310387}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742310444}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742310529}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742310561}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742325044}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742325071}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742325193}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742325215}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742325940}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742325965}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742326012}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742326149}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742342040}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742342063}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742342084}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742342336}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742356418}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742356481}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742356762}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" figure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742356795}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" caption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742407230}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742407256}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742407278}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742407304}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742407635}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742407936}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742407964}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742408009}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742409977}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742410001}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742410073}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742410093}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742412678}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742412707}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742412774}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742412972}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742422087}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742422208}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742422232}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742422280}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742422960}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742422981}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742423071}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742423125}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742454314}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742454366}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ids"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742454557}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742454581}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742460546}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742460737}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742460765}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"all"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742460801}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742462284}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742462309}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bid"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742462329}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742462347}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742472947}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742472972}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742472998}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742473061}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742487539}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742487564}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742487635}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742487655}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742504991}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=[]\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742505015}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742505104}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" attr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742505142}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742524280}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742524456}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742524490}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-lab"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742524810}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742546081}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"by"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742546104}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742546199}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742546326}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-described"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742547705}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"by"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742547725}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742547747}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742547802}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-control"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742560649}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742560674}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742560743}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742560824}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742572374}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"owns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742572417}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742572534}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742572562}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742573175}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742573210}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742573236}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742573265}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742590669}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742590694}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742590716}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"attr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742590865}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742610030}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742610109}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742610243}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742610278}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742611057}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742611105}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742611142}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742611194}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742630979}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742631026}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"):\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742631208}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742631267}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742640561}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742640619}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742640697}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742640766}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".group"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742642075}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742642119}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742642320}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742642359}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"split"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742660657}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"():\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742660706}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"  "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742660743}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742660785}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742682806}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742682973}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742683015}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ids"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742683103}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742683544}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742683587}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".append"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742683622}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742683696}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"attr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742696023}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742696076}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742696109}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742696164}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742715567}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742715595}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742715796}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742715825}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742734666}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742734695}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742734920}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742734945}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742754387}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742754414}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742754705}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742754746}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742779230}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742779255}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742779496}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742779518}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742786244}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742786270}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" broken"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742786363}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742786645}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-lab"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742815556}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742815580}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"by"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742815600}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reference"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742815761}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742890850}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":50120,"ts_us":1793126742890876}}

data: {"id":"8b7e05d994372f9ccce9ceaf1ae36e47","object":"chat.completion.chunk","created":1793126741,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":338891,"completion_tokens":357,"total_tokens":339248,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":337920,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":26,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":50120,"ts_us":1793126742890959}}

data: [DONE]

