data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879829943}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879830090}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it against"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879830164}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mock preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879885535}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need rebuild preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879885604}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first (design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879885655}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879885705}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed, shell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879946099}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879946388}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with btn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879946510}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-record). Ass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123879946637}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"emble +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880120949}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mock then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121006}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run CDP."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121057}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_j1zebwurd22lssuyzglnckm4","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121111}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121160}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121542}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121620}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121691}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121738}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121801}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121880}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121945}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880121998}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880122044}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880295657}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880295738}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880295806}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880295875}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880295917}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880295964}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296187}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296258}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296335}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296397}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296453}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296847}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296916}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880296977}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880297033}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880297089}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880297137}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880297929}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880297974}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880298015}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880298055}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880298096}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880298256}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880298330}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299020}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299066}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299106}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299166}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299220}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299269}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299895}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880299940}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880300026}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880300100}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880300162}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880300228}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880300274}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880300845}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880300956}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880301039}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880301087}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assemble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880301127}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880301165}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880301928}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880301976}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880302020}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880302071}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880302179}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880302234}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880302290}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303108}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303164}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303208}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"quiet"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303255}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303326}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303414}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303492}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880303964}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304012}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304090}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304160}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304678}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304752}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304821}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304868}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880304913}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880305000}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880305662}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880305716}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880305782}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880305860}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880305921}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880305965}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880306593}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880306645}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880306732}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880306798}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880306834}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880306973}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880307019}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880307797}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880307893}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880308555}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"WD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880308754}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880308918}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880309026}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880320960}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880321011}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880321151}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880321278}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880321939}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880322001}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880322150}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880322216}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880338569}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880338666}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880338749}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880338799}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880389002}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880389106}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880389257}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880389316}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880390241}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880390335}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880390456}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880390501}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880411409}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880411742}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880411819}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880411917}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880446961}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" QA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880447014}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" against"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880447186}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880447476}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880492056}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6267,"ts_us":1793123880492575}}

data: {"id":"c1ce28c9c62311e2cb3c470fa8931396","object":"chat.completion.chunk","created":1793123879,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":208462,"completion_tokens":192,"total_tokens":208654,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":201728,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":30,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6267,"ts_us":1793123880493265}}

data: [DONE]

