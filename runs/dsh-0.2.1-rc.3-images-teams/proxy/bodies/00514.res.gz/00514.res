data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424041196}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424133907}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sleep "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424133957}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"80 command itself got"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424133992}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" backgrounded due to 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424287482}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s tool cap. Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424287532}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check logs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424287571}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly with a quick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424287618}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" command ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424366577}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"no sleep)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424366632}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ketmwrm0bcc6uka43uqgv6sn","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424366770}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424366833}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424366883}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367006}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367071}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367204}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367252}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367392}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367568}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367616}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367665}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367705}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367780}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367831}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367878}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424367952}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424368011}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424368062}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424372692}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424372736}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424372877}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424372939}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424400265}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424400312}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424400450}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424400513}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424422098}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424422153}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424422288}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424422342}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424439494}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424439554}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424439606}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424439642}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424460664}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424460719}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424460819}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424460878}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424481302}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424481366}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424481414}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424481506}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424496082}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424496141}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424496184}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424496318}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424511101}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424511180}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424511236}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424511268}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530290}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530341}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530381}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530485}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530693}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530833}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530890}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424530998}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424539444}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424539494}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424539536}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424539600}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424594413}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424594462}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424594554}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424594658}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424595403}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424595480}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424595569}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424595650}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424595739}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424595849}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424595983}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424596027}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424596146}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424596198}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424596248}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424596299}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424600841}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424600893}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424601035}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424601133}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424601229}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424601368}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424601485}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424601571}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424620190}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424620279}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424620359}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424620437}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424657984}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424658041}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424658109}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424658207}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424658311}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424658381}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424658445}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424658501}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424659159}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424659268}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424659429}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424659487}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424671895}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424671942}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424672006}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424672100}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424672430}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424672518}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424672644}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424672701}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424735631}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424735725}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424735798}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424735870}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424736226}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424736321}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424736359}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424736486}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424737301}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424737383}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424737493}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424737553}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424758724}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424758862}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424758929}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424758982}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424778283}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424778340}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424778413}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424778503}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424795156}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424795220}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424795298}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424795490}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424831689}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424831787}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" matrix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424831841}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" logs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424831896}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424903209}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6428,"ts_us":1793127424903274}}

data: {"id":"25840b245d4d3b9fb20099a21d93eb81","object":"chat.completion.chunk","created":1793127423,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":363641,"completion_tokens":205,"total_tokens":363846,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":363264,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":30,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6428,"ts_us":1793127424903469}}

data: [DONE]

