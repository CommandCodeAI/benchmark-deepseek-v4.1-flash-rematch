data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716815129}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0g6cgngj1u8diadm3pu130o7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716815244}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716815296}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716815366}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716815417}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716815470}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716815518}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716827418}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716827888}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716827951}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716828001}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716847822}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716847956}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716848098}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716848615}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716880439}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716880727}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716880818}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716881452}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716898990}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716899074}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716899147}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716899219}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716911620}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716911798}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716911900}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716913126}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716927923}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716928039}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716928142}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716928198}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716944283}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716944341}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716944519}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716944649}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716945144}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716945253}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716945467}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716945528}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716975456}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716975600}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716975746}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716976021}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716995854}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716995928}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716996078}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123716996235}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717016636}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717016733}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717016874}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717016928}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717017262}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717017327}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717017677}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717017760}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717031235}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717031505}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717031721}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717031797}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060019}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060072}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060253}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060374}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060535}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060610}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060677}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717060987}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717075964}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717076172}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717076276}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717076346}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717088461}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"disable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717088581}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717088741}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pu"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717088783}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717088988}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717089291}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717089355}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717089630}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717111425}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717111496}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717111585}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-data"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717111718}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717117260}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717117348}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717117414}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717117567}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717117762}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717117975}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717118044}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717118089}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717139951}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717140118}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717140181}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717140502}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bars"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717158347}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717158523}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"force"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717158567}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717158775}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717158816}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-scale"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717158875}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-factor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717159576}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717159626}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717168785}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717169025}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717169092}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717169174}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717191898}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717192024}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717192262}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717192337}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717192839}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717192909}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717192969}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717193033}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717207550}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717207873}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717207943}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717208053}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717222566}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717222643}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717222710}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717223320}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717223392}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"virtual"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717223637}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717223705}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717224079}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"udget"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717244716}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717244804}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717244957}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717246520}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717262510}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717262608}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717262749}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717262852}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717262937}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"WD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717263016}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717263101}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717263171}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717274591}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717274689}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717274912}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717274989}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717289432}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717289588}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717289758}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717289882}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717290221}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717290396}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717290599}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717290651}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717305320}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717305476}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717305554}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717307253}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717352836}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717352949}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717353022}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717353852}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717356928}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717357001}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717357139}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717357328}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717362768}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717362831}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717362951}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717363083}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717377839}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717377935}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717378128}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717378175}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717436867}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717436997}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717437075}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3114,"ts_us":1793123717441301}}

data: {"id":"10d8cce83547cbf4b488911ab4eba50b","object":"chat.completion.chunk","created":1793123716,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":187780,"completion_tokens":209,"total_tokens":187989,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":184960,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3114,"ts_us":1793123717441787}}

data: [DONE]

