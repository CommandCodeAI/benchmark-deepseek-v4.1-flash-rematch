data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572689300}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572724852}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cursor label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572724946}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is indeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572725148}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paper with brass border"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572803582}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572804528}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot at 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572804626}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572804703}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dark only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572889185}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due small size"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572890074}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n\nHowever in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572890199}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572890345}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier screenshot the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572969203}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rule has \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572970114}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"GEN 12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572970260}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / 13\" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127572970320}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573002830}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" notes;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573003787}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice. The weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573003873}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seal has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573003958}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"P\" circle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573165803}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n\nWe should wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573166738}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573166873}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier final. While"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573166920}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" waiting, inspect final official"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573261453}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573262501}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 screenshot and "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573262612}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024 perhaps. "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573262758}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280 earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573318272}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looked good. View"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573319140}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573319252}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-live-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573319306}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573386760}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_4jz5z72g0ba6aw814locf6dz","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573387806}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573388016}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573388066}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573388184}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573388233}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573388290}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573398815}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573402530}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573403633}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573403775}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573403893}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573423078}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573424206}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573424297}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573424342}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573434490}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573435414}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573435511}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573435559}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573435671}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573435782}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573448681}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573448739}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573459396}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573460404}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573460513}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573460574}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573466169}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573466268}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573470473}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573470520}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573480188}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573481164}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573481257}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573481347}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573481481}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573481574}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573494389}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573494459}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573504158}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573505140}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573505332}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573505377}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573517654}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573517710}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573519565}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573519659}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573519763}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573519845}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573519937}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573520035}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573577008}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573577102}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573577218}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573577309}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573587850}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573587957}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573588128}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573588276}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573619465}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573620603}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11138,"ts_us":1793127573620700}}

data: {"id":"da355b66236032560f689c664832b2d5","object":"chat.completion.chunk","created":1793127572,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":358994,"completion_tokens":188,"total_tokens":359182,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":358016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":98,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":11138,"ts_us":1793127573626786}}

data: [DONE]

