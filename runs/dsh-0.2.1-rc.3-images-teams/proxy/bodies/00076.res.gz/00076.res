data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261414440}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261473729}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3: actually has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261473836}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261474949}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles: flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261519829}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" peaks 129"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261520054}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1, crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261520203}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 39"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261520283}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261590186}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"overs; herbivores dip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261590481}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261590613}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261590705}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 289"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261728254}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261728678}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predators dip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261728745}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261728876}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261752954}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 64. At gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261753065}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40, predator "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261753225}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64, herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261753286}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261811138}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 96, flora 254"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261811259}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261811454}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261811494}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" alive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261895367}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261895546}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" about"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261895743}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to crash. Charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261895783}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261985826}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show dramatic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261985914}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261986233}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actually good! But traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123261986287}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262043899}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bounds: predator speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262043983}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reaches 1.85 max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262044374}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", herbivore threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262044420}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262116557}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifts to 0.85"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262116685}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262116910}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.47"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262116949}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predators max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262177989}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed. Tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262178181}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"it evolution visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262178245}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but hitting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262178465}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bounds is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262269163}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not ideal ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262269222}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"could clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262269479}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Accept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262269549}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262311060}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262311183}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue is some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262311332}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds go"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262311504}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct. The ask"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262390455}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is \"ev"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262390548}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"olving ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262390602}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262390996}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262453428}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for N generations\" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262453529}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262453890}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inctions of a species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262453959}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could be a valid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262526357}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outcome but for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262526459}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262526727}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design showcase we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262526769}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" want all three present"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262597366}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" most"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262597523}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262597570}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262598018}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262667919}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" markers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262668012}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262668346}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262668479}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262738455}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262738556}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262738791}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262738863}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/12 seeds had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262801834}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all three"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262802008}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" alive at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262802080}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40; others"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262802344}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262889206}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262889407}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could improve robustness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262889478}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nObservations from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262889778}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 3: flora bloom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262953015}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262953165}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rash cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262953222}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" driven by herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123262953652}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore bo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263023322}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oms; predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263023413}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263023635}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263023684}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators almost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263097542}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263097717}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263097813}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263098106}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") but recover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263170547}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263170740}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263170878}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom they boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263171137}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263259317}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263259417}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263259781}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash; next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263259837}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263316443}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators die. To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263316553}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" damp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263316627}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"en"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263316715}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263472422}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator maximum"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263472565}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth? Their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263472743}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263472823}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6 to 64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263487292}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over 34"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263487516}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263487622}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crazy. Herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263487841}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263525773}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263525947}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263526011}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263526245}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predators follow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263608948}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The core cycle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263609084}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263609430}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore-fl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263609531}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora oscillation with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263684163}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263684522}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263684590}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263684676}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" amplitude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263773355}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", make herbivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263773436}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263773580}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263773624}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" destructive /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263830604}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263830747}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263830793}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263831109}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 plant crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263901098}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263901191}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 129"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263901236}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 (gen16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263901485}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") to 39"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263971120}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (gen32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263971236}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263971277}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore from 146"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123263971586}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 289"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264037817}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264037878}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are being"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264038016}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264038063}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264103236}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"razed massively ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264103314}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eaten 2000 bites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264103495}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen while flora "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264103542}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264191307}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264191457}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264191711}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" production"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264191794}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can't keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264249816}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up. The system"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264250138}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" relies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264250204}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264250426}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264343879}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264344060}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limit herbivores; then herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264344123}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores crash; plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264344354}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover. Big"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264412718}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" amplitude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264412926}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- We could cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264412991}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivore reproduction more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264413139}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264509502}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264509607}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 340 currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264509683}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; actual 289"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264509938}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264571463}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and reduce grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264571584}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264571773}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264571842}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264645493}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264645544}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264645759}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264645794}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" severe. Also increase plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264708499}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264708667}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264708704}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"prout so recovery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264709097}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264784288}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", shortening"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264784426}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264784614}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. With"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264784690}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264850197}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264850285}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"39, spr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264850429}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out scarcity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264850603}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiplier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264933312}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~3.2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264933389}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" × 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264933448}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".4 ≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123264933633}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265037944}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265038026}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 330 seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265038161}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265038193}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so recovery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265152749}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would be quick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265152915}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265153042}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265153194}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumed immediately"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265170521}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but herbivores at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265170606}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 289 eat sprouts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265170876}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265170946}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265210927}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". A plant refuge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265211032}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mechanism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265211148}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (e.g., seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265211221}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can establish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265267761}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" where"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265267833}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores aren"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265267908}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265268088}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would help;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265338950}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clustering is broken"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265339001}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265339138}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make plants grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265339209}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster overall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265416261}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265416321}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265416366}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to ensure food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265416480}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" floor: increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265504415}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265504480}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265504537}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265504800}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265569122}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265569306}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265569467}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265569535}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265642151}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" won't go beyond"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265642207}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265642311}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265642359}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265751757}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265751878}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265751928}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cap lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265752078}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (250) so consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265783753}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265784027}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265784102}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265784353}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265869099}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265869203}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265869534}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265869601}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 84"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265932270}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265932362}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265932627}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123265932684}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–250. Vis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266009596}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ually that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266009824}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s fine.\n\nBetter idea"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266009917}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": make the \"food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266010047}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266073413}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth\" parameter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266073491}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meaningful with default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266073618}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.0 resulting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266073742}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in stable richness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266145187}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266145312}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Increase K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266145399}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".floraGrowth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266145596}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Base"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266215311}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and metabolism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266215374}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266215521}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" production"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266215575}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266287379}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" currently ~200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266287472}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seedlings"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266287672}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen; at flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266287748}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266367433}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800, growth 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266367516}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".012"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266367583}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266367645}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick*800*30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266434772}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266434853}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266434921}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", growth per plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266434991}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266508506}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.012*("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266508656}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1-e/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266508859}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.55) ≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266508943}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.005"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266576192}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266576388}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266576454}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 = 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266576596}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".15 energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266706280}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266706410}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266706462}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800 = 120 energy/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266706780}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266720086}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" removes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266720187}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266720243}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266720552}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266828790}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy/gen ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266828963}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266829113}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 bites ×0.18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266829192}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=360). So plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266873858}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can't sustain. Herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266873956}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores need to eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266874144}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266874338}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266975554}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266975603}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.18 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266975665}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.12 and digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123266975914}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.55"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267033328}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267033436}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2000 bites = 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267033539}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy; intake"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267034829}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267101773}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivore lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267101921}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267102126}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267102189}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267193170}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267193252}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267193483}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overgra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267193523}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ze (same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267259051}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" number of bites) but less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267259144}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy extracted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267259394}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Their reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267259484}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" depends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267321944}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267322112}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267322270}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267322350}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267401034}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267401262}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267401320}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267401359}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267473093}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s the feedback. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267473145}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adjust bite to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267473204}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267473248}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267536874}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" digest 0.6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267537030}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267537245}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267537290}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant energy capacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267637075}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recovery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267637216}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let's test a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267637263}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sweep.\n\nAlso predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267637524}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now survive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267681419}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267681467}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267681509}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to energy storage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267682401}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267756242}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inctions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267756291}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in seed 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267756393}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",2 where"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267756576}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267840972}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267841077}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", driven"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267841217}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267841348}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash? Trace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267944474}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267944641}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_okjy1o81fo55gef7xlarfmgj","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267944692}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267944950}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267944999}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267945032}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267945566}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123267945615}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074156}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074236}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074282}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074396}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074749}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074791}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074918}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268074981}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268086938}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268087059}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268087142}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268087281}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268093803}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268093933}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268094107}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268094241}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268094728}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268094973}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268095021}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097227}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097298}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097362}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097410}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097464}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097515}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097574}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097624}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268097667}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268098492}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268098606}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268098725}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268098767}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268103145}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268103262}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268103326}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268103441}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268112577}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268112628}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268112749}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268112804}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268113522}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268113617}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268113727}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268113785}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268119440}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268119551}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268119712}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268119768}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"===="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268137759}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268137807}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268137859}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268137935}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268138321}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268138514}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"===="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268138563}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268138632}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268158822}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268158900}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268159036}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268159089}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268178518}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268178655}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268178693}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"race"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268179134}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268198847}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268198925}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268199096}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268199220}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268199422}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268199500}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268199660}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268199726}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268223902}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268223960}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268224068}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268224136}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268243829}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268244009}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268244154}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268244277}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268257853}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Trace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268257971}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" collapsed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268258143}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ecosystem"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268258199}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268276796}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268276915}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268276991}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268277079}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2718,"ts_us":1793123268404763}}

data: {"id":"94a9151bad8a0bc3d0c8ec1500e859ce","object":"chat.completion.chunk","created":1793123261,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":135273,"completion_tokens":1008,"total_tokens":136281,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":129792,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":878,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2718,"ts_us":1793123268404845}}

data: [DONE]

