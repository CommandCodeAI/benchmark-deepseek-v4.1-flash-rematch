data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965396629}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965505428}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965505478}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harness. Write `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965505527}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"verify/lib/engine.mjs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965565426}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` with load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965565483}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965565577}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965569590}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965638815}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runner for browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965638900}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-side"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965641546}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965641600}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965705699}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a string"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965705778}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965705833}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" used by CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965705947}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965766812}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965766882}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"verify/engine.test.mjs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965767121}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965767202}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me write an in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965852622}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-page test function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965852715}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965852787}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a big"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965852858}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" string that runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965919316}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965919404}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965919471}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965919747}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and returns JSON"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965984676}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Actually simpler:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965984719}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965984758}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122965984817}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node; for browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966090274}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parity just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966090342}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" get hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966090419}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966090614}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a couple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966176140}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966176220}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966176284}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Runtime.evaluate."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966176327}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966235500}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task says \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966235578}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Also test the same code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966235710}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extracted from the assembled index"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966235768}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".html if feasible\". I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966290577}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can do more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966290734}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": in the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966290796}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser, run the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966290898}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966362353}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966362418}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Complex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966362467}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Alternative: extract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966362881}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine source"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966426471}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966426547}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HTML reliably using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966426600}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" src"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966426870}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/engine.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966487246}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966487321}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" comparison"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966487386}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966487442}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966568129}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `assemb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966568182}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"led`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966568228}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966568270}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Src"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966637667}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966637765}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"byte"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966637837}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-identical), then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966638043}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the engine code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966691682}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in assembled =="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966691730}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" src/engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966691778}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966692316}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966741926}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suffice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966741991}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966742044}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966742143}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks `typeof"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966819239}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" window.VIVARI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966819313}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UM_ENGINE === '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966819407}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"object'`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966819507}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and hash parity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966906276}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- If not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966906353}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical (because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966906406}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966906453}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" escapes `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966976322}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"</script>`), do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966976396}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" normalization:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966976598}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122966976657}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Src.replace(/<\\/script>/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967056027}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gi"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967056083}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967056120}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"<\\\\/script>')"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967056413}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` then includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967113492}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967113541}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" missing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967113639}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", could extract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967113681}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967168515}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finding start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967168577}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marker:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967168708}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967168761}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starts with comment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967233935}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967234031}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/*`..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967234114}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but comments"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967234163}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967311741}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vary. Alternative extraction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967311863}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": find the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967311920}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" position"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967311983}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of `V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967369954}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVARIUM_ENGINE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967370017}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` assignment in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967370081}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inline script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967370220}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then balanced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967456426}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-brace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967456478}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scan backwards"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967456514}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967461921}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the IIFE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967525461}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start. Too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967525507}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fragile. We'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967525586}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rely on include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967525740}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check + browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967584946}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parity; if include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967585021}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967585070}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", report flag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967585113}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967655851}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967656051}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lined verbatim /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967656090}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extraction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967656220}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failed\".\n\nActually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967716135}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967716207}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can extract in-b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967716260}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowser engine by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967716372}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" executing the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967764738}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967764816}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inline script in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967764878}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967764990}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" isolated if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967858888}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rame-like environment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967858935}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967858975}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm no.\n\nBetter:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967859021}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967936871}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vm can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967936915}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" load full assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967936996}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inline script if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967937081}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we provide DOM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967986393}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shims enough for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967986446}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot/re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967986508}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nder/controls/d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122967986566}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ashboard to at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968076668}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" least execute"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968076748}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968076802}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throwing. That's brittle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968076879}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968136187}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modules evolve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968136579}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Skip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968136681}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968136759}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968246842}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + browser parity is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968246950}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sufficient"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968247193}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evidence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968247267}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBrowser parity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968308769}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test: evaluate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968308819}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968308860}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".VIVARI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968308939}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UM_ENGINE`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968381495}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" availability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968381544}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968381664}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968381714}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World(r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968451249}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"unHeadless("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968451335}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"createWorld({"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968451422}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed:1977"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968451479}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}),40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968526686}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"))` inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968526733}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser, compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968526781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968526829}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" value"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968583900}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968583975}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968584036}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"controls mutated state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968584087}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968672433}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wouldn't affect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968672479}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this isolated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968672519}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968673176}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n\nNow engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968724305}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests. Let me write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968724355}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carefully,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968724391}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" accounting for the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968724678}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968825605}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract. I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968825680}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need to be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968825721}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tolerant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968825780}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of reasonable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968895688}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968895805}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968895896}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" length: run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968896235}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation records"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968946685}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968946747}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; generation starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968946776}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0. After run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122968946862}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969006263}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less(w,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969006337}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40): generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969006521}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969006584}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40, history length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969061802}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 (maybe "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969061875}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"41 if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969061914}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969061961}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 entry"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969121625}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969121673}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm `history:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969121731}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [{gen,...}]"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969122909}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` — likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969209701}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969209757}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" push after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969209809}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969210404}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969281670}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 entries gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969281731}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969281776}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..40,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969281818}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or push"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969349179}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969349270}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969349395}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too. Test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969349478}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969446671}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969446754}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history entry"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969446822}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen === world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969447081}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generation, history.length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969499561}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >= gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969499651}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969499800}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entries"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969499866}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sorted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969564418}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969564478}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969564782}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0, length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969565445}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 41. Accept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969618002}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" either. For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969618054}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969618112}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969618168}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" axis "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969729464}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0..N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969729528}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needs history to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969729597}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" include "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969730355}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 maybe;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969825137}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chartwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969825211}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can handle."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969825466}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969825518}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969931298}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen === 40 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969931366}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969932304}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >= 40?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969932350}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969984993}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation increments"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969985070}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0→"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969985124}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 and history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122969985178}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970043299}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970043406}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..40 → "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970043445}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"41. Accept length>="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970043564}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970101731}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970101775}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" non"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970101812}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-negative integers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970101848}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970154457}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- traits all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970154552}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 taxa"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970154632}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" × 4 genes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970154719}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", each mean/sd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970213623}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/min/max finite,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970213695}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970213745}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"<=mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970213797}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"<=max?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970260969}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970261033}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970261077}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970261136}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970320675}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/max? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970320744}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", mean ∈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970320830}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [min,max]"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970320921}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970427483}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970427548}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ax are actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970427618}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min/max."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970427737}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sd >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970495353}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.\n- get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970495432}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Stats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970495471}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970495540}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"orld).count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970555525}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970555592}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" traits present"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970555638}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970555693}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Stats maybe returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970617309}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970617373}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970617429}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970617553}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stub; real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970674749}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970674820}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" match contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970674879}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- diversity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970674933}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970742657}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (≥"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970742723}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0).\n- mutations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970742776}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ThisGen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970742896}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" integer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970797419}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≥0.\n- events types"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970797484}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" valid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970797541}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970797609}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970923270}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970923363}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970923419}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970923456}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=3, catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970977683}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes=true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970977728}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970977777}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60 gens. Expect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122970977823}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971031032}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens approx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971031116}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiples of 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971031170}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (3,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971031599}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6,9...)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971081728}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971081810}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971081858}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971081901}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=interval."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971129971}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Gap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971130446}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971130505}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971130561}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971211837}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971211891}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971211934}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971211995}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens between"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971283006}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971283098}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971283182}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971283435}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971339296}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consecutive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971339340}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gap equal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971339382}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to interval ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971339439}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"maybe ±"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971408298}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971408430}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971408542}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971408630}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971458041}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine random"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971458162}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"izes within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971458424}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971458640}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971552997}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" accept "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971553090}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971553147}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971553199}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971599652}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971599723}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": number"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971599853}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of events within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971599912}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [floor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971700300}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971700363}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/interval)-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971700408}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1, floor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971700529}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(60/interval)+1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971770725}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"], and if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971770789}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971770835}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inconsistent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971771419}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971817655}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971817714}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says \"config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971817821}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"urable interval\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971817881}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971881240}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduling expected."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971881305}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll assert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971881356}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971881415}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≈ and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971977596}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gap mode"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971977668}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" === interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971977727}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122971977987}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972058206}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fail with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972058298}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" detail ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972058345}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"but mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972058389}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" severity major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972136749}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972136812}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" randomness in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972136863}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" type"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972136957}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972223101}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm, maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972223191}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972223253}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adapt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972231158}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after seeing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972271292}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real engine."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972271344}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" For flexibility:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972271426}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compute"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972271495}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" observed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972329373}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gaps;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972329650}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assert all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972329710}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gaps >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972329806}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972472486}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972472600}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972472691}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 and event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972472778}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count >= interval-derived"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972545351}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972545703}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bound. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972545758}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972545802}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972596811}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972596873}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972596928}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" configurable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972596973}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" - I'd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972651278}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972651337}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972651392}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=3 vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972651539}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval=8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972711579}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972711645}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972711730}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972712195}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3. That's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972784757}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" robust:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972784815}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972784848}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60 gens with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972785515}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972852960}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 → n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972853032}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972853219}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972853289}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; interval 12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972955209}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → n12; assert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972955273}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" n3 > n12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972955320}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" * 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122972955431}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; assert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973012678}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" n3 >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973012781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973013352}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973013539}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973074198}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/3=20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973074289}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" minus tolerance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973074379}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"); n12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973075215}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973135329}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973135411}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973135485}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"]. Also all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973135585}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 types"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973195773}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appear over long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973195842}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run (200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973195896}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973195931}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3). And"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973255313}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973255370}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-check event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973255446}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen modulo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973255527}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973317940}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973318010}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973318076}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973318111}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973371934}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973372034}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if not exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973372111}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973372166}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973486687}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973486758}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973486812}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param(w,'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973487052}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973558349}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation',0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973558431}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".15)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973558498}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then config update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973558538}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973618910}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Snapshot().config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973618978}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mutation === "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973619036}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.15; setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973619089}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973670734}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → subsequent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973670800}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events spacing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973670854}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shrinks: run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973670994}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973719434}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973719509}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", count events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973719576}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973719637}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973812595}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973812648}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973812696}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973812802}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973926344}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973926418}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" worlds except"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973926478}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973926543}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973992435}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run... complicated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973992488}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Simpler check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973992527}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": after set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122973992574}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974041742}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"interval', 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974041801}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974041837}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974041901}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974110395}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974110444}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974110764}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events gaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974110815}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974164752}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4. Since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974164793}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974164837}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974164871}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use counter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974220054}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modulo interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974220127}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", changing might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974220169}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974220216}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974279990}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll assert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974280150}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974280281}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974280330}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and that count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974364284}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974364430}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974364473}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974366078}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 gens is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974432780}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974432830}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974432872}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",12]. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974432908}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine schedules"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974507343}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974507402}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Counter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974507486}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" % interval, likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974507606}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974578668}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974578719}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes false:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974578789}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974578896}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world {"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974642776}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"catastrophes:false"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974642828}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974642872}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":3},"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974643504}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974743688}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974743732}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".length ==="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974743785}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974743846}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" activeEvents "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974804755}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.\n- effects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974804818}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measurable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974804865}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974805747}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974863371}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974863421}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974863539}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122974863614}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975559524}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occurs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975559567}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (gen 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975559621}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"); getStats before/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975559667}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"after: event recorded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975617485}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and activeEvents non"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975617538}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-empty; history["},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975618601}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"event gen]."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975618658}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"event ==="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975672545}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" type; and at least"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975672636}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one species mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975672706}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count changes \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975672779}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"measurably\" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975769133}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard due to natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975769280}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics. Better: events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975769364}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"[0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975769441}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"] exists"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975832636}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975832720}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events length ≥1 after event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975832836}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then after duration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975833011}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens, activeEvents empty."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975885479}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also check effect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975885725}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" function:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975885787}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975886534}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975940324}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975940398}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975940519}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; compare flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122975940580}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976022957}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" delta during"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976023012}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" active event vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976023125}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" baseline?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976023400}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976090318}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"isy. Alternative:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976090358}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976090442}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976090489}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implement catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976181996}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976182042}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multipliers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976182096}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976182167}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976252667}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976252706}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test at event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976252746}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" firing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976252801}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen: history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976321504}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entry has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976321666}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976321731}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; and counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976321761}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976387908}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976387957}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sane"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976387993}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bounds."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976388061}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" For \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976450309}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"meas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976450375}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"urable\", compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976450483}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976450543}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976514403}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"catastrophes on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976514468}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976514520}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976514560}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed, interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976568541}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4) vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976568595}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world B (catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976568633}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes off) after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976568723}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976634078}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens: has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976634125}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hes differ /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976634162}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts differ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976634225}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976687047}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976687093}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parameter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976687140}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976687181}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outcome."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976741557}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976741600}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976741752}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events effect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976741785}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976796561}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976796615}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976796653}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976796693}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fauna"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976872511}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976872598}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976872655}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976872703}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976937323}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976937369}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wildfire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976937413}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976937456}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976997702}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drop >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976997747}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976997781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not guaranteed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122976998201}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977052550}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977052593}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977052649}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977052692}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977114317}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recorded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977115279}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977115342}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2) activeEvents non"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977115391}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-empty; ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977172897}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3) world with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977172996}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophes on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977173081}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs off diverg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977173338}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"es (different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977239681}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977239728}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ounts after "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977239768}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 gens). That's evidence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977241055}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977317010}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are applied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977317088}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977317150}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": craft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977317283}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" conditions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977380813}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": {"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977380877}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"width:20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977380933}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",height:10,m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977381535}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation:0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977431045}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2,regrowth:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977431100}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.2,interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977431151}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":2,seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977431333}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977489239}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"} run "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977489287}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"120 gens across seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977489322}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977489372}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1..10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977538523}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ensure no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977538595}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throws, counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977538670}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977539289}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, hash stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977587960}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" repeated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977588012}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977588050}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977588089}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" least one extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977667164}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977667235}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977667287}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 for some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977667364}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977732677}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977733078}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or any"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977733122}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977733520}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") → report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977791727}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977791800}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if none"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977791857}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977791909}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977930631}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" necessarily)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977930684}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977930726}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122977930771}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978024661}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978024710}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" continues without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978024756}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throwing for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978024811}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" another "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978103697}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20 gens.\n- param"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978103746}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extremes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978103829}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978103911}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978183299}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.2, reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978183382}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth 0.2 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978183442}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.5:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978183736}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978239406}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20 gens, finite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978239451}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values.\n- determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978239526}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism across processes: spawn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978239601}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `node verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978299442}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978299495}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-proc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978299539}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mjs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978299635}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <seed> <gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978357747}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":">` returning hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978357815}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978357851}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978357903}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978412513}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ocations;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978412582}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978412657}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process-independent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978412730}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978564489}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that inserting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978564543}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978564578}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978564612}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" operations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978627027}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978627080}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no effect: call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978627123}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" getStats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978627188}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/getSnapshot between gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978682424}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978682483}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978682550}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978682722}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run.\n- benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978743837}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978743966}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978744088}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978744189}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100) returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978805536}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" {ms,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978805670}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticksPerSec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978805769}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978805837}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finite; ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978871777}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" < 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978871850}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0? brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978871920}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978872065}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less faster than real time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978916648}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; real time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978916717}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 gens at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978916767}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978916908}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/s ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978968866}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978968914}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 ticks/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978968990}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60=50s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122978969138}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979031906}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979031980}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979032019}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979032073}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is strong"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979091070}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979091215}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979091269}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979091325}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979201756}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid fl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979201824}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aky CI,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979201858}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979201908}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also measure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979273540}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979273602}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979273650}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100 gens wall time separately"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979273935}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979329544}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" format"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979329596}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": non-empty string.\n- get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979330671}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Snapshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979330746}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979409025}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979409092}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed/generation/finished"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979409133}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979409174}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"istory?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979503518}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"plain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979503583}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state summary\" — test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979503645}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979503704}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s JSON-s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979557622}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"erializable and has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979557710}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed/g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979557821}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eneration/config maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979557879}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". L"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979641472}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oose: object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979641518}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", JSON"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979641564}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" round"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979641608}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-trip OK,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979705130}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979705187}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DOM nodes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979705271}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979705470}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"resetWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979773302}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979773387}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979773425}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979773469}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979823210}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0, seed override"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979823255}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" applied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979823289}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979823343}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" retained"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979895096}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", history emptied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979895149}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979895186}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" positive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979895230}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979950715}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runTick`: "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979950765}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979950825}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" => generation advances"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122979950869}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980025307}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1, tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980025360}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980025500}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980025582}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticksInto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980077111}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Gen 0 after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980077156}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980077198}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980077232}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980152792}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 30 ticks."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980152857}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Test run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980152996}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980153042}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"29 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980239303}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980239376}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980239432}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980239486}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"th → gen 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980306647}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Engine static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980306704}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scans"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980306763}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for Math"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980306835}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".random/Date:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980377447}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980377502}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" comments/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980377557}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"strings? Simple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980377626}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regex on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980507790}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980507857}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980507913}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" locations."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980508610}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Allowed maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980565000}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980565092}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980565182}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timing ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980565302}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"performance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980645470}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".now better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980645589}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980645656}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explicitly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980645953}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980715595}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Math.random / Date in simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980715682}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". Date"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980715748}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may appear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980715809}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in benchmark or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980790193}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" snapshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980790275}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timestamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980790346}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -> note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980790412}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as warn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980850491}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not blocker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980850563}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if outside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980850627}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980850686}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll detect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980911328}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occurrences and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980911431}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980911502}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" surrounding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980911570}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980966705}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980966783}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980968091}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Math.random appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122980968169}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" anywhere; Date"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981027142}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981027217}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981027278}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981027336}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" context;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981095514}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" classify:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981095582}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981095626}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benchmark function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981095674}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/performance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981146143}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981146221}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981146261}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; else"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981146428}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981273811}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981273879}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981273936}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pler: report both"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981273988}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981357422}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981357465}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if Math.random found"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981357499}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fail if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981357534}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Date found ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981442325}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"strict)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981442378}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but with note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981442439}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981442503}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981516202}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benchmark. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981516274}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me implement:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981516319}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regex line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981516371}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scan;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981604296}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exclude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981604342}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines containing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981604390}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 'performance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981604431}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981663962}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981664009}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Engine might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981664048}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use `Date.now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981664523}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` for benchmark;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981757777}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981757824}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says \"no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981757860}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Math.random / Date in simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981757901}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" — benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981819716}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is not simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981819778}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981819845}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll accept Date"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981819887}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only if inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981871412}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benchmark function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981871456}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (cr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981871510}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ude:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981871569}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check position after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981925976}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 'benchmark('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981926111}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and within next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981926169}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981926341}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines). Report as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981982910}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" NOTE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981982988}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981983117}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ENE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122981983209}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_KEYS exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982039022}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" array"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982039260}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- SPECIES"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982039302}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shape"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982039683}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": each has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982107888}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" id?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982107955}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Brief:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982108011}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `SPEC"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982108177}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IES: { flora: {..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982209571}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}, herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982209615}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora: {...}, carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982209677}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora: {...} },"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982209713}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" // id, latin, glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982297750}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", colors`. Check keys"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982297804}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", latin string"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982297840}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", glyph string"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982297879}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", colors object with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982358713}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at least"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982358781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a primary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982358814}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" color.\n- CAT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982359535}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ACLYS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982409780}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"MS keys"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982409827}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982409861}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plague, wildfire each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982409908}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with latin/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982491989}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"name/note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982492032}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982492073}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"uration?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982492122}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Brief comment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982544345}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982544394}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t specify fields"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982544428}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" beyond"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982544466}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" {..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982613065}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"};"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982613145}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shell expects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982613207}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982613396}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982674035}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982674103}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exists"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982674149}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982674227}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 keys.\n- D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982737253}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS exact values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982737300}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982737346}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982737395}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7, mutation "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982787553}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.06, reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982787635}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth 1.0,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982787670}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations 40, speed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982787710}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.0, interval "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982892968}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8, catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982893037}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" true, trails true,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982893186}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width 160, height "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982896719}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"90.\n\nThat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982953782}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a lot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982953847}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Write the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982953892}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine test file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122982953939}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983015800}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983015865}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":vm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983016090}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loader"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983016136}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso cross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983170634}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983170682}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"untime parity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983170717}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test happens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983171499}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in browser suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983231382}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983231433}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983231471}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"verify/lib/engine.mjs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983231579}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350289}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xj81nukt4pvcago6xzzlikyj","type":"function","function":{"name":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350349}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350420}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350541}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350602}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350671}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350800}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350857}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"//"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350904}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983350943}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" loading"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351431}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351520}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shared"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351565}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351603}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assertions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351649}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351818}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"DOM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351876}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-free"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983351924}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983352007}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983352087}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sand"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983352128}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983352193}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":").\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983352235}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"//"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983352263}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Works"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983362888}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983362948}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983363002}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983363048}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983370948}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983370991}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983371030}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983371067}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983399141}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" any"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983399189}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" extracted"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983399264}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" copy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983399339}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983471149}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" the"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983471256}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983471368}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983471444}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983555113}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983555165}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983555203}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983555249}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983556202}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983556248}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983556295}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983556340}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983556937}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983556986}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983557026}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983557069}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983557500}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983557882}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983557936}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983557979}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983558467}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983558517}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983558561}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983558626}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"export"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983573619}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983573668}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983573716}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983573758}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Source"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983578985}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983579047}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983579194}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983579250}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" filename"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983609025}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983609149}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983609209}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983609427}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983617532}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983617754}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983617809}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983618041}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983618174}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983618238}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983618283}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983618344}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983643781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" win"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983643835}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983643906}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983643979}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983662778}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983662826}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sand"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983663577}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983663658}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983663770}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983663845}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983664297}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983664364}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983670372}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983670488}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983670556}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983670690}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" win"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983695227}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983695303}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983695342}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" setTimeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983695693}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983705537}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983705582}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clear"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983705667}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983705759}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983723249}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983723403}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" queue"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983723477}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Micro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983723570}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983724349}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983724414}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983724468}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" performance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983724504}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983738797}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983738880}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983738970}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983739075}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983767998}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983768048}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983768098}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983768144}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"process"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983768183}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983768225}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983768334}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ime"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983768401}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983772128}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983772184}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"int"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983772229}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983772435}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983788863}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983788926}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983788977}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"000"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983789070}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983805255}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983805453}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983805534}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983805579}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983806175}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983806289}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983806358}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sand"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983806401}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983819981}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".gl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983820044}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"obal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983820121}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"This"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983820387}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983841087}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sand"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983841205}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983841291}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983841389}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983868024}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983868139}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983868224}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983868296}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983868576}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983868665}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Context"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983868951}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983869033}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983879399}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983879505}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983879599}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983879703}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983898737}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983898837}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983899347}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Context"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983899450}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983899874}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983900171}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983900256}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983900453}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983933884}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" filename"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983934020}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983934316}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983934400}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983965304}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983965414}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983965518}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983965741}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983967107}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983967190}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983967266}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122983967455}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984001239}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" win"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984001360}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984001441}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984001523}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984002078}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984002178}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984002246}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENG"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984002569}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984020615}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984020702}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sand"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984020834}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984021492}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984042672}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984042731}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984042777}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984042838}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984043482}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENG"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984043539}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984043705}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984043771}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984056987}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984057075}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984057371}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984057427}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984097042}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sand"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984097129}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984097181}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984097705}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" win"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984116675}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984116730}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984116908}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984117067}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984117451}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"export"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984117538}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984117705}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984117769}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984153690}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984153796}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984153869}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984155800}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984190439}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984190505}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984190557}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984190591}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984194596}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984194660}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984194711}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984195036}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984203836}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984203888}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984204302}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984204357}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984204675}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984204743}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984204787}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984204848}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984240640}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984240760}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984240849}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984241080}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ..."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984252784}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984252844}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984252915}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Source"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984253285}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984270834}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984270926}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984270995}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" filename"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984271052}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984290849}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984290916}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" })"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984291112}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984291181}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984303041}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"//"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984303169}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Deep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984303222}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984303295}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"one"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984341331}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984341380}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984341437}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" so"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984341494}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984380783}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cannot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984380949}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" share"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984381039}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984381109}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" identity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984391205}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984391282}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"export"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984391331}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984391594}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984424379}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984424490}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984424589}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"over"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984424672}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984441010}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984441065}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984441110}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984441589}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984482592}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ..."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984482764}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"over"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984483043}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984483125}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"export"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984508012}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984508085}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984508144}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984508201}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984533688}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984533899}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984533961}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" names"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984534010}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984553215}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984553296}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984553392}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984553465}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984581564}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984581645}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" names"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984581712}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".filter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984581781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984582437}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984582568}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984582658}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984582733}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" typeof"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984592536}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984592615}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984592671}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984593077}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612026}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612132}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612227}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612307}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612586}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612715}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612787}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984612829}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984626636}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984626700}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984626757}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984626866}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984663738}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984663802}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984663851}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984663905}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" functions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984668487}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984668599}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984668685}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984669072}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984687474}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984687554}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984687623}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984687766}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984688009}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984688104}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"export"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984688178}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984688251}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" validate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984739132}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"History"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984739195}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984739251}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984739309}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984761764}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984761881}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gene"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984761950}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984762086}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984796905}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984797003}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984797527}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984797583}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984818420}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984818469}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984818550}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984818926}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984876599}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984876668}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984876712}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984877241}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" typeof"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984877820}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984877892}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984877967}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984878037}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984891948}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984892027}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984892079}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984892125}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984901544}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984901610}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984901691}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984901732}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984905333}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984905435}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984905527}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984905595}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984908322}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984908387}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984908459}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984908513}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984929629}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Integer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984929710}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984929821}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984929896}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984950116}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984950197}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984950265}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984950304}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984950792}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984950838}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984950879}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984951078}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984963510}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984963686}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984963730}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984963779}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984981601}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984981678}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984981919}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984981968}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984984166}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984984250}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984984316}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122984984361}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985002450}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985002528}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985002591}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985002644}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016356}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016433}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016587}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016640}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016757}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016813}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016859}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985016904}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985036091}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985036170}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985036256}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985036353}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056212}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056305}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056681}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056733}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056779}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056819}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056857}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985056974}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985100942}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985100994}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985101065}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985101232}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985148438}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985148503}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985148561}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985148616}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985149176}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985149279}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985149337}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985149550}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985158550}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985158636}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985158711}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985158780}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985165808}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985165889}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985165949}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985166007}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985166632}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Integer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985166752}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985166973}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985167033}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985174746}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985174822}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985174878}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985174971}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985182419}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985182485}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985182550}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985182991}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985183507}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985183552}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985183594}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985183696}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985199211}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985199283}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985199349}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985199879}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985229770}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985229842}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985229913}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985230351}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985247394}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985247442}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" non"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985247502}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-negative"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985247722}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" integer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985248401}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985248473}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985248536}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985248598}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985267055}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985267112}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985267154}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985267232}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285041}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"raits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285091}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285203}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285277}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285568}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285617}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285701}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985285751}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985310607}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985310659}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" traits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985310702}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985310749}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985328155}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985328227}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985328298}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985328363}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985328857}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985328913}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985328968}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985329037}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985348156}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985348229}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985348279}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985348317}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360029}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360093}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360154}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360264}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"raits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360324}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360382}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360451}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985360500}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985375546}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985375596}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985375636}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985376484}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985431335}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985431405}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985431487}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985431541}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985433087}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985433166}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985433897}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" traits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985433958}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985436537}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985436587}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985436659}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985436711}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985440893}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985440972}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985441040}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985441598}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985447899}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985447952}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985448000}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985448044}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gene"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985448328}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985448454}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985448533}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985448619}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985494867}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985494920}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985495007}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985495049}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985495785}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985495872}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985495929}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985495977}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985504884}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985504965}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985505022}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985505341}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985518218}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985518264}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985518432}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985518495}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985519195}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985519253}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985519309}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" traits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985519370}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985537669}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985537713}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985537766}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985537813}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985554360}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985554412}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985554452}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" missing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985554494}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985555156}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985555195}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985555240}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985555479}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985591663}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985591764}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985591809}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985591936}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985592137}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985592201}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985592256}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985592409}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985610900}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985611081}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985611127}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985611169}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985625906}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985625972}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985626041}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985626104}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985626464}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985626509}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985626548}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985626590}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985641005}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985641340}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985641388}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985641565}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985654944}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985654987}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985655035}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985655079}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985655153}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985655319}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985655407}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985655493}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" traits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985674002}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985674128}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985674233}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985674338}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985695421}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985695519}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985695605}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985695680}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985712508}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985712629}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985712751}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985712847}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985713269}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985713418}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985713693}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985713771}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" finite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985749062}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985749160}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985749248}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985749334}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985757975}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985758308}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985758409}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985758603}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985759080}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985759166}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985759246}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985759322}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985769449}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985769543}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985769616}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985769787}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985785367}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985785464}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985785548}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985785628}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985786071}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985786157}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985786240}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" negative"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985786327}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985802310}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985802408}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985802488}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985806842}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985827656}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985827751}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985827834}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985827919}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985837293}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985837387}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985837485}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985837664}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985848774}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985848864}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985848942}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985849023}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985850357}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985850453}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985850528}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985850734}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985869239}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985869362}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985869455}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985869537}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985884912}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985884998}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985885071}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985885142}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985920397}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985920474}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985921370}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985921457}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985923079}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985923152}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985923215}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985923274}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985949488}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985949546}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985949574}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985949618}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985950382}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985950457}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985950515}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985950544}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985968524}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985968600}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985968673}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985968736}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985985047}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985985131}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985985196}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985985261}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985986092}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985986176}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985986267}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122985986373}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986001547}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986001755}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986001839}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986002165}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986019991}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986020080}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986020164}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986020231}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986035292}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986035342}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" //"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986035416}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tolerate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986035486}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tiny"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986088584}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" float"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986088659}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" drift"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986088742}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" only"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986088792}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986151051}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986151105}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986151565}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" slack"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986151638}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986169330}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986169385}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986169505}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986169554}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986169907}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986170085}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986170143}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986170246}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986204352}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986204437}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986204495}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986204538}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986210304}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986210646}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986210689}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986210759}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986222094}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986222150}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986222198}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986222952}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986239519}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986239806}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986239897}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986239982}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986240387}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986240460}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986240522}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986240576}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986250942}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986250984}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986251073}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986251528}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" slack"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986272421}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986272491}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986272548}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986272684}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986273569}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986273614}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986273667}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986273719}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" slack"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986291383}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986291464}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986291557}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"         "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986291606}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986308181}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986308233}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986308279}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986308438}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986309043}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986309088}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986309144}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986309194}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986334182}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986334229}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986334312}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" outside"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986334377}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986338423}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986338485}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986338538}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986338582}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986361745}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986361793}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986361840}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986361939}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986382782}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986382855}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986383010}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986383078}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986383683}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986383733}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986383781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986383856}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986399059}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986399356}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986399418}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986399781}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986420720}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986420776}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986420844}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986420908}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986421050}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986421099}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986421143}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986421501}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986452018}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Integer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986452064}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986452734}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986452795}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986452858}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986452930}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986452988}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986453034}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986468887}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986468932}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986469015}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986469081}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986487590}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986487661}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986487711}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986487865}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986488160}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986488238}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986488359}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986488405}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986503427}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986503483}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986503615}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mutations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986503666}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986519438}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986519484}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986519832}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986519877}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986537557}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986537637}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986537706}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" non"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986537770}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-negative"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986538783}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" integer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986538827}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986538873}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986538913}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587407}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587490}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587555}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587610}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587651}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587738}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587809}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986587947}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986588000}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986588056}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986588137}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iversity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986588205}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986603833}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986603898}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986604052}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986604121}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iversity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986609504}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986609547}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986609588}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986610553}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986610598}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986610651}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986610701}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986610729}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986624603}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986624662}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986625438}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986625491}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986648631}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" diversity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986648685}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986649200}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986649290}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986649392}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iversity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986649460}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986649526}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986649602}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" finite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986671566}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986671631}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986671680}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986671821}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986672433}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986672497}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986672626}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986672705}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986693323}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986693379}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986693841}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986693900}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986705084}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986705175}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986705250}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986705374}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986720677}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986720736}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986720780}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986720848}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986745063}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ague"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986745317}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986745381}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986745437}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wild"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986755026}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fire"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986755100}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986755158}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"includes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986755275}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986755868}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986755923}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986756039}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986756085}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986768001}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986768062}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986768143}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986768203}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986788324}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986788374}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986788423}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986788477}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986798491}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986798553}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986798938}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986798983}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986800420}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986800470}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986800511}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986800551}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986816630}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"export"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986816925}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986816972}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" validate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986817022}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Snapshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986849729}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986849799}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986849865}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986849912}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894108}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894315}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894377}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894425}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894466}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894530}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894572}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986894624}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986903980}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986904054}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986904111}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986904321}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986912895}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" typeof"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986912958}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986913000}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986913051}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986953971}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986954024}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986954071}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986954118}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986954160}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986954202}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986954276}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986954352}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986968587}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986968644}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" an"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986969356}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986969410}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986969573}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986969643}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986969728}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986969834}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986983089}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986983166}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986983920}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122986983999}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987055909}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987055987}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987056050}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987056092}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987087789}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987087861}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987088008}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987088812}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987089187}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987089273}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987089355}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987089403}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987097801}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987097848}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987097919}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987097993}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098061}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suspicious"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098130}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098169}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" empty"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098250}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098334}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098403}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098623}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987098688}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987101993}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".includes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987102066}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987102211}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987102286}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987130047}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" throw"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987130123}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987130340}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987130413}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987147791}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"where"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987147844}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987148065}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snapshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987148118}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" leaks"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987196120}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" functions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987196171}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987196246}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987196312}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" plain"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209092}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209147}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209213}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209272}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209381}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209421}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209688}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987209736}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987248260}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987248392}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987248440}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987248541}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987265850}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987265893}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987266620}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987266672}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987317031}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987317098}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987317159}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987317223}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987340183}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987340231}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987340290}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987340353}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987345541}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987345620}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987345859}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987345916}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352021}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352098}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352136}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352198}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352775}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352825}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352865}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987352906}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987357268}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987357318}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987357440}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987357492}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987370952}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987371005}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987371044}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987371134}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987371737}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987371822}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987371889}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987371933}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987377725}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987377774}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987378973}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987379032}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987391799}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987391845}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987391889}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987391933}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987392519}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987392565}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987392613}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987392708}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987419581}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987419705}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987419794}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987419898}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987431609}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987431821}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987431868}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1275,"ts_us":1793122987432027}}

data: {"id":"f74c1b5ed1bac4637313a72c8c578bd4","object":"chat.completion.chunk","created":1793122965,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":41889,"completion_tokens":3482,"total_tokens":45371,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":41600,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":2376,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1275,"ts_us":1793122987500015}}

data: [DONE]

