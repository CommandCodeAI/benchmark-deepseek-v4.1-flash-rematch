data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428002119}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Excellent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428037811}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": canvas backing sizes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428037889}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now exactly match"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428038866}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS at d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428125466}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pr 1; chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428125611}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright fixed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428125728}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428126722}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428176625}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both sizes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428176747}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428176895}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428176967}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot to ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428257424}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual quality"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428257592}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (matrix taller"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428257761}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428257949}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428382240}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"364 vs 356"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428382427}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428382727}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_o00rgr8093o82tk7yy3q1era","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428382809}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428383112}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428383183}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428383240}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428383784}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428401074}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428401268}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428401556}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428401636}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428401978}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428402286}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428403178}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428403238}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428415173}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428415265}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428415430}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428415473}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428434541}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428434692}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428434811}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428434894}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428449879}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428449930}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428450021}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428450188}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428468716}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428468834}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428469067}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428469600}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428469708}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428469816}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428469903}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428470055}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428485656}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428485702}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428485830}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428486681}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428502765}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428502848}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428502992}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428503302}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428504032}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428504190}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428504305}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428504422}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428518573}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428518666}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428518804}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428518904}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428538623}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428538794}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428538867}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428539016}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428539490}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428539588}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428539854}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428539925}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428558535}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428558644}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428558908}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428558980}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43132,"ts_us":1793126428633288}}

data: {"id":"e7d20b624d11fbe59d439c0bbca1ea4c","object":"chat.completion.chunk","created":1793126427,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":334312,"completion_tokens":134,"total_tokens":334446,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":333824,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":44,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":43132,"ts_us":1793126428633447}}

data: [DONE]

