data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980185801}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980215602}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chartwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980215700}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980216658}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot is actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980297476}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from 12 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980297518}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980297557}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good, though at this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980297594}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980384502}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980384721}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980384770}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980386430}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980454330}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finished"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980454389}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980454419}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read output. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980456303}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need to get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980528672}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the live page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980528747}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot at proper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980528790}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" viewport. Let me first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980528831}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read seed search result.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980585528}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note: chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980585578}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright's record at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980585618}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440x900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980585655}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits (content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980651476}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ends at ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980651524}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"862 with margins"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980651583}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Good. The record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980651634}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980725576}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980725631}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Closed Ecology"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980725693}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" but population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980727731}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980784770}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980784843}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980784886}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980784947}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb/p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980853357}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"red due to grouping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980853426}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980853606}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lacks catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980853682}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" types"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980926294}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variety"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980926365}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980926422}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980926502}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980989415}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12 gens but "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980989476}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 gens will show more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980989527}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me check seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123980989651}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" search."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981069128}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_r5ww9g0fm2ozilcy900nsdk7","type":"function","function":{"name":"job_output"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981069197}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981069238}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981069278}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"job"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981289533}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981289633}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981289890}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981289984}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981290223}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981290307}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981290546}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"528"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981290625}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981291007}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"833"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981291084}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981291160}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981291261}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"846"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981291662}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"91"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981291777}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981291872}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5595,"ts_us":1793123981292084}}

data: {"id":"10a26814e5f2f313ad15432bc54e40c2","object":"chat.completion.chunk","created":1793123980,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":225920,"completion_tokens":173,"total_tokens":226093,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":223360,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":126,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":5595,"ts_us":1793123981292340}}

data: [DONE]

