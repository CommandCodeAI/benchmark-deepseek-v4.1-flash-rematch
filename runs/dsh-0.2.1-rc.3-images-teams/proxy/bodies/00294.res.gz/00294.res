data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124815891134}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124815950952}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"window.__VIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124815951001}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARIUM__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124815951068}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` exists"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816001389}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816001459}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" conclude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816001499}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816001555}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816092181}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" function? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816092228}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me check boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816092263}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816092303}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exposure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816158000}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816158064}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" __"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816158103}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIVARIUM__. Search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816158217}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231332}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_6falqvxyjmnet9lt1lszwdm5","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231397}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231516}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231567}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231615}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231658}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231698}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231736}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231772}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816231819}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232244}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232285}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232375}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232437}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232476}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232527}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232570}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232614}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232662}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232708}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232753}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232831}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232940}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816232997}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816233052}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816233107}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816233150}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816233192}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816233943}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816234032}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816234176}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816234216}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816239624}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816239675}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816239721}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816239755}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816260953}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816261146}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816261189}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816261242}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816276750}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816276822}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816276862}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816276919}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816311212}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816311264}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816311299}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816311415}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816329492}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816329545}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" global"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816329586}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" API"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816329634}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816395541}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41535,"ts_us":1793124816395598}}

data: {"id":"47ff9348071af11ea537fca68e4a60f8","object":"chat.completion.chunk","created":1793124815,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":222209,"completion_tokens":119,"total_tokens":222328,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":218880,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":31,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":41535,"ts_us":1793124816395672}}

data: [DONE]

