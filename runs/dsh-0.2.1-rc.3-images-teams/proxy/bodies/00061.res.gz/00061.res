data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088383215}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088508938}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" landed. Let me inspect key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088509012}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parts: GENE_META"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088509052}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", SPECIES, history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088574834}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entries"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088574891}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", events,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088575032}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088576710}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less, getStats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088639831}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Grep."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088639909}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8xjg2uxuqmy1qieeu0spkbit","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088639985}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640081}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640161}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640271}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640337}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640405}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640519}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640701}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640762}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088640818}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088651707}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088651777}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088651885}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088651954}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088652036}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ETA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088652082}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088652122}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SPEC"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088652161}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088658976}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088659033}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088659083}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088659139}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088673238}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088673295}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"CAT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088673340}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AC"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088673409}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"L"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088693617}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"YS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088693722}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"MS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088693812}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088693878}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088713697}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088713752}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088713808}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088713844}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088726966}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088727046}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088727097}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088727147}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"YS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088778091}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088778150}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088778209}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088778251}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088799713}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088799779}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088799836}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088799899}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830099}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830145}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830240}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830318}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830685}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830837}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830893}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iversity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088830963}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088851648}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088851735}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088851798}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088851879}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088886290}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088886334}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088886385}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088886431}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088896545}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088896657}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088896776}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088896883}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088924756}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088924815}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088924858}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088927233}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088931212}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088931295}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088931358}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" metadata"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088931960}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088977581}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088977633}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" structures"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088977684}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123088977742}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1660,"ts_us":1793123089043378}}

data: {"id":"16a7f755bcf6169ccc00f6045613da77","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":61963,"completion_tokens":146,"total_tokens":62109,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":60288,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":32,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1660,"ts_us":1793123089043458}}

data: [DONE]

