data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677267325}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3qsdy7247c02ydb8wv9zoo1k","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677267443}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677268817}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677288967}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677289143}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677289400}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677289644}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677305782}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677305955}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677306567}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677306616}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677322334}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677323121}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677323214}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677323509}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677343310}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677343525}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677343650}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677345917}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677361528}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677361617}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677361685}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677362239}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677362398}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677362928}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677362986}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677364069}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677382776}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677382850}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677383318}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677383369}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677400868}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677400977}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677401032}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677401200}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677401241}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677401387}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677401428}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677403360}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677421493}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677421656}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677421712}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677422925}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677431752}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677431881}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677432100}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677432879}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677433193}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677433250}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677433359}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677433401}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677451216}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677451544}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677451600}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677451663}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677490811}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677490949}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"01"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677491001}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677491852}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677536320}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1713,"ts_us":1793123677536503}}

data: {"id":"03d8a1f15fb107c1be78cef5348ae613","object":"chat.completion.chunk","created":1793123677,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":181525,"completion_tokens":88,"total_tokens":181613,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":181120,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1713,"ts_us":1793123677536588}}

data: [DONE]

