data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510448909}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Oops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510549536}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the huge output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510549595}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was because `console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510549636}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".log` printed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510609015}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the entire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510609100}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world including"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510609165}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510609304}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Grid. But I got"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510723076}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the key info at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510723180}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the end:\n\n- setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510723255}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510723336}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"interval', 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510809380}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") sets `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510809452}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world.config.interval = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510809491}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3` but leaves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510809537}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `nextEventGen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510890979}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 27` (from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510891033}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prior"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510891095}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" schedule)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510891149}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510965470}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test ran"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510965545}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24 more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510965614}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens: "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123510965667}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24→48;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511019284}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nextEventGen 27"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511019358}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should fire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511019415}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 27! But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511019459}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output says \"after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511080631}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": gen 24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511080680}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events 12,24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511080716}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nextEventGen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511080755}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"27\" — wait after run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511129956}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511130090}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",24), gen is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511130166}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still 24?! Because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511130272}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless stopped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511217217}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511217259}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511217334}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Ah"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511217421}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — `world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511262328}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511262421}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inished`? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511262506}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world config generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511262571}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe 48 default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511316275}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Hmm after first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511316323}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511316358}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",24) gen=24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511316393}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", events "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511400207}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12,24. Then run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511400267}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(w,24)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511400325}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gave gen still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511400360}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24, no advancement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511445696}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511445766}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Possibly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511445823}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world.f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511445971}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inished became true because..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511626766}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config.g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511626876}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enerations? I passed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511626961}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511627118}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":48 in `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511682811}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"make({"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511682889}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed:197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511682942}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7, interval:12,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511682992}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations:48})`. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511746534}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe createWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511746607}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" placed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511746668}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511746724}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` in config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511824158}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511824303}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first run "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511824391}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511824458}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" < 48 not finished"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511876704}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm.\n\nWait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511876787}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511876852}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511876910}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" truncated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511939710}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" included"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511939790}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511939858}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dump"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511939928}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511991466}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511991550}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run: \"...\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511991623}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123511991689}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512048223}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512048291}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512048346}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".interval 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512048419}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nextEventGen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512135184}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 27`; `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512135236}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"after: gen 24 events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512135292}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12,24`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512135328}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So second"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512207265}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless did nothing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512207329}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why? Maybe `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512207391}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runHeadless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512207422}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"orld, gens)` semantics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512280830}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": runs until `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512280875}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512280989}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generation >= gens`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512281071}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512338977}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": in earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512339039}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512339099}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512339165}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".runHeadless(w, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512435327}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100)` with default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512435378}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations 40 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512435433}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reached 40 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512435490}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"finished). Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512516083}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512516148}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations=100 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512516214}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reached 100. What does"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512516262}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless do exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512565560}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Maybe signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512565652}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `runHeadless(world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512565711}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", gens)` sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512565764}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `world.config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512625878}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generations = gens`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512625943}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?? No...\n\nLook at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512626027}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512626075}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512698678}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World({seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512698744}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512698825}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7, generations:60});"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512698878}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless(w5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512761688}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",60) → reached "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512761748}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60? We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512761798}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" saw events 19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512761837}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512845700}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512845748}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 = gens 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512845788}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..57 ✓ so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512845831}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reached 60. So run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512928323}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(w, gens)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512928378}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" advances *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512928431}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"to* generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123512928525}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `gens` ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513017174}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"absolute target), not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513017230}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513017290}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" delta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513017335}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513077765}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513077844}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- runHeadless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513077993}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(w,24) first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513078053}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513140384}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24.\n- runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513140457}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less(w,24) again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513140505}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → nothing ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513140559}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"already at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513228963}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24).\nSo `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513229007}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runHeadless(world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513229062}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", gens)` = run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513229123}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until generation >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513286630}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens. Not \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513286740}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513286951}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513287139}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513355230}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief says `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513355323}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runHeadless(world,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513355393}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens) -> world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513355452}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513420375}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" // fast-forward`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513420463}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — ambiguous but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513420531}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513420604}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"run to gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513482529}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". My tests calling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513482598}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513482660}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 24) twice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513482708}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are wrong."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513556158}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513556212}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": use target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513556295}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation absolute"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513556372}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": e.g., runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513648110}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less(wI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513648182}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 24) then run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513648244}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(wI, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513648306}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"48).\n\nSimilarly B11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513710707}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513710775}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"E.runHeadless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513710830}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 12)\" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513710894}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513785161}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513785211}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 → target "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513785258}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12 → advances"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513785329}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 more only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513849362}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513849436}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expiry test ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513849492}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"drought duration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513849561}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 → over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513906195}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by 12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513906250}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n\nB12 fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513906301}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": after first run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513906371}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 24, second"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513984462}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513984598}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be runHeadless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513984695}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(wI, 48"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123513984781}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n\nAlso my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514051522}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514051577}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runs` helper: run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514051628}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(w, gens)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514051685}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514119724}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514119787}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514119836}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 → advances"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514119884}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514182712}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine.\n\nB13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514182764}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514182807}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(w,120)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514182849}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target 120 from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514269563}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514269624}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then runHeadless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514269668}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",10) after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514269704}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 120 does"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514340342}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nothing! Fix:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514340419}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless(w,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514340487}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 130).\n\nB"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514340569}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6: from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514394139}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514394184}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 fine.\nB8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514394229}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514394315}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 → 100 fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514452941}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514453002}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benchmark separate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514453079}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nB15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514453179}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": reset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514528132}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then runHeadless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514528176}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(w2,5) from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514528224}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 fine.\nB"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514528270}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2: fine.\nB"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514621699}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5: run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514621749}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation increments.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514621788}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514621823}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514700460}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval leaves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514700548}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nextEvent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514700631}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Gen unchanged ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514700696}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514761866}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cheduled at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514761941}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"27 based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514762001}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on interval 12?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514762040}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514840722}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 + 12 = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514840774}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"36? Hmm next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514840811}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EventGen 27:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514840860}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514892733}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514892801}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output after first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514892854}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run: nextEvent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514892917}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Gen was maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514946305}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 36? Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514946364}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514946418}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123514946459}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515006265}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515006369}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" source shown for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515006443}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515006515}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param at bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515084780}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is partial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515084851}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; it says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515084938}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515085008}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 'cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515133073}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515133161}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515133235}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reschedules."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515133306}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" For interval, likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515303249}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515303308}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" further: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515303385}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515303456}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (key === 'gener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515366701}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515366769}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` truncated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515366816}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515366953}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515452014}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"chedules nextEventGen = generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515452087}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + interval... "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515452139}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24+3 = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515455199}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"27 ✓!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515572359}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515572444}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515572544}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param DOES"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515572617}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reschedule →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515635018}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515635071}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 27. Then my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515635172}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515635225}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515695139}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nothing. So engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515695211}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely fine. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515695267}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": B12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515695394}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515766908}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515766971}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515767024}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSo engine is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515767074}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515826783}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good shape except contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515826862}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ali"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515826937}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ases missing ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515828767}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"stepGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515880250}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", getSnapshot, world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515880320}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".activeEvents). Also check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515881032}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" whether"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515881100}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515940460}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless` semantics documented"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515940537}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515940596}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely uses run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123515940651}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick loops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516053548}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516053596}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless, so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516053646}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no issue.\n\nLet me fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516053691}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B12/B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516109177}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516109223}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check B15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516109265}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" message"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516110857}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516176122}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516176200}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": B8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516176253}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.9s for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516176302}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 gens = 13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516233445}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"x realtime; brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516233505}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516233651}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says faster than real time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516233749}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓. Task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516319211}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matrix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516319280}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516319388}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516319449}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens under ~1s\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516403803}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516403860}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" achievable with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516403916}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current engine perf"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516403966}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; note as MIN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516474710}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OR risk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516474777}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (engine performance:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516474842}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516474987}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"26"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516538110}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens/s; fine for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516538198}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" turn-based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516538270}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516538404}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516606620}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516606698}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516606911}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516606986}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516698184}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516698243}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s at 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516698371}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516698459}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516746805}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compute: playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516746890}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516747109}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"× presumably"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516747243}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240 ticks/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516833161}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 8 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516833230}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516833313}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516833427}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516915288}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick cost ~ "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516915340}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516915410}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9s/100/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516915477}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 = 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516972846}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".3ms/tick →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516972953}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516973030}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123516973097}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30 ticks = 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517053958}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/s * 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517054025}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3ms = 31"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517054078}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% CPU."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517054145}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine. Actually 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517106749}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517106801}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s baseline at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517106854}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517106897}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0× → 30 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517200745}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s per 1×;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517200803}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8× ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517200850}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240 ticks/s ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517200881}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517259002}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3ms/tick →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517259051}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 312ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517259101}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s = 31%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517259154}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517331639}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one core, plus rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517331688}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Acceptable but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517331732}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517331812}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517390020}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517390079}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60fps?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517390130}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rAF render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517390178}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 60f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517445539}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ps; tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517445597}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" processing at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517445638}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240/s done"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517445702}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in chunks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517647289}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517647342}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517647390}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517647425}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/frame = ~5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517698586}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2ms)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517698662}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517698729}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be tight but OK"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517698808}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWait engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517753457}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517753508}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measured"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517753553}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517753735}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s/100 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517810358}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 39ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517810423}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517810468}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517810521}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".3ms/tick ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517863557}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 ticks)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517863606}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517863640}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"× ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517863684}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240 ticks/s → "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517922079}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"312ms CPU"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517922160}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s. Plus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517922233}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendering maybe "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517922280}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5-8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517972447}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms/frame at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517972496}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60fps = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517972543}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123517973331}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s. Total ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518029731}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"70% CPU"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518029817}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Risky for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518029899}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60fps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518029989}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518089887}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518089977}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will tell.\n\nFix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518090038}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518090137}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518204463}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518204535}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518204580}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Har","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518204636}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ness found","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518255796}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" the","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518255844}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" key","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518255926}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" detail: `runHead","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518256006}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"less(world, gens","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313207}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":")` targets an absolute","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313281}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" generation. Fixing those","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313333}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" tests:","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313399}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_tzjxth066es7o3kafqp38a1z","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313468}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313553}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313744}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313817}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518313956}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314027}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314165}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314239}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314355}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314445}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314499}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314610}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314696}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314843}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518314911}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315046}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315115}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315219}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315283}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315367}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315442}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315619}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315766}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518315933}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518316009}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518316186}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518316301}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518316448}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518316506}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518316648}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518316747}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518317006}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518317075}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518317223}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518317401}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518317479}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518317653}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518317860}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318065}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318137}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318207}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318344}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318414}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318473}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318530}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318587}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318645}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318710}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318780}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318907}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518318998}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319075}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319284}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319347}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319450}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319560}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319623}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319682}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319752}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518319907}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320042}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320127}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320177}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320310}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320383}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320521}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320613}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320758}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518320869}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518321022}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518321131}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518321269}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518338113}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518338182}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518338410}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518338561}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518360818}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518360909}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" second"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518360984}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518361064}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518410894}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" call"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518410965}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518411024}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" an"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518411084}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" absolute"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518490379}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518490479}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518490553}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518490605}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518491184}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518491260}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518491320}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518491420}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518504915}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518504998}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518505068}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Param"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518505147}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518506285}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518506386}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518506485}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518506625}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518507539}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518507748}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518507833}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518507983}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518509217}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518509308}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518509502}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518509559}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518510303}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518510360}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518510405}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518510523}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518510763}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518510890}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518510983}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518511097}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518511195}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518511309}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518511437}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518511507}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518524590}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518524711}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Param"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518524798}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518524868}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518543972}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518544051}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518544114}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518544239}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518544432}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518544509}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518544656}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518544803}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518558257}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518558315}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518558370}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518558426}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581113}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581199}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581259}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581391}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581440}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"48"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581500}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581625}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" //"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518581788}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518618518}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518618596}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518618650}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" targets"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518618733}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" an"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518656794}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" absolute"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518656876}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518656938}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518657099}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518658905}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518658952}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518659672}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518659712}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518675653}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" post"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518675739}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518675787}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inction"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518675819}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518684613}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" must"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518684698}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518684781}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518684879}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" later"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518706361}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518706431}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518706492}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518706549}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518724477}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518724572}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518724710}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518724762}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"         "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518724891}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518724935}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518725137}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518725221}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518745056}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518745111}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518745233}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518745319}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518768252}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518768344}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"         "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518768399}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518768460}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518773623}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518773686}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518773743}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518773805}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518792791}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518792843}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518792895}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518792943}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518815006}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518815073}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518815119}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518815198}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518816061}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" post"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518816149}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518816231}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inction"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518816415}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518873898}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518873972}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518874039}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518874102}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518885803}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"         "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518885856}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518885906}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518885958}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518886817}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518886878}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518886944}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518887012}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518923389}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"130"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518923451}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518923501}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"         "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518923543}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518928651}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518928716}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518928773}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Number"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518928842}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518929246}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518929312}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518929364}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518929766}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518931340}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518931408}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518931459}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518931527}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518946646}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518946712}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" post"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518946757}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518946796}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inction"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518947306}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518947422}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518947494}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518947717}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518957747}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518957845}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518957922}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518958046}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518958392}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" accuracy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518958446}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518958564}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518958621}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518969179}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518969274}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518969370}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518969433}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518990145}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518990219}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518990270}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123518990351}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519010763}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519010833}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519010906}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519011011}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519011234}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519011290}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519011338}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519011385}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519031007}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Equal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519031069}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519031336}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519031416}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519051312}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519051376}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519051448}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519051519}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519064959}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519065066}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519065149}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519065227}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519065879}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reset"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519065937}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" failed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519065983}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519066024}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519076993}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519077075}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519077139}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reset"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519077206}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ok"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519094425}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519094498}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" params"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519094547}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" retained"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519094594}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519112598}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519112653}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519112704}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entries"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519112753}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519129432}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519129482}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519129553}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519129629}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519130723}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519130802}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519130848}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519130890}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519156714}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519156794}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519156854}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519156917}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519203502}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519203579}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"History"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519203643}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519203713}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519204108}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519204183}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519204319}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519204381}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519223030}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519223110}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519223173}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519223240}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519224800}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519224904}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519224983}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519225056}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519225684}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519225731}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519225773}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519225811}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519253803}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519253875}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519253935}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Equal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519253998}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519265030}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519265111}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519265201}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519265308}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519265888}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519265960}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519266126}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519266213}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519282909}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519283007}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519283112}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reset"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519283177}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" failed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305205}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305290}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305356}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305423}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305566}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reset"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305654}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ok"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305872}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519305970}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" params"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519318607}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" retained"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519318664}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519318732}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519318847}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519373099}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entries"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519373159}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519373206}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519373249}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"History"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519375172}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519375232}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519375380}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519375433}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519384742}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519384812}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519384905}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519384972}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519388707}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519388849}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519388953}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519389064}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519389574}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519389621}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519389711}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519389789}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ched"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519393307}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519393361}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519393401}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519393463}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519420914}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519421008}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519421098}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519421191}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519422388}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519422443}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519422492}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519422585}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519430947}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519431006}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519431055}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519431131}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519447348}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519447401}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519447487}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519447552}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"//"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519469112}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" focused"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519469174}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verification"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519469226}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519469303}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" the"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519515023}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" two"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519515072}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519515162}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" checks"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519515250}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519515924}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519515969}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519516042}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519516093}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519534527}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519534581}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519534650}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519534706}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519554651}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" './"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519554699}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519554740}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519554827}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519555416}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519555511}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519555604}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519555695}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519566487}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519566551}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519566593}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519566644}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519585230}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519585318}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519585386}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519585433}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519602395}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519602498}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519602582}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519602661}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519624059}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519624172}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519624260}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519624351}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519624798}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519624896}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519624989}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519625080}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519660462}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519660560}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519660640}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519660724}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519687643}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519687745}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519687828}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519687905}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519688216}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519688304}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519688434}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519688521}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519716093}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519716193}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519716271}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519716444}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738197}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738261}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738333}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738401}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"48"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738649}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738699}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738927}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519738996}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519752243}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519752316}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519752394}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519752508}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519764817}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519764892}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519764999}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519765072}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519765668}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" before"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519765729}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519765778}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519765957}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519787633}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519787687}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519787731}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519787779}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519807667}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519807758}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519807812}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Param"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519807888}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519808291}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519808362}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519808421}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519808595}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519824518}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519824578}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519824641}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519824698}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519842686}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519842736}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519842809}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519842882}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519843794}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519843857}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519843991}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519844044}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519859584}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"48"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519859634}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519859688}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519859731}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519881108}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519881220}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519881315}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-change"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519881368}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519895380}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519895432}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519895467}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519895515}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931056}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931115}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931169}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931215}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" before"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931330}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931442}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931552}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519931659}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519946386}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519946440}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519946551}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519946597}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519959966}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519960045}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519960112}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519960156}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519977423}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519977470}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519977533}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519977607}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519978160}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519978238}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519978304}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123519978358}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520016373}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520016472}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520016526}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520016559}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520033025}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520033106}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520033174}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520033224}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520050011}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520050060}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520050108}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" delta"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520050155}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assumptions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520146421}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520146485}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520146527}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520146618}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2077,"ts_us":1793123520182349}}

data: {"id":"30df65d9999b5eb7927e51c90e7fa7e8","object":"chat.completion.chunk","created":1793123510,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":158282,"completion_tokens":1968,"total_tokens":160250,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":129664,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1363,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2077,"ts_us":1793123520182469}}

data: [DONE]

