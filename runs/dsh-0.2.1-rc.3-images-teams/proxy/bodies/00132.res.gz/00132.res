data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609310900}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_o1ii6jbkiym4qovafv6dkm3w","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361212}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361329}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361412}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361509}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361556}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361667}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361723}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361810}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609361899}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609362055}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609362151}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609385886}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609385940}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609386095}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609389083}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609395017}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609395067}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609395203}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609395242}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609404790}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609405294}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609405538}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609405618}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609405720}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609405824}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609405952}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609406080}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609426948}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609426997}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609427054}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609427176}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609446310}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609446383}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609446434}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609446517}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609447068}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609447158}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609447241}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609447287}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609464703}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609464750}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609464801}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609464853}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609481370}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609481420}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609481468}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609481571}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609482081}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609482197}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609482343}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609482386}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609495017}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609495063}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609495265}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609495334}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609519120}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609519163}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609519203}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609519249}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2699,"ts_us":1793123609582732}}

data: {"id":"771d21432b9821700efba6d8a2edde56","object":"chat.completion.chunk","created":1793123609,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":153723,"completion_tokens":88,"total_tokens":153811,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":151936,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2699,"ts_us":1793123609582894}}

data: [DONE]

