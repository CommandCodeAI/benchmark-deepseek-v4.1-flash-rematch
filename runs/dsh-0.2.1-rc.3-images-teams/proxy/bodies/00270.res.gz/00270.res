data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124589996016}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590049504}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DEFA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590049563}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ULTS is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590049595}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `const`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590121313}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object, but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590121367}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590121428}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed` changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590123422}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" between node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590174475}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs (197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590174526}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7→"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590174596}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590174712}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — something"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590256787}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutates it at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590256832}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" module init"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590256883}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590257962}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590299594}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590299642}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at engine lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590299722}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 74"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590299789}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-95 and around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590404046}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590404117}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590404174}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"260. Hmm `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590404228}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"DEFAULTS.se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590455996}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed` in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590456056}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" normalize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590456105}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Seed fall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590456148}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back. But our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590525918}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node printed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590525967}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DEFAULTS.seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590526019}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 in one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590526069}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590575214}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590575281}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 in earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590575322}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs? Earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590575379}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590628826}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" asserted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590628875}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DEFAULTS.seed==="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590628933}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1977 and passed at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590628976}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590775105}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":56. Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590775149}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590775190}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So something in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590775253}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590828377}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590828453}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process mutated it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590828502}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before print"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590829594}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590907381}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parity2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590907430}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590907469}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590908801}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loaded engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590989434}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then created"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590989479}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590989516}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"... then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124590989555}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" printed N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591059554}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".DEFAULTS after browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591059636}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test. `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591059691}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"createWorld({"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591062221}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed:1977})`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591126687}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shouldn't mutate D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591126737}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS. Hmm wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591126786}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" N.D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591126902}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed printed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591204423}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901 — but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591204491}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loadEngine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591204535}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FromFile at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591204582}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591265523}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Did `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591265593}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"loadEngine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591265721}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FromFile` maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591265767}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591323850}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591323904}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s init"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591323962}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591324009}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed = random"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591385313}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591385370}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591385415}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Math.random in engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591385471}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591444246}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Unless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591444296}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591444338}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `window.__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591444383}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591505216}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARIUM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591505277}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_SEED`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591505312}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? no window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591505718}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591563449}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591563503}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"box: window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591563560}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"={} ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591563613}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hmm.\n\nOH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591618114}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" WAIT. My load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591618169}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EngineSource"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591618205}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591618240}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"box sets `window = {}"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591679477}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` and `global"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591679537}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"This = sand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591679592}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"box`. Engine II"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591679656}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FE `(function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591736842}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(root){...})("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591736949}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"typeof window !== 'undefined'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591737057}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ? window : globalThis)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591737100}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`. In node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591786310}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591786359}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591786404}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591786446}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` exists → root"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591865127}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=win. Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591865176}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWhere would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591865211}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DEFAULTS.se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124591865251}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed become 1901"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592030427}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592030499}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine's `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592030562}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"normal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592030622}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"izeSeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592081699}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` mutates? line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592081846}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 251"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592081929}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592082016}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (!Number"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592135063}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".isFinite(s)) s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592135188}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = DEFAULTS.seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592135266}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592135331}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n\nLook:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592188802}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe engine has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592188885}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592188948}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592189016}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" init"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592241615}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592241699}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `if (D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592241765}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed ==="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592241871}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977) D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592294107}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed = ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592294171}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592294226}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s grep surrounding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592294276}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592353434}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS definition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592353479}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and any"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592353528}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592353570}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420257}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420333}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8v9oq9zesqxj9wk43c2x6l1u","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420411}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420478}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420556}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420623}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420681}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420778}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420836}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592420903}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592421192}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592421259}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592421328}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592421414}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592421478}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592421542}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592436235}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592436291}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592436347}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592436406}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592438574}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592438657}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592438763}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592438872}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592463843}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592463919}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592463975}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592464118}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592465178}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592465242}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592465400}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592465486}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592482812}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592482893}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592482959}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592483018}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592577446}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592577640}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592577839}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592577925}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592651418}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592651476}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592651588}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592651683}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592652594}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592652655}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592652718}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592652776}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592659270}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592659320}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592659378}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592660168}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592663181}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592663227}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592663267}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592663307}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592664376}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592664423}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EFA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592664466}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ULTS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592664531}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592665108}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592665163}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592665204}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592665244}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592665942}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592665987}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592666028}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592666069}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592666866}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592666913}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592666965}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592667013}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674459}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674511}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"74"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674571}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674650}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674791}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674836}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674906}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592674989}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592693088}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592693130}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592693175}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592693950}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592732579}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592732633}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592732676}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seeds"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592733873}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592736352}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592736392}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592736444}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592736492}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592754564}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592754626}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592754678}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592754719}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592777113}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592777160}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592777243}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592777331}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592795988}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592796072}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592796130}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592796171}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592840090}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592840162}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592840225}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592840351}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592867630}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592867713}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592867777}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Trace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592867850}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592871421}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EFA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592871506}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ULTS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592871569}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592871618}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mutation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592940205}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592940286}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10257,"ts_us":1793124592940338}}

data: {"id":"46d4f7b9b2fb83ef961ecaace4b39405","object":"chat.completion.chunk","created":1793124589,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":252665,"completion_tokens":562,"total_tokens":253227,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":251520,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":410,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10257,"ts_us":1793124592946597}}

data: [DONE]

