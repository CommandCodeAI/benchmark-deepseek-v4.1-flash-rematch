data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592262481}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592307374}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592307428}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592307547}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901: 534/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592376115}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"144/41,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592376190}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592376256}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". View."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592376587}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yq8n3i3hbzj1h6wr59qekpkm","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592411555}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592411606}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592411651}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592412247}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592452510}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592452805}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592452849}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592452887}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592453696}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592453807}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592453911}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592453981}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592461720}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592461873}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592461946}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592462369}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592478825}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592478999}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592479074}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592480100}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592498645}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592498693}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592498739}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592499032}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592499956}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592500048}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592500086}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592500490}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592509676}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592509837}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592509888}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592510188}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592528366}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592528509}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592528761}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592528808}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592544343}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592544433}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592544477}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592544729}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592544967}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592545154}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592545199}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592545426}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592556530}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592556595}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592556648}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592556745}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592576987}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592577151}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592577243}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592577304}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592577678}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592577722}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592577765}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592578175}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592657114}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592657210}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592657505}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27171,"ts_us":1793124592657572}}

data: {"id":"57a6fe6cdc3cd90ed15a21a0efee02d0","object":"chat.completion.chunk","created":1793124592,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":264084,"completion_tokens":108,"total_tokens":264192,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":263552,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":20,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":27171,"ts_us":1793124592689959}}

data: [DONE]

