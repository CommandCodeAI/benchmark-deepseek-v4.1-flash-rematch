data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498423486}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_4yd0cx2fk7k8bieokp3fpxdt","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498456582}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498456674}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498456737}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498473167}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498473226}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498473270}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498473310}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498487316}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498487402}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498487472}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498488247}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498503886}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498503944}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498504284}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498504378}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498522131}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498522217}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498523469}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498523527}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498537867}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498537920}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498537988}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498538063}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498556794}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498556863}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498556914}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498557041}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498568789}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498568863}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498568907}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498570257}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498570313}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498570357}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498570416}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498571098}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498590783}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498590842}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498590891}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498591441}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498608577}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498608628}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498608672}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498610213}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498621245}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498621295}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498621356}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498621423}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498621600}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498621696}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498621778}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498622502}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498639190}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498639256}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498639333}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498639464}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498656811}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498656872}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498656990}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rule"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498657055}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-end"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498673464}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498673550}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498673622}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57675,"ts_us":1793126498673669}}

data: {"id":"4639ce0733431bfd38fd5387caba102a","object":"chat.completion.chunk","created":1793126498,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":360807,"completion_tokens":91,"total_tokens":360898,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":360064,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":57675,"ts_us":1793126498742319}}

data: [DONE]

