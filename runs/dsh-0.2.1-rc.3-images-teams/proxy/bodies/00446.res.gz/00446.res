data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487693421}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487729540}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks good;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487729600}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matrix taller;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487729638}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487820983}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" legible?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487821029}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487821081}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487821125}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but okay. Population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487837085}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487837136}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-axis labels "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487837173}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487837241}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"500 etc."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487975360}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fig"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487975451}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487975488}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rows."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126487975525}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The title/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488009970}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"op okay."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488010015}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488010068}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nOne thought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488010115}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": the title \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488069400}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"A Closed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488069547}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Ecology\" and seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488069636}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488069726}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488306557}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488306642}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes. Good.\n\nPotential improvement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488306684}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488306755}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488475135}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top overlap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488475209}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488475258}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 WEATHERS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488475294}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" legend? P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488502027}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EST"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488502097}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488502166}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ENTIA G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488502232}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"08 label at y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488516040}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488516111}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488516155}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under top;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488516200}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine. GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488594072}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488594131}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" S"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488594185}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ICCIT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488594236}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AS label near top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488681742}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488681809}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not clipped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488681863}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488681924}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for atelier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488728784}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/chartwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488728854}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final. We need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488728923}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" perhaps run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488728961}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488790300}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488790378}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Before that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488790420}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", check current page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488790489}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488852126}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280 live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488852176}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot; likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488852254}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488852561}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We measured"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488915833}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488915908}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488915964}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488916223}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488984710}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488984767}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488984813}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126488984848}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_htkeyyswfjrnvcbs6boiqgec","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489024793}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489024874}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489024947}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489024998}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489044640}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489044694}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489044751}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489045109}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489065471}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489065562}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489065609}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489065635}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489084584}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489084677}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489084721}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489084768}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489098711}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489098789}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489098836}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489098888}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489129657}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489129956}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489130204}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489130266}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489144970}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489145074}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489145139}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489145432}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489145477}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489145531}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489145580}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489145619}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489233581}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489233630}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489233702}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489233785}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489249982}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489250032}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489250071}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489250110}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489250777}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489250874}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489250943}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489250979}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489257260}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489257308}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489257350}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489257390}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489271776}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489271865}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489271920}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489272001}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489273075}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489273146}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489273200}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489273273}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489274498}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489274544}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489274596}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489274667}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489328557}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54319,"ts_us":1793126489328617}}

data: {"id":"4ff21a85af586e9f6e64842a03ec49ec","object":"chat.completion.chunk","created":1793126487,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":335544,"completion_tokens":251,"total_tokens":335795,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":334208,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":161,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":54319,"ts_us":1793126489328701}}

data: [DONE]

