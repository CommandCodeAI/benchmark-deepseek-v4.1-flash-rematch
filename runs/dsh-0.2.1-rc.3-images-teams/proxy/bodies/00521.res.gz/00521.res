data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644654488}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644682844}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644682914}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", composition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644684401}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644778225}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644778478}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" folio text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644778924}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" smaller"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644779006}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644857744}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible. The desktop sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644857868}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644858381}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644858426}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" precisely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644933026}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Great.\n\nOne minor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644933126}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" thing:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644933181}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In 1280 screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644933225}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the \"Plate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644997712}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644997782}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" caption and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644997836}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clock"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127644997877}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645074199}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645074410}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick numerals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645074899}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645074977}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay.\n\nNow wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645133906}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for verifier; likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645134008}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645134315}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645134455}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" progress. Use wait_"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645222071}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"agent."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645222187}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_69ur71csdqca4e2i3p5lv5yu","type":"function","function":{"name":"wait_agent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645222629}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645223191}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645223254}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645223333}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645224420}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645224461}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645236598}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645236752}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645237211}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"000"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645243307}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":65855,"ts_us":1793127645338922}}

data: {"id":"9573a7abecffa4801e89ee0201887803","object":"chat.completion.chunk","created":1793127644,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":360132,"completion_tokens":117,"total_tokens":360249,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":358912,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":75,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":65855,"ts_us":1793127645339010}}

data: [DONE]

