data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123355951186}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356007336}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": adding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356007449}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356007682}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356106658}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 45"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356106744}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356106958}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as reproCooldown) and carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356106996}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cooldown 75 shouldn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356180721}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t change behavior"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356180962}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but results changed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356181057}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait previously"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356181195}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default repro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356252627}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cooldown 45 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356252736}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356252888}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356252932}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 75; same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356329219}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The output first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356329357}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row shows seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356329476}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356329517}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356394978}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356395097}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" alive (h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356395145}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 259"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356395423}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", c 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356472398}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") — different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356472474}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from previous? Because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356472705}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356472879}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356531912}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aselines threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356532010}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356532237}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356532278}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", same. H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356651708}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm, maybe previous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356652084}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356652383}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" table was before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356652434}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patch? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356694266}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356694354}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" table"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356694537}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after v"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356694568}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 had seed1 h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356770022}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356770165}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0. Now seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356770778}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356770819}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"259 c10. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356828254}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only change is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356828376}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" baseline object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356828540}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356828579}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" K and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356909185}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356909280}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356909489}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356909526}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" type=="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356985506}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"='carniv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356985590}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora'?K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356985722}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".carnCooldown:K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123356985765}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".herbCooldown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357047067}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` for child"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357047108}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357047148}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before child co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357047539}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown was K.re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357120992}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"proCooldown=45"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357121124}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357121223}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Now predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357121284}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" child cooldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357187580}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"75 vs 45, slowing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357187697}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357187830}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recovery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357187881}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357254061}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357254197}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" child 45 same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357254240}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That changes dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357254557}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357319533}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357319628}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 75 for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357319892}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" children slows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357319988}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357391954}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth; could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357391988}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357392217}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357392259}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 now herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357468302}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357468364}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 259 and flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357468394}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 47"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357468814}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predators "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357559255}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 — over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357559349}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357559536}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"razed. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357559601}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entire table again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357633194}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357633249}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s run full test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357633290}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" table"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357633704}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357740445}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_jl335ub1rxqjn0oszzp0chb5","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357740638}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357740857}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357740903}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357741378}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357741445}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357741493}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357741572}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357746283}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357746472}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357746607}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357746864}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357747389}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357747658}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357761835}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357761916}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357761980}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357762041}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357762091}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357762144}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357762200}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357762242}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357762482}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357762540}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357776547}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357776611}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357776659}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357776728}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357780955}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357781064}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357781205}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357781297}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357781629}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357781715}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357781926}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357782047}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357839404}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357839452}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357839496}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357839597}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357843222}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357843356}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357843550}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357843612}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357844152}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357844224}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357844273}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357844377}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357851858}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357852003}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357852065}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357852164}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357852632}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357852674}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357852790}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357852834}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357867972}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357868029}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357868079}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357868170}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357883943}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357884005}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357884109}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357884172}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357884807}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357884964}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357885015}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357885111}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357898988}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357899064}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357899237}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357899361}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357918065}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357918140}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357918187}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357918264}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357939257}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357939312}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357939390}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357939500}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357958347}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357958392}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357958469}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Full"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357958613}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357985298}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357985370}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357985492}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123357985604}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ecology"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123358017419}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123358017575}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123358017629}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" parameter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123358017731}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ization"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123358072435}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123358072530}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2972,"ts_us":1793123358072610}}

data: {"id":"7fa3462f5c3c0be624ed8828ece23eef","object":"chat.completion.chunk","created":1793123355,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":145931,"completion_tokens":390,"total_tokens":146321,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":144512,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":261,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2972,"ts_us":1793123358074956}}

data: [DONE]

