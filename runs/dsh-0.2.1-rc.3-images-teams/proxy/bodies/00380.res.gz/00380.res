data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596784933}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596829541}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 undefined — maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596829699}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the evaluate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596829918}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expression with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596891705}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596891799}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596891869}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less took"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596892203}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too long or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596954273}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returned undefined"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596954317}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due exception;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596954384}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125596954436}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Possibly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597034207}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597034423}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597034454}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARIUM__` not ready"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597034759}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597099856}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.5s?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597100051}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or the expression"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597100205}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returns object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597100342}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but await"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597229925}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Promise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597229982}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let's debug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597230036}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The expression"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597230466}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses `W"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597294018}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597294072}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless` exposed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597294148}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597294246}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe `Page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597313947}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".reload`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597314202}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597314268}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597314565}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597366667}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 undefined likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597366878}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because Runtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597367067}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".evaluate returned exception;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597367134}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597461049}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597461094}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" printed. Add logs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597461141}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Simpler run with diagnostics. Maybe `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597461232}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597515164}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"engine` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597515217}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ENGINE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597515325}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597515369}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless; yes."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597595149}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could be page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597595180}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hidden?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597595225}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no. Let's check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597595376}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597676478}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597676532}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597676580}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use quick CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597676693}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597741617}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modify script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597741686}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597741776}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" response."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597741900}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597801234}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be `document.active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597801311}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Element`? no that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597801537}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s later.\n\nPoss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597801613}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ibly the `Runtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597898297}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".evaluate` expression returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597898458}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a Promise?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597898694}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125597898802}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Aw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598027757}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aitPromise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598027885}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" true and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598027994}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returnBy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598028032}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Value; h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598072957}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598073068}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598073122}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe `hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598073364}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At` called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598107850}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too soon after navigate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598107916}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and `__V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598108067}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVARIUM__` undefined"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598108124}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → exception"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598185529}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ev returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598185609}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exceptionDetails object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598185668}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598185777}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598250505}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598250600}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"if(r.result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598250659}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?.exceptionDetails) err"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598250857}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s.push(...)`;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598334723}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598334788}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" response"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598334849}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shape"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598335005}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": send"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598396633}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returns full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598396749}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598396909}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P message; `r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598396965}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".result` is result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598481662}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object with `exception"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598481727}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Details` at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598481899}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top-level and `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598482317}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"result` etc. Actually Runtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598563246}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".evaluate response"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598563389}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is `{result:{result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598563495}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":{...},"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598563606}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exceptionDetails:...}}`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598609796}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; my `r.result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598609856}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?.exceptionDetails` correct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598609943}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". `r.result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598610027}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?.result?.value` undefined"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598732372}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598732461}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exception"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598732504}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Print errors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598732674}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598759876}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"un with error"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598759987}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output and wait longer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598760102}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598760417}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_epzl41yaysilqukvenh0e0vm","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598777867}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598777944}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598778093}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598778312}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598791642}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598791729}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598791814}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598791915}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598855532}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598855644}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598855757}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598855832}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598857278}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598857335}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598857390}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598857433}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598858296}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598858380}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598858530}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598858626}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598863557}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598864112}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598864159}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598864210}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598865044}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598865164}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598876825}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598876923}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598876986}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598877056}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598877116}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598877158}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598898389}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598898498}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598898638}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598898691}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598908648}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598908717}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598908790}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598908892}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598910424}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598910501}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598910568}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598910684}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598931898}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598932077}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598932124}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598932230}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598949329}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598949434}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598949550}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598949631}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598971294}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598971369}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598971448}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598971565}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598973072}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598973134}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598973263}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125598973312}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599025220}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599025331}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599025393}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599025499}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599026040}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599026169}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599026314}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599026377}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599027050}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599027168}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599027417}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599027497}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599027858}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599027956}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599028064}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599028191}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599028550}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599028623}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599028713}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599028845}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599035611}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599035750}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"At"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599035821}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599035963}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599052395}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599052443}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599052512}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599052645}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599066985}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599067067}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599067178}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599067253}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599082443}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599082516}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599082766}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599082822}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599082970}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599083037}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599083088}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599083278}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599111392}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599111495}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599111575}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599111654}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170067}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170157}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170234}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170309}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170391}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170483}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170567}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599170622}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599172921}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599173035}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599173132}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599173315}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599182623}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599182715}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599182803}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599183035}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599207909}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599208004}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599208085}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599208487}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599208570}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599208651}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599208770}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599208986}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599254135}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599254223}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599254296}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599254532}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599274956}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599275054}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599275217}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599275299}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599276408}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599276690}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599276781}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599276926}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599287505}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599287849}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599287939}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599288014}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599411679}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599411763}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599411824}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599411947}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599412398}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599412505}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599412577}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599413664}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599420399}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599420460}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599420518}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599420638}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599429195}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599429249}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"At"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599429289}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599429581}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599429899}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599430152}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599430234}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599430375}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599433738}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599433979}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599434038}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599434088}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599451728}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599451796}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599451907}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599451973}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599453456}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599453575}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599453626}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599453792}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599474446}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599474496}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599474543}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599474658}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599474939}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599475038}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599475088}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599475235}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599482221}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599482273}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599482314}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599482377}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599482832}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599482892}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599483091}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599483136}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599491579}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599491746}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599491907}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599491970}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599492140}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599492270}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599492317}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599492438}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599495814}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599495976}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599496040}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599496188}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599507718}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599507772}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599507944}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599508044}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599508530}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599508695}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599508914}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599508994}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599543775}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599543856}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599543920}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599543984}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599545978}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599546044}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599546107}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599546420}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599546792}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599546860}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599546909}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599547083}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599570831}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599570926}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599570989}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599571099}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599601722}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599601805}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599601878}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599601950}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599602179}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599602243}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599602298}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599602391}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599605268}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599605333}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599605418}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599605546}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599616343}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599616478}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599616525}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599616634}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599617347}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599617402}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599617443}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599617538}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599631885}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599631985}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599632048}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599632126}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599664392}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"At"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599664440}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" returns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599664489}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599664594}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599684396}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599684442}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599684605}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599684669}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599698405}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599698461}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599698570}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599698614}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599715844}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599715955}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599715998}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599716050}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738071}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738129}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738224}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738313}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738483}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738603}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738754}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599738808}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599758276}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599758401}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599758448}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" send"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599758894}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599787765}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599787807}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599787872}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avigate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599787922}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599789039}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599789215}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599789276}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599789366}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599810797}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599810849}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599810962}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599811061}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599877342}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599877418}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599877628}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599877694}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599878466}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" send"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599878510}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599878552}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599878595}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599889157}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avigate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599889205}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599889347}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599889388}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599889840}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599889951}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599889999}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599890495}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599890958}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"250"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599891011}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599891091}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599891138}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599891674}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599891737}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599891798}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599891894}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599907507}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599907650}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" send"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599907720}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599907761}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599910844}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599910895}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599910942}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599911066}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599917975}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ignore"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599918094}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599918247}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599918290}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599918806}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599918949}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599918995}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599919099}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599934967}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599935053}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599935211}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599935293}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599953975}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599954053}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599954114}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" send"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599954213}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599954550}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599954635}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599954715}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599954781}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599977452}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599977501}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ignore"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599977546}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599977674}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599994784}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599994838}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599994990}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599995061}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599996045}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599996193}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"250"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599996267}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125599996344}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600009443}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600009505}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600009606}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600009649}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032202}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032253}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032323}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032507}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032665}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032735}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032871}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600032945}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600044595}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600044699}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600044743}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600044891}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600062221}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600062387}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600062437}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600062718}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600092833}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600092883}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600092928}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600093520}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108120}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108200}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108263}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108498}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Debug"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108655}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reload"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108699}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" determin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108772}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600108880}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" script"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600286426}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600286494}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41737,"ts_us":1793125600286565}}

data: {"id":"f1146fb4694c27521aa23a8ce056a9dc","object":"chat.completion.chunk","created":1793125596,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":309669,"completion_tokens":746,"total_tokens":310415,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":307456,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":320,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":41737,"ts_us":1793125600286722}}

data: [DONE]

