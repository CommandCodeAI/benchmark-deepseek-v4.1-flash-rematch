data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974331353}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Fol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974391886}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"io looks nice;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974391952}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974391993}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lines visible;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974465112}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels right-al"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974465195}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"igned; units"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974465260}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; dial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974465330}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974520440}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pointer. Minor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974520496}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" observations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974520567}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974520614}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974631859}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974631911}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974631946}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974632000}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"76"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974689914}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974689960}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"22 but appear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974690045}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974690129}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974772432}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974772473}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"curves;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974772506}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n2. **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974772541}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"GENER"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974841917}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATION readout sub"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974841979}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974842037}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974842098}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"gen 1 gen\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974911879}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**? Under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974911949}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974911997}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974912059}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says \"40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974978235}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" then \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974978312}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen 1\" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974978379}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"GENERATIONS\" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124974978420}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975031838}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen 1\" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975031905}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975031950}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Δ progress sub"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975032013}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975106812}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out maybe (\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975106865}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen 1\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975106904}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975106943}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?). Might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975157420}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be confusing but acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975157491}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975157532}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"sub read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975157588}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out showing current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975219252}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975219319}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975219371}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n3. **TEM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975219436}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"PO dial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975295569}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**: shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975295652}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pointer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975295718}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975295769}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975364560}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.25×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975364625}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"..8×; readout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975364675}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975364741}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.0× +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975425875}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"60 t/s realised\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975425955}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975425994}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"T"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975426069}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ICKS / SECOND\" ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975508135}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n4. **Dial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975508205}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975508251}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975508295}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** engraved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975564270}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine.\n5."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975564338}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Seed ste"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975564385}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pper: \"−"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975564424}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975623770}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 + REC"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975623872}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AST\" with read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975623940}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975624011}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 + \"1 –"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975714556}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9999 SE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975714667}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ED\" scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975714746}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓.\n6. Labels:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975714864}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"SEED"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975783241}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\", \"MUTATION"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975783300}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" RATE\", \"RE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975783358}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"GROWTH\", \"G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975783416}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ENERATIONS\", \"TEMPO"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975846439}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\", \"WEATHER R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975846515}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"HYTHM\","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975846593}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975846647}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATASTROPHES\","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975902507}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"GH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975902596}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OST TRAILS\" — note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975902658}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"TEM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975902747}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"PO\" instead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975958574}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of \"SP"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975958647}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EED\"; brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975958719}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" table"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124975958790}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key speed but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976043108}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label could be Tem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976043152}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"po. My D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976043186}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 relaxed regex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976043219}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976096481}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tempo ✓.\n7. **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976096539}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tab spine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976096593}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**: rotated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976096662}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976194526}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INSTRUMENTS\" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976194579}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976194622}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ⇥/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976194668}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"⇤ mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976262569}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + brass riv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976262618}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ets top/bottom;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976262654}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks like a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976262694}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" book spine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976338783}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Acceptable but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976338827}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the arrows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976338877}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are separate small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976338930}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brass circles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976393460}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine.\n8."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976393506}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976393569}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a stray"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976393616}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hairline running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976482510}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976482559}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976482610}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"struments\" title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976482651}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976551797}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976551843}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ruler).\n\nOne issue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976551892}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976551927}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976619475}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976619549}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976619598}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" diagonal line rather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976619648}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976674718}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976674795}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Deterministic;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976674857}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n\nNow wait for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976674913}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976729704}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 results. Then check event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976729785}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976729840}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976729872}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976785839}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976785893}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xpu5ns08nywq90wpsm0cxrls","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976785968}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786038}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786178}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786251}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786317}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786376}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786421}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786491}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786543}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786594}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786670}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786739}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786797}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976786865}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787098}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787137}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787209}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787297}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787358}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fficial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787444}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787505}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787571}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787611}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787664}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787706}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976787737}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976817902}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976817962}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976818011}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976818064}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976831833}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976831887}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976831938}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976831994}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976848957}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976849004}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" updated"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976849051}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976849103}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976933860}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976933910}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15625,"ts_us":1793124976933954}}

data: {"id":"e8a5a69033c2f92a552a1c1f022f7897","object":"chat.completion.chunk","created":1793124974,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":279298,"completion_tokens":477,"total_tokens":279775,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":279296,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":401,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":15625,"ts_us":1793124976940614}}

data: [DONE]

